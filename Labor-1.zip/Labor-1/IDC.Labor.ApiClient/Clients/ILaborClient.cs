﻿using FluentResults;
using IDC.Common.Model;
using IDC.Labor.ApiClient.Models;

namespace IDC.Experience.ApiClient.Clients
{
    public interface ILaborClient
    {
        Task<Result<PaginatedList<LaborBulkCompletionDto>>> FindLaborBulkCompletion(FindLaborBulkCompletionRequestDto request, IDictionary<string, string>? headers = null, CancellationToken token = default);
        Task<Result<LaborBulkCompletionDto>> PatchLaborBulkCompletion(Guid id, PatchLaborBulkCompletionRequestDto request, IDictionary<string, string>? headers = null, CancellationToken token = default);
    }
}
