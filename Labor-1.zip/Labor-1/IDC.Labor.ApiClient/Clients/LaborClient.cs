﻿using FluentResults;
using IDC.Common.Model;
using IDC.Common.Tools.Contract;
using IDC.Common.Tools.HttpClientExtensions;
using IDC.Labor.ApiClient.Models;

namespace IDC.Experience.ApiClient.Clients
{
    public class LaborClient : HttpClientBase, ILaborClient
    {
        public LaborClient(HttpClient httpClient, Uri baseUri)
          : base(httpClient, baseUri)
        {
        }

        public LaborClient(HttpClient httpClient, Uri baseUri, TimeSpan timeout)
            : base(httpClient, baseUri, timeout)
    {
    }


        public Task<Result<PaginatedList<LaborBulkCompletionDto>>> FindLaborBulkCompletion(FindLaborBulkCompletionRequestDto request, IDictionary<string, string>? headers = null, CancellationToken token = default)
        => this.PostAsync<FindLaborBulkCompletionRequestDto, ApiResult<PaginatedList<LaborBulkCompletionDto>>>($"AutomateLabor/find-bulk-completion", request, headers, token).ToResultAsync();


        public Task<Result<LaborBulkCompletionDto>> PatchLaborBulkCompletion(Guid id, PatchLaborBulkCompletionRequestDto request, IDictionary<string, string>? headers = null, CancellationToken token = default)
        => this.PatchAsync<PatchLaborBulkCompletionRequestDto, ApiResult<LaborBulkCompletionDto>>($"AutomateLabor/patch-bulk-completion/{id}", request, headers, token).ToResultAsync();

    }
}
