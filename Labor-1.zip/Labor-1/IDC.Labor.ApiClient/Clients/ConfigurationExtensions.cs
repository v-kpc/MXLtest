﻿
using IDC.Common.Tools.HttpClientExtensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace IDC.Experience.ApiClient.Clients
{
    public static class ConfigurationExtensions
    {
        public static IServiceCollection AddLaborClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddClient<ILaborClient, LaborClient>(configuration, "idc-labor-api-service");
            return services;
        }
       
        private static IServiceCollection AddClient<T, TImpl>(this IServiceCollection services, IConfiguration configuration, string httpClientName)
            where TImpl : HttpClientBase where T : class
        {
            services.AddHttpClient(httpClientName);
            services.TryAddSingleton<T>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();

                //TODO: add configuration to azure
                var baseUri = new Uri(configuration["endpoints:idc-labor-api-service:uri"] ?? string.Empty);
                if (TimeSpan.TryParse(configuration["endpoints:idc-labor-api-service:timeout"], out var timeout))
                    return (T)Activator.CreateInstance(typeof(TImpl), factory.CreateClient(httpClientName), baseUri, timeout)!;

                return (T)Activator.CreateInstance(typeof(TImpl), factory.CreateClient(httpClientName), baseUri)!;
            });

            return services;
        }
    }
}
