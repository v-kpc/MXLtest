﻿using IDC.Common.Model.Enums;

namespace IDC.Labor.ApiClient.Models
{
    public record FindLaborBulkCompletionRequestDto    
        (string? LaborCategory = null, string? ErrorType = null, DateTimeOffset? StartDate = null, DateTimeOffset? EndDate = null, int PageIndex = 0, int PageSize = 100);
}
