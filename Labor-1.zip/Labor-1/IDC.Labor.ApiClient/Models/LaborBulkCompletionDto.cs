﻿namespace IDC.Labor.ApiClient.Models
{
    public record LaborBulkCompletionDto
        (Guid Id, string PackageID, string AgreementID, string ErrorType, string LaborCategory, DateTimeOffset Timestamp, string ServiceId, string Country, string? Comment);

}
