﻿
namespace IDC.Labor.ApiClient.Models
{
    public record PatchLaborBulkCompletionRequestDto(string ErrorType, string Comment, string userName);
}
