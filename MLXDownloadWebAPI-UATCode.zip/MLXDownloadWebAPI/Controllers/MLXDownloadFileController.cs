﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Auth;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace MLXDownloadWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MLXDownloadFileController : ControllerBase
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public async Task DownloadAllBlobsInFolderUsingRbacToken()
        {
            

            CloudBlobClient client = await GetClientViaRBACAccessToken();
            CloudBlobContainer container = client.GetContainerReference("mlxfiles");


            var blobPrefix = "LATEST";
            var useFlatBlobListing = true; // ensure all blobs are listed.
            int? maxResults = null;
            BlobContinuationToken currentToken = null;
            BlobRequestOptions options = null;
            OperationContext operationContext = null;
            var blobsListingResult =
                await container.ListBlobsSegmentedAsync(blobPrefix, useFlatBlobListing, BlobListingDetails.None, maxResults, currentToken, options, operationContext);

            var blobsList = blobsListingResult.Results;

            foreach (var item in blobsList)
            {
                var cloudBlob = item as CloudBlob;

                var nameChunks = cloudBlob.Name.Split(new string[] { "/" }, StringSplitOptions.RemoveEmptyEntries);
                if (nameChunks.Length < 1) continue;

                var name = nameChunks[nameChunks.Length - 1];


                CloudBlob blobClient = container.GetBlobReference(cloudBlob.Name);

               // await blobClient.DownloadToFileAsync(Path.Combine(targetFolder, name), FileMode.CreateNew);
                //  }
            }
        }



        //for Prod Environment
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
        string clientId = "dedf7654-8892-4751-a8bc-a72b90ba6f13";
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
        string clientSecret = "~w-tk0o7YAPK.86_vVk8DKdWSZ_ba0B_cK";
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
        string tenantId = "72f988bf-86f1-41af-91ab-2d7cd011db47";
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
        string StorageAccountName = "serviceshubmlx"; //ConfigurationManager.AppSettings["StorageAccountName"].ToString();

        /// <summary>
        /// Get client via Principal MlxBlobDownload
        /// </summary>
        /// <returns></returns>
        public async Task<CloudBlobClient> GetClientViaRBACAccessToken()
        {
            var authContext = new AuthenticationContext($"https://login.windows.net/{tenantId}");
            var credential = new ClientCredential(clientId, clientSecret);
            var result = await authContext.AcquireTokenAsync("https://storage.azure.com", credential);
            Console.WriteLine("Getting token");
            // MessageBox.Show("Getting Token!");
            if (result == null)
            {
                throw new Exception("Failed to authenticate via ADAL");
            }

            var token = result.AccessToken;

            TokenCredential tokenCredential = new TokenCredential(token);
            StorageCredentials storageCredentials = new StorageCredentials(tokenCredential);

            CloudBlobClient client = new CloudBlobClient(new Uri($"https://{StorageAccountName}.blob.core.windows.net"), storageCredentials);

            return client;
        }
    }
}
