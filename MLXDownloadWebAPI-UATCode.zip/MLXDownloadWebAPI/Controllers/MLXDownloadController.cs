﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage;
using Azure;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.Azure.Storage.Auth;
using Microsoft.Identity.Client;
using Newtonsoft.Json.Linq;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Text.RegularExpressions;
using System.Configuration;
using System.IO;
using System.Xml.Serialization;
using System.IO.Pipes;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Newtonsoft.Json;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Diagnostics.Metrics;
using System.Runtime.Serialization;


namespace MLXDownloadWebAPI.Controllers
{

   

    [ApiController]
    [Route("[controller]")]
    public class MLXDownloadController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string _connectionString = "DefaultEndpointsProtocol=https;AccountName=serviceshubmlx;AccountKey=mf7NXLOM5xeRbUylAWyO7BJuKTaCaupx1USOlB1KwO1OV4bBrv8WXbCFnfonvCvhFCVZ1x42DBxw+AStiJEabg==;EndpointSuffix=core.windows.net";

        public MLXDownloadController(IConfiguration configuration)
        {
            _configuration=configuration;
        }
        [HttpGet("[action]")]
        public async Task<IActionResult> MLXDownload()
        {
            BlobClient blobClient = new BlobClient(_connectionString, "mlxfiles", "LATEST/_SC-ADHOCWK-JTE-FR-0-13-JUN-2024-09-00-AM.MLX");
            using (var stream = new MemoryStream())
            {
                await blobClient.DownloadToAsync(stream);
                // await blobClient.GetTagsAsync(stream);
                stream.Position = 0;
                var contentType = (await blobClient.GetPropertiesAsync()).Value.ContentType;
                return File(stream.ToArray(), contentType, blobClient.Name);
            }
        }

        [HttpGet(Name = "download")]
        public async Task<IActionResult> download(string TagName, string Region = null, string Language = null, string file=null)
        {
            //string keyVaultUrl = configuration["KeyVaultSettings:Url"];
            //            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
                       string clientId = "dedf7654-8892-4751-a8bc-a72b90ba6f13";
            //            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
             //          string clientSecret = "8_O8Q~8xpRtvzxnQmPJjqPO5F8YsEv5g.2_eHcaZ";
            //            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]
                       string tenantId = "72f988bf-86f1-41af-91ab-2d7cd011db47";
            //            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine", Justification = "...")]


            //string clientSecretValue = "";
            //Regex _htmlRegex = new Regex("<.*?>", RegexOptions.Compiled);
            //var authContext = new AuthenticationContext($"https://login.windows.net/{tenantId}");
            //string secretName = "MlxBlobDownload-prod";
            //clientSecretValue = GetSecret(secretName).GetAwaiter().GetResult();
            //ClientSecretCredential credential = new ClientSecretCredential(tenantId, clientId, clientSecretValue);
            //BlobServiceClient blobServiceClient = new BlobServiceClient(new Uri("https://serviceshubmlx.blob.core.windows.net"), credential);
            //BlobContainerClient blobContainerClient = blobServiceClient.GetBlobContainerClient("mlxfiles");
            BlobContainerClient blobContainerClient = new BlobContainerClient(_connectionString, "testmlxfiles");

            // BlobServiceClient blobServiceClient = new BlobServiceClient(
            //new Uri($"https://serviceshubmlx.blob.core.windows.net"),
            //new ManagedIdentityCredential(clientId));
            //BlobContainerClient blobContainerClient = blobServiceClient.GetBlobContainerClient("mlxfiles");

            //string storageAccountUrl = "https://serviceshubmlx.blob.core.windows.net";
            //string containerName = "mlxfiles";
            //var blobServiceClient = new BlobServiceClient(new Uri(storageAccountUrl), new DefaultAzureCredential());
            //var blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName);

            var blobs = blobContainerClient.GetBlobs();
            var resultSegment = blobContainerClient.GetBlobsByHierarchyAsync(delimiter: "/")
            .AsPages(default, 2);
            //var resultSegment = blobContainerClient.GetBlobsByHierarchyAsync(prefix:"LATEST", delimiter:"/")
            // .AsPages(default, 2);
            List<MXLDownloadfile> res= new List<MXLDownloadfile>();
            var bulk = new List<(string newsletter, string MLXfile)>();
            var list = new List<BlobItem>();
            var listfilter = new List<BlobItem>();
            await foreach (Page<BlobHierarchyItem> blobPage in resultSegment)
            {
                // A hierarchical listing may return both virtual directories and blobs.
                foreach (BlobHierarchyItem blobhierarchyItem in blobPage.Values)
                {
                    if (blobhierarchyItem.IsBlob)
                    {
                        // Write out the prefix of the virtual directory.
                        Console.WriteLine("Virtual directory prefix: {0}", blobhierarchyItem.Prefix);

                        // Call recursively with the prefix to traverse the virtual directory.
                        list = await ListBlobsHierarchicalListing(blobContainerClient, blobhierarchyItem.Prefix);
                        string MlxTagname;
                        if (Region !=null && TagName!=string.Empty && Language==null)
                        {
                            MlxTagname = Region + "-" + TagName;
                             //listfilter = list.FindAll(s => s.Name.IndexOf("SECURITYCALL-CN", StringComparison.OrdinalIgnoreCase) >= 0);
                             listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase)>=0);
                        }
                        else if (TagName != string.Empty && Language != null && Region != null && file == null )
                        {
                            MlxTagname = Region+"-"+TagName + "-" + Language +"-";
                            listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase) >= 0);
                        }
                        else if (TagName != string.Empty && Language != null && Region != null && file != null)
                        {
                            MlxTagname = Region + "-" + TagName + "-" + Language + "-"+file;
                            listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase) >= 0);
                        }

                        else if (TagName != string.Empty && Language != null && Region == null && file == null)
                        {
                            MlxTagname = TagName + "-" + Language + "-";
                            listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase) >= 0);
                        }
                        else if (TagName != string.Empty && Language != null && Region == null && file != null)
                        {
                            MlxTagname = TagName + "-" + Language + "-"+file;
                            listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase) >= 0);
                        }

                        else if (TagName != string.Empty && Language == null && Region == null && file == null)
                        {
                            MlxTagname = TagName+"-";
                            listfilter = list.FindAll(s => s.Name.IndexOf(MlxTagname, StringComparison.OrdinalIgnoreCase) >= 0);
                        }
                    }
                    else
                    {
                        // Write out the name of the blob.
                        Console.WriteLine("Blob name: {0}", blobhierarchyItem.Blob.Name);
                    }
                }

            }
           // XmlDocument xmlDocument = new XmlDocument();

            foreach (var blob in listfilter)
            {
                var blobClient = blobContainerClient.GetBlobClient(blob.Name);
                
                string strnewletter = blobClient.Name;
                using var stream = new MemoryStream();
                await blobClient.DownloadToAsync(stream);
                stream.Position = 0;
                using var streamReader = new StreamReader(stream);
                var result = await streamReader.ReadToEndAsync();
                byte[] byteArray = Encoding.UTF8.GetBytes(result);
                MemoryStream streamdata = new MemoryStream(byteArray);

                MailingTagList mls = DeserializeXmlData<MailingTagList>(result);
                var downloadcount = mls.MailingLists.Count();
                int counter;
                List<MXLDownloadfile> finallist = new List<MXLDownloadfile>();
                if (_configuration["DuplicateRecepient"] == "TRUE")
                {
                    XDocument document = XDocument.Load(streamdata);
                    var grouped = document.Descendants("RecipientsTo").Where(x => x.Value.ToLower().Contains("@microsoft.com")).GroupBy(x => x.Value.ToLower());
                    //  .Where(g => g.Count() > 1);

                    var grpcount = grouped.Count();

                    foreach (var groupItem in grouped)
                    {
                        counter = 0;
                        if (groupItem.Count() > 1)
                        {
                            foreach (var item in groupItem)
                            {
                                if (counter > 0)
                                {
                                    item.Parent.Remove();
                                }
                                counter++;
                            }
                        }

                    }
                    string xmlstring = document.ToString();
                    MailingTagList mlscount1 = DeserializeXmlData<MailingTagList>(xmlstring);
                    var afterfiltercount = mlscount1.MailingLists.Count();


                   
                    finallist.Add(new MXLDownloadfile { MLXfile = xmlstring, Newsletter = strnewletter, BeforeCSAMSremoveMlxcount = downloadcount, AfterCSAMSremoveMLXcount = afterfiltercount });
                }
                else
                {
                   
                    finallist.Add(new MXLDownloadfile { MLXfile = result.ToString(), Newsletter = strnewletter, BeforeCSAMSremoveMlxcount = downloadcount, AfterCSAMSremoveMLXcount = 0 });


                }
                res.AddRange(finallist);

            }

            return Ok(res);

        }

        public static T DeserializeXmlData<T>(string xmlData)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using StringReader reader = new StringReader(xmlData);

            return (T)serializer.Deserialize(reader)!;
        }


        public static async Task<string> GetSecret(string secretName)
        {
            string secretValue = "";
            string keyVaultName = "ServiceCenterIDCKeyVault";
            try
            {
                SecretClientOptions options = new SecretClientOptions()
                {
                    Retry =
            {
            Delay= TimeSpan.FromSeconds(2),
            MaxDelay = TimeSpan.FromSeconds(16),
            MaxRetries = 5,
            Mode = Azure.Core.RetryMode.Exponential
            }
                };
                var client = new SecretClient(new Uri("https://" + keyVaultName + ".vault.azure.net/"), new DefaultAzureCredential(), options);

                KeyVaultSecret secret = client.GetSecret(secretName);

                secretValue = secret.Value;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            return secretValue;
        }
        private static async Task<List<BlobItem>> ListBlobsHierarchicalListing(
    BlobContainerClient container,
    string prefix)
        {
            var list = new List<BlobItem>();

            var resultSegment =
                container.GetBlobsByHierarchyAsync(prefix: prefix, delimiter: "/");

            // A hierarchical listing may return both virtual directories and blobs.
            await foreach (BlobHierarchyItem blobhierarchyItem in resultSegment)
            {
                if (blobhierarchyItem.IsPrefix)
                {
                    // Write out the prefix of the virtual directory.

                    // Call recursively with the prefix to traverse the virtual directory.
                    list.AddRange(await ListBlobsHierarchicalListing(container, blobhierarchyItem.Prefix));
                }
                else
                {
                    // Write out the name of the blob.
                    list.Add(blobhierarchyItem.Blob);
                    // list.Add(blobhierarchyItem.Blob.Name)
                }
            }
          

            return list;
        }

        [HttpGet("[action]")]
        public async Task<IActionResult> Bulkdownlaod()
        {
            BlobContainerClient blobContainerClient = new BlobContainerClient(_connectionString, "mlxfiles");
            // var containerClient = blobContainerClient.GetBlobContainerClient("mycontainer");
            var blobs = blobContainerClient.GetBlobs();

            foreach (var blob in blobs) {

                BlobClient blobClient = blobContainerClient.GetBlobClient(blob.Name);
                blobClient.DownloadTo(@"C:\temp\test"+blob.Name);

            }
            return Ok();
            

           
        }

      

        }
    }