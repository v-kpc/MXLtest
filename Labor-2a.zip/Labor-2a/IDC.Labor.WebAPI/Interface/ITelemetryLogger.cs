﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Metrics;

namespace AutomationLaborEntry.Interface
{
    public interface ITelemetryLogger : ILogger
    {
        void LogError(Exception exception);

        void LogError(EventId eventId, Exception exception);

        void LogError(Exception exception, string message);

        void LogError(EventId eventId, Exception exception, string message);

        void LogError(Exception exception, Dictionary<string, string> extendedInformation);

        void LogError(Exception exception, string message, Dictionary<string, string> extendedInformation);

        void LogError(EventId eventId, Exception exception, string message, Dictionary<string, string> extendedInformation);

        //-----------------------------------------

        void LogTrace(string message);

        void LogTrace(EventId eventId, string message);

        void LogTrace(string message, Dictionary<string, string> extendedInformation);

        void LogTrace(EventId eventId, string message, Dictionary<string, string> extendedInformation);

        //-------------------------------------

        void LogWarning(Exception exception);

        void LogWarning(EventId eventId, Exception exception);

        void LogWarning(Exception exception, string message);

        void LogWarning(EventId eventId, Exception exception, string message);

        void LogWarning(Exception exception, string message, Dictionary<string, string> extendedInformation);

        void LogWarning(EventId eventId, Exception exception, string message, Dictionary<string, string> extendedInformation);

        /// <summary>
        /// MSIT Feature usage logging. This should be used to log usage of any user facing feature.
        /// </summary>
        /// <param name="eventName">The name of the event that is happening</param>
        /// <param name="componentType">What type of component are you</param>
        /// <param name="componentUri">What is the path to your feature i.e. Api url or app page path</param>
        /// <param name="userRole">[Optional] What is the role name of the user using this feature</param>
        /// <param name="durationInMS">[Optional] How long was the feature used in milliseconds </param>
        /// <param name="properties">[Optional] A collection of properties that should be associated to the telemetry entry</param>
        /// <param name="metrics">[Optional] A collection of metrics that should be associated to the telemetry</param>
      //  void TrackFeatureEvent(string eventName, ComponentType componentType, string componentUri, string userRole, double durationInMS, Dictionary<string, string> properties, Dictionary<string, double> metrics);

        /// <summary>
        /// Tracks the business event.
        /// </summary>
        /// <param name="businessProcessEvent">The business process event.</param>
       // void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent);

        /// <summary>
        /// MSIT Business process event logging. This should be used to log an event that operates on a business object.
        /// </summary>
        /// <param name="businessProcessEvent">The business process event.</param>
        /// <param name="properties">[Optional] A collection of properties that should be associated to the telemetry entry</param>
       // void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent, Dictionary<string, string> properties);

        /// <summary>
        /// Tracks the business event.
        /// </summary>
        /// <param name="businessProcessEvent">The business process event.</param>
        /// <param name="properties">The properties.</param>
        /// <param name="metrics">The metrics.</param>
       // void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent, Dictionary<string, string> properties, Dictionary<string, double> metrics);

        /// <summary>
        /// Send a Microsoft.ApplicationInsights.DataContracts.MetricTelemetry for aggregation in Metric Explorer.
        /// </summary>
        /// <param name="name">Metric name.</param>
        /// <param name="value">Metric value.</param>
        /// <param name="properties">Named string values you can use to classify and filter metrics.</param>
        void TrackMetricEvent(string name, double value, Dictionary<string, string> properties);

        /// <summary>
        /// Send a Microsoft.ApplicationInsights.DataContracts.RequestTelemetry for aggregation in Request Explorer.
        /// </summary>
        /// <param name="telemetry">request telemetry</param>
       // void TrackRequest(RequestTelemetry telemetry);

        /// <summary>
        /// Custom event to track the Dependency.
        /// </summary>
        /// <param name="dependencyTypeName">The dependencyType.</param>
        /// <param name="target">target name.</param>
        /// <param name="dependencyName">dependency Name.</param>
        /// <param name="command">The command.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="duration">Dependency duration.</param>
        /// <param name="resultCode">Dependency resultCode.</param>
        /// <param name="success">Dependency status.</param>
        void TrackDependency(string dependencyTypeName, string target, string dependencyName, string command, DateTimeOffset startTime, TimeSpan duration, string resultCode, bool success);


        /// <summary>
        /// Custom event to track the Dependency.
        /// </summary>
        /// <param name="dependencyType">Type of the dependency.</param>
        /// <param name="dependencyName">dependency Name.</param>
        /// <param name="target">The target.</param>
        /// <param name="resultCode">The result code.</param>
        /// <param name="command">Dependency command.</param>
        /// <param name="duration">Dependency duration.</param>
        /// <param name="success">Dependency status.</param>
        /// <param name="customProperties">customProperties</param>
        void TrackDependency(string dependencyType, string dependencyName, string target, string resultCode, string command, TimeSpan duration, bool success, Dictionary<string, string> customProperties);

        /// <summary>
        /// Flushes the in-memory buffer and any metrics being pre-aggregated.
        /// </summary>
        void Flush();
    }
}
