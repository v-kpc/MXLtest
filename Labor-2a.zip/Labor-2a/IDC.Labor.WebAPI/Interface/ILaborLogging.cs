﻿using AutomationLaborEntry.Model;

namespace AutomationLaborEntry.Interface
{
    public interface ILaborLogging
    {
        public Task<List<MailingList>> GetMXLfiles(List<MXLDownloadfile> mXLDownloadfiles, CancellationToken cancellationToken);


        public Task<List<MailingList>> GetMailingList(CancellationToken cancellationToken);
    }
}
