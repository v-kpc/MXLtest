﻿
using AutomatedLaborEntry.Model;
using AutomationLaborEntry.Model;
using IDC.Labor.Infrastructure.Repositories;

namespace IDC.Labor.WebAPI.Interface
{
    public interface IProcessTransaction
    {
       Task<bool> GetTransaction(TopicMessage listMessage);
    }
}
