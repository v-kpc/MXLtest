﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Xml;
using AutomationLaborEntry.Model;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.ApplicationInsights;
using AutomationLaborEntry.HttpClientBulk;
using Newtonsoft.Json;
using AutomationLaborEntry.Interface;
using System.Configuration;
using Azure.Identity;
using Azure.Storage.Files.DataLake;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;
using System.IO;
using System.Text;
using IDC.Labor.WebAPI;
using IDC.Common.Authentication;
using Microsoft.Extensions.Configuration;

namespace AutomationLaborEntry
{
    public class LaborLogging : ILaborLogging
    {
        #region public variable
        public static System.IO.StreamWriter appFile;
        public static List<MailingList> loadedLists;
        public IEnumerable<MailingList> batchLists;
        public ObservableCollection<Data> data;
        ApiMethods callApi;
        public List<string> failedPayload;
        public IConfiguration Configuration { get; }
        public ITokenProvider TokenProvider;
        public static MemoryStream stream;
        public static DataLakeFileClient fileClient;
        #endregion

        public LaborLogging(IConfiguration configuration, ITokenProvider tokenProvider)
        {

            try
            {

                loadedLists = new List<MailingList>();
                failedPayload = new List<string>();
                Configuration = configuration;
                TokenProvider = tokenProvider;
                //string accountName = "msit-onelake";
                //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
                //string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";
                //// string fileName = $"{Configuration.GetValue<string>("CDEFabricsDataLake:fileName")}-{DateTime.Now.ToString("yyyy-MM-dd")}.txt";
                //string fileName = "Applog-" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
                //string newFileName = "LoadList.xml";


                //var serviceClient = new DataLakeServiceClient(
                //    new Uri($"https://{accountName}.dfs.fabric.microsoft.com"),
                //    new DefaultAzureCredential());

                //DataLakeFileSystemClient fileSystemClient = serviceClient.GetFileSystemClient(fileSystemName);

                //var directoryClient = fileSystemClient.GetDirectoryClient(directoryName);
                //fileClient = directoryClient.GetFileClient(fileName);
                //fileClient.Create();
                //stream = new MemoryStream();




            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Labor logging " + ex.StackTrace);
                // appFile.WriteLine("Inside Labor logging" + ex.Message + " " + DateTime.Now.ToString());
                // telemetryClient.TrackException(ex);
            }
            finally
            {
                //if (_readWriteLock.IsWriteLockHeld)
                //{
                //    _readWriteLock.ExitWriteLock();
                //}
                // appFile.Close();
            }

        }





        /// <summary>
        /// Generating Payload for Post request
        /// Parameter: flag - false for fresh entry and true for Application retry entry
        /// </summary>
        /// <param name="flag"></param>
        public string GeneratePayload(int index)
        {
            try
            {
                data = new ObservableCollection<Data>();
                foreach (MailingList ml in batchLists)
                {
                    data.Add(LaborEntry(ml, index));
                }
                return GetHeader();
            }
            catch (Exception exe)
            {
                appFile.WriteLine("Generating Pay Load:  " + exe.StackTrace + "\n" + exe.Message + " " + DateTime.Now.ToString());
                Console.WriteLine(exe.StackTrace);
                // telemetryClient.TrackException(exe);
            }
            return string.Empty;
        }


        /// <summary>
        /// generating header for the payload
        /// </summary>
        public string GetHeader()
        {
            string output = string.Empty;
            try
            {
                //telemetry = new Telemetry();
                BulkSubmitHeader _submitHeader = new BulkSubmitHeader();
                _submitHeader.operationID = Guid.NewGuid();
                //appFile.WriteLine("Creating operationId  :" + _submitHeader.operationID);

                string applog1 = "Creating operationId  :" + _submitHeader.operationID + Environment.NewLine;
                byte[] initialData = Encoding.UTF8.GetBytes(applog1);
                stream.Write(initialData, 0, initialData.Length);

                _submitHeader.originatingDateTimeInUtc = DateTime.UtcNow;
                _submitHeader.type = "Submit";
                BulkSubmit bulkSubmit = new BulkSubmit();
                bulkSubmit.context = _submitHeader;
                bulkSubmit.data = data;
                output = JsonConvert.SerializeObject(bulkSubmit);

                string applog2 = "Bulk Submit Payload " + output + Environment.NewLine;
                byte[] outputdata = Encoding.UTF8.GetBytes(applog2);
                stream.Write(outputdata, 0, outputdata.Length);
                //appFile.WriteLine("Bulk Submit Payload " + output);
                //telemetry.telemetryOperationProperties.Add("OperationId", _submitHeader.operationID.ToString());
                // logger.TrackBusinessEvent(new msit.BusinessProcessEvent("OperationID generated", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryOperationProperties);
                return output;

            }
            catch (Exception ex)
            {
                appFile.WriteLine("Binding Header: " + ex.Message + " " + DateTime.Now.ToString());
                // telemetryClient.TrackException(ex);
            }
            return output;
        }


        /// <summary>
        /// spliting mailing list into parts for processing
        /// </summary>
        /// <param name="lists"></param>
        /// <param name="flag"></param>
        public async Task<bool> BatchProcessList(List<MailingList> lists, int index)
        {

            try
            {
                bool isValidPayLoad;



                Task<bool> getPostResult;
                if (index > 0)
                {

                    //appFile.WriteLine("Inside Batch Processing");
                    //   await callApi.SaveTextFileAsync(directoryClient, newFileName, appFile);

                    //File.AppendText(ConfigurationManager.AppSettings["ApplicationLog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd"));
                }
                string applog = "Inside Batch Processing" + Environment.NewLine;
                //string applog = "Exit due to error in StoredList";
                byte[] newData4 = Encoding.UTF8.GetBytes(applog);
                stream.Write(newData4, 0, newData4.Length);
                //appFile.WriteLine("Inside Batch Processing");
                int BatchSize = 150;// int.Parse(Configuration.GetValue<string>("SharepointUrl:BatchSize").ToString());
                /* just checking*/
                List<Task> tasklist = new List<Task>();
                if (callApi == null)
                {
                    callApi = new ApiMethods(Configuration, TokenProvider);
                }

                for (int i = 0; i < lists.Count; i = i + BatchSize)
                {
                    try
                    {
                        batchLists = new ObservableCollection<MailingList>();
                        batchLists = lists.Skip(i).Take(BatchSize);
                        string output = GeneratePayload(index);
                        if (!string.IsNullOrEmpty(output))
                        {

                            getPostResult = callApi.PostMethod(output);
                            tasklist.Add(getPostResult);
                            isValidPayLoad = await getPostResult;
                            if (!isValidPayLoad)
                            {
                                failedPayload.Add(output);
                            }
                        }
                        else
                        {
                            appFile.WriteLine("Payload is Empty");
                        }
                    }
                    catch (Exception exe)
                    {
                        appFile.WriteLine("Error in bulk submit trigger  " + exe.StackTrace + " " + exe.Message + DateTime.Now.ToString());
                    }

                }
                await Task.WhenAll(tasklist);

                if (failedPayload.Count != 0)
                {
                    foreach (string pay in failedPayload)
                    {
                        try
                        {
                            getPostResult = callApi.PostMethod(pay);
                            tasklist.Add(getPostResult);
                            isValidPayLoad = await getPostResult;
                            if (!isValidPayLoad)
                            {
                                //string isdone = string.Empty;////= new WriteToAzureStorage().UpdateFailedPayLoadAzureTableEntity(pay, "Failed");
                                //appFile.WriteLine("Retry Failed for Payload   " + pay + "
                                //" + isdone);
                                byte[] newDatafail = Encoding.UTF8.GetBytes("Retry Failed for Payload   " + pay + "Status " + "Failed");
                                stream.Write(newDatafail, 0, newDatafail.Length);
                                stream.Seek(0, SeekOrigin.Begin);
                                fileClient.Append(stream, 0);
                                fileClient.Flush(stream.Length);
                            }
                            else
                            {
                                //string isdone = string.Empty;// = new WriteToAzureStorage().UpdateFailedPayLoadAzureTableEntity(pay, "Success");
                                //appFile.WriteLine("Retry Passed for Payload   " + pay + "Status " + isdone);
                                byte[] newDatafailed = Encoding.UTF8.GetBytes("Retry Passed for Payload   " + pay + "Status " + "Failed");
                                stream.Write(newDatafailed, 0, newDatafailed.Length);
                                stream.Seek(0, SeekOrigin.Begin);
                                fileClient.Append(stream, 0);
                                fileClient.Flush(stream.Length);
                            }
                        }
                        catch (Exception exe)
                        {
                            byte[] newDataerr = Encoding.UTF8.GetBytes("Error in retry bulk submit trigger  " + exe.StackTrace + " " + exe.Message + DateTime.Now.ToString());
                            stream.Write(newDataerr, 0, newDataerr.Length);
                            stream.Seek(0, SeekOrigin.Begin);
                            fileClient.Append(stream, 0);
                            fileClient.Flush(stream.Length);


                        }
                    }
                }
                else
                {
                    string applogstr = "All task completed" + Environment.NewLine;
                    byte[] newDatacom = Encoding.UTF8.GetBytes(applogstr);
                    stream.Write(newDatacom, 0, newDatacom.Length);
                    stream.Seek(0, SeekOrigin.Begin);
                    fileClient.Append(stream, 0);
                    fileClient.Flush(stream.Length);
                    
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in batchprocessing" + ex.StackTrace + ex.Message);
                appFile.WriteLine("Batch Processing " + ex.Message + " " + DateTime.Now.ToString());
                //contentToSave = appFile.ToString();
                //await callApi.SaveTextFileAsync(directoryClient, newFileName, contentToSave);
                // telemetryClient.TrackException(ex);
                return false;

            }
            finally
            {
                //if (_readWriteLock.IsWriteLockHeld)
                //    _readWriteLock.ExitWriteLock();
            }
            return true;
        }



        /// <summary>
        /// setting values to Labor Data
        /// </summary>
        /// <param name="ml"></param>
        /// <param name="flag"></param>
        /// <returns></returns>
        public Data LaborEntry(MailingList ml, int index)
        {
            Data laborDataEntry = new Data();
            LaborEntry labor = new LaborEntry();
            //telemetry = new Telemetry();
            try
            {
                labor.laborCategoryId = ml.LaborCategoryId;
                if (ml.Index > 0)
                {
                    laborDataEntry.context.correlationId = Guid.NewGuid();
                    ml.GUID = laborDataEntry.context.correlationId;
                }
                else
                {
                    laborDataEntry.context.correlationId = ml.GUID;// Guid.NewGuid();
                }

                labor.assignmentDetails = new AssignmentDetails();

                //for Labor late submission
                //labor.laborDate = DateTimeOffset.Parse("2020-04-15T00:00:00Z").UtcDateTime.Date;//for late submission
                //labor.submittedBy = "bravos-idc-newsletters-submitter-" + "04" + "/" + DateTime.Now.Year;
                //labor.submittedFor = "bravos-idc-newsletters-submitter-" + "04" + "/" + DateTime.Now.Year;


                labor.laborHours = new TimeSpan(00, 00, 00);
                labor.laborTimeZoneId = 35;

                // for normal submission
                labor.submittedBy = "bravos-idc-newsletters-submitter-" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year;
                labor.submittedFor = "bravos-idc-newsletters-submitter-" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year;
                labor.laborDate = DateTime.UtcNow.Date;


                if (labor.laborCategoryId == (int)MailingList.laborCategory.Proactive_Content_Billing)
                {
                    labor.laborNotes = string.Format("Proactive Alert " + " " + System.String.Format("{0:MMM}", DateTime.Now) + " " + DateTime.Now.Year);
                    if (string.Equals(ml.AgreementCountry, "China") || string.Equals(ml.AgreementCountry, "Taiwan"))
                    {
                        labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                        {
                            chargedLabor = new TimeSpan(00, 30, 00)
                        };
                    }
                    else
                    {
                        labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                        {
                            chargedLabor = new TimeSpan(00, 45, 00)
                        };
                    }
                }
                else if (labor.laborCategoryId == (int)MailingList.laborCategory.Reactive_Content_Billing)
                {
                    labor.laborNotes = string.Format("Security Alert" + " " + System.String.Format("{0:MMM}", DateTime.Now) + " " + DateTime.Now.Year);
                    labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                    {
                        chargedLabor = new TimeSpan(00, 15, 00)
                    };
                }
                labor.partner = "bravos-idc-newsletters";
                labor.assignmentDetails = new AssignmentDetails()
                {

                    agreementId = Int64.Parse(ml.AgreementId),
                    packageId = Int64.Parse(ml.PackageId),
                    serviceId = Int64.Parse(ml.ServiceId),
                    regionId = ml.AgreementRegionId,
                    //  isPublicSector = null

                };


                labor.updatedDateInUtc = DateTime.UtcNow;

                /// for late submission scenario
                //  labor.actionDetails = new ActionDetail[1];
                //  labor.actionDetails[0] = new ActionDetail();
                //  labor.actionDetails[0].reasonId = 333177;
                ////  labor.actionDetails[0].comments = "Delayed Billing";
                // labor.actionDetails[0].comments = "https://nam06.safelinks.protection.outlook.com/?url=https%3A%2F%2Fipgengagements.visualstudio.com%2Ff9cffc0e-8cf9-4ef4-8634-4413399709c7%2F_workitems%2Fedit%2F36203&data=02%7C01%7Cv-ranjpa%40microsoft.com%7Cead15e2a0e684a6411e508d7eff596aa%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C637241710586101292&sdata=LB3ypKgdknZD%2FvYC3jXp2GNYj9AL3u9VzQN2vfU1NpY%3D&reserved=0" +"   delayed submission due to pubsec charges";
                //  labor.actionDetails[0].actionType = "LateSubmission";



                laborDataEntry.data = labor;
                //telemetry.telemetryLaborProperties.Add("ContractId", ml.AgreementId);
                //telemetry.telemetryLaborProperties.Add("ScheduleId", ml.PackageId);
                //telemetry.telemetryLaborProperties.Add("LineItemId", ml.ServiceId);
                //telemetry.telemetryLaborProperties.Add("CorrelationID", ml.GUID.ToString());
                //telemetry.telemetryLaborProperties.Add("LaborCategoryID", (ml.LaborCategoryId != 0) ? ml.LaborCategoryId.ToString() : "0");
                //telemetry.telemetryLaborProperties.Add("Modified Guid", (ml.GUID == laborDataEntry.context.correlationId) ? "0" : laborDataEntry.context.correlationId.ToString());
                // logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Labor Data : ", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryLaborProperties);

                if (ml.Index > 0)
                {
                    string status = storeLoadedList(index, ml);
                }

            }

            catch (Exception exe)
            {
                appFile.WriteLine("Inside Labor Entry" + exe.StackTrace);
                //telemetryClient.TrackException(exe);
            }
            return laborDataEntry;
        }
        /// <summary>
        /// to get access with appid,clientid and secretid
        /// </summary>
        /// <returns></returns>
        public AuthInput GetAuth()
        {
            AuthInput auth = new AuthInput();
            auth.Authority = Configuration.GetValue<string>("Time2.0APIUrldetails:Authority").ToString();
            auth.ClientId = Configuration.GetValue<string>("Time2.0APIUrldetails:ClientId").ToString();
            //auth.ClientSecret = Configuration.GetValue<string>("Time2.0APIUrldetails:ClientSecret").ToString();
            auth.Resource = Configuration.GetValue<string>("Time2.0APIUrldetails:Resource").ToString();
            return auth;
        }

        /// <summary>
        /// store the existing Mlx file to storedlist
        /// </summary>
        public string storeLoadedList(int index, MailingList ml)
        {
            //string accountName = "msit-onelake";
            //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
            //string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";
            ////string fileName = "Applog-2024-09-10.txt";

            //string newFileName = "LoadList.xml";

            string accountName = Configuration.GetValue<string>("CDEFabricsDataLake:accountName");
            //string accountName = "msit-onelake";
            //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
            string fileSystemName = Configuration.GetValue<string>("CDEFabricsDataLake:fileSystemName");
            // string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";

            string directoryName = Configuration.GetValue<string>("CDEFabricsDataLake:directoryName");
            // string fileName = $"{Configuration.GetValue<string>("CDEFabricsDataLake:fileName")}-{DateTime.Now.ToString("yyyy-MM-dd")}.txt";
            //  string fileName = "Applog-" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            string fileName = Configuration.GetValue<string>("CDEFabricsDataLake:fileName") + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            //string newFileName = "LoadList.xml";
            string newFileName = Configuration.GetValue<string>("CDEFabricsDataLake:newFileName");


            var serviceClient = new DataLakeServiceClient(
                new Uri($"https://{accountName}.dfs.fabric.microsoft.com"),
                new DefaultAzureCredential());

            DataLakeFileSystemClient fileSystemClient = serviceClient.GetFileSystemClient(fileSystemName);

            var directoryClient = fileSystemClient.GetDirectoryClient(directoryName);
            string strloadlist = string.Empty;


            try
            {
                if (ml != null)
                {
                    if (ml.Index > 0)
                    {
                        // XmlSerializer serializer = new XmlSerializer(typeof(List<MailingList>));

                        XmlRootAttribute xRoot = new XmlRootAttribute();
                        xRoot.ElementName = "Tag";
                        XmlSerializer serializer = new XmlSerializer(typeof(List<MailingList>), xRoot);
                        using (StringWriter writer = new StringWriter())
                        {
                            serializer.Serialize(writer, ml);
                            strloadlist = writer.ToString();
                            // Console.WriteLine(xmlOutput);
                        }

                        //directoryClient = fileSystemClient.GetDirectoryClient(directoryName);
                        var fileClient1 = directoryClient.GetFileClient(newFileName);
                        if (fileClient1.Exists())
                        {
                            // Delete the file if it exists
                            fileClient1.Delete();
                        }

                            //if( fileClient1.Exists
                            // {

                            // }

                            using (MemoryStream smxml = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(strloadlist)))
                        {
                            fileClient1.Create();
                            fileClient1.Append(smxml, 0);
                            fileClient1.Flush(smxml.Length);
                        }

                        //byte[] newData4 = Encoding.UTF8.GetBytes("LoadedList added with Mailing List" + ml.GUID.ToString() +Environment.NewLine);
                        //stream.Write(newData4, 0, newData4.Length);
                        //stream.Flush();

                        //stream.Seek(0, SeekOrigin.Begin);
                        //fileClient.Append(stream, 0);
                        //fileClient.Flush(stream.Length);

                        //appFile.WriteLine("LoadedList added with Mailing List" + ml.GUID.ToString());
                    }


                }

                else
                {


                    string xml = ConvertListToXml(loadedLists);
                    var fileClient2 = directoryClient.GetFileClient(newFileName);
                    if (fileClient2.Exists())
                    {
                        // Delete the file if it exists
                        fileClient2.Delete();
                    }

                    using (MemoryStream ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(xml)))
                    {
                        fileClient2.Create();
                        fileClient2.Append(ms, 0);
                        fileClient2.Flush(ms.Length);
                    }

                }
                return "Success";
            }


            catch (Exception exe)
            {
                appFile.WriteLine("Error Store Loaded list" + exe.StackTrace + " " + exe.InnerException);
                //telemetryClient.TrackException(exe);
                return "Failed";
            }
            finally
            {
                //doc = null;

            }
        }






        public static string ConvertListToXml<T>(List<T> list)
        {
            XmlRootAttribute xRoot = new XmlRootAttribute();
            xRoot.ElementName = "Tag";
            //XmlSerializer serializer = new XmlSerializer(typeof(List<MailingList>), xRoot);
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>), xRoot);
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, list);
                return writer.ToString();
            }
        }


        private void AppendToFileLog(string file)
        {
            try
            {
                if (!Directory.Exists(""))//ConfigurationManager.AppSettings["BusinessErrorLog"].ToString()))
                {
                    Directory.CreateDirectory("");// ConfigurationManager.AppSettings["BusinessErrorLog"].ToString());
                }
                using (StreamWriter wr = System.IO.File.AppendText(""))//ConfigurationManager.AppSettings["LstLog"].ToString() + ".lst"))
                {
                    wr.WriteLine(file);
                    wr.Close();
                }
            }
            catch (Exception exe)
            {
                appFile.WriteLine(exe.Message);
            }
            finally
            {
            }


        }

        public async Task<List<MailingList>> GetMXLfiles(List<MXLDownloadfile> mXLDownloadfiles, CancellationToken cancellationToken)
        {
          
            string accountName = Configuration.GetValue<string>("CDEFabricsDataLake:accountName");
            //string accountName = "msit-onelake";
            //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
            string fileSystemName= Configuration.GetValue<string>("CDEFabricsDataLake:fileSystemName");
            // string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";

            string directoryName = Configuration.GetValue<string>("CDEFabricsDataLake:directoryName");
            // string fileName = $"{Configuration.GetValue<string>("CDEFabricsDataLake:fileName")}-{DateTime.Now.ToString("yyyy-MM-dd")}.txt";
            //  string fileName = "Applog-" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            string fileName = Configuration.GetValue<string>("CDEFabricsDataLake:fileName") + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            //string newFileName = "LoadList.xml";
            string newFileName= Configuration.GetValue<string>("CDEFabricsDataLake:newFileName");


            var serviceClient = new DataLakeServiceClient(
                new Uri($"https://{accountName}.dfs.fabric.microsoft.com"),
                new DefaultAzureCredential());

            DataLakeFileSystemClient fileSystemClient = serviceClient.GetFileSystemClient(fileSystemName);

            var directoryClient = fileSystemClient.GetDirectoryClient(directoryName);
            fileClient = directoryClient.GetFileClient(fileName);
            fileClient.Create();
            stream = new MemoryStream();
            List<MailingList> LstMXLfile = new List<MailingList>();

            try
            {
                //using (MemoryStream stream = new MemoryStream())
                //{
                string applog1 = "Reading Mlx Files" + DateTime.Now.ToString() + Environment.NewLine;
                byte[] initialData = Encoding.UTF8.GetBytes(applog1);

                stream.Write(initialData, 0, initialData.Length);



                if (mXLDownloadfiles.Count() > 0)
                {
                    foreach (var mlxdata in mXLDownloadfiles)
                    {

                        MailingTagList mls = DeserializeXmlData<MailingTagList>(mlxdata.MLXfile);

                        // Parse all tags and add to our global list if they weren't there already
                        foreach (MailingList ml in mls.MailingLists)
                        {
                            ml.Index = 0;// mls.MailingLists.IndexOf(ml);
                            ml.Tag = new string[] { mls.Name.Trim() };
                            ml.GUID = Guid.NewGuid();

                            // Add this list to our tally of all lists
                            if (ml.Tag[0].ToUpper().Contains("_SC-REACTIVEBILLINGONLY"))//_SC-SECURITY-
                            {
                                if (loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-REACTIVEBILLINGONLY")).Count() == 0)
                                {
                                    ml.LaborCategoryId = (int)MailingList.laborCategory.Reactive_Content_Billing;
                                    loadedLists.Add(ml);
                                }
                            }
                            else if (ml.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY"))
                            {
                                if (loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY")).Count() == 0)
                                {
                                    ml.LaborCategoryId = (int)MailingList.laborCategory.Proactive_Content_Billing;
                                    loadedLists.Add(ml);
                                }
                            }
                        }
                        // read Xml file
                    }


                    // store the mailing list
                    List<MailingList> lineItemNullList = loadedLists.Where(x => x.ServiceId == null || x.ServiceId == "").ToList<MailingList>();
                    if (lineItemNullList.Count() > 0)
                    {
                        foreach (MailingList ml in lineItemNullList)
                        {
                            AppendToFileLog("Mailing List Null LineItemID - AgreementId: " + ml.AgreementId + " " + "PackageId : " + ml.PackageId + ", LaborCategory: " + Enum.GetName(typeof(MailingList.laborCategory), ml.LaborCategoryId));
                            string status = string.Empty;//= new WriteToAzureStorage().CreateAzureTableEntity(ml, "Mailing List null ServiceId", "Business", null);
                                                         //appFile.WriteLine("ServiceId Null Post to Azure Storage" + status);
                            string applog2 = "ServiceId Null Post to Azure Storage" + status + Environment.NewLine;
                            // stream = new MemoryStream();
                            // Append new data to the MemoryStream
                            byte[] newData1 = Encoding.UTF8.GetBytes(applog2);
                            stream.Write(newData1, 0, newData1.Length);
                            // fileClient.Append(stream,1);


                        }
                    }

                    //  checking for null LineItemID, contractID , ScheduleID and Region, if present excluding from billing list
                    loadedLists.RemoveAll(x => (x.ServiceId == null) || (x.AgreementRegionId == 0) || (x.PackageId == null) || (x.AgreementId == null) || (x.ServiceId == "") ||
                    (x.PackageId == "") || (x.AgreementId == ""));
                    string applog3 = "Total loaded MLX Count after NUll check" + loadedLists.Count().ToString() + Environment.NewLine;

                    // stream = new MemoryStream();
                    // Append new data to the MemoryStream
                    byte[] newData2 = Encoding.UTF8.GetBytes(applog3);
                    stream.Write(newData2, 0, newData2.Length);
                    //stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(applog));
                    stream.Flush();

                    //                  stream.Seek(0, SeekOrigin.Begin);
                    //fileClient.Append(stream, 0);
                    //fileClient.Flush(stream.Length);
                    //stream.Seek(0, SeekOrigin.Begin);
                    // fileClient.Flush(stream.Length);
                    //  appFile.Flush();
                    // logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Successfully Read MLX files", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryMlxProperties);
                    //  loadedLists = loadedLists.Take(10).ToList<MailingList>();

                    // store the mailing list
                    string storingstatus = storeLoadedList(0, null);
                    if (loadedLists.Count > 0)
                    {
                        string applog = string.Empty;
                        var result = BatchProcessList(loadedLists, 0).GetAwaiter().GetResult();
                    }
                    else
                    {
                        string applog = "Exit due to error in StoredList" + Environment.NewLine;
                        byte[] newData4 = Encoding.UTF8.GetBytes(applog);
                        stream.Write(newData4, 0, newData4.Length);
                        //fileClient.Append(stream, 0);

                        //  appFile.WriteLine("Exit due to error in StoredList");
                        //  logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Exit due to error in StoredList", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);

                    }

                }
                else
                {
                    string applog = "No Mlx File found" + Environment.NewLine;
                    //string applog = "Exit due to error in StoredList";
                    byte[] newData4 = Encoding.UTF8.GetBytes(applog);
                    stream.Write(newData4, 0, newData4.Length);

                    //                  stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(applog));
                    //fileClient.Append(stream, 0);

                    // appFile.WriteLine("No Mlx File found");
                    //  logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Mlx Files not found", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);

                }
                //}
            }
            catch
            {

            }
            return LstMXLfile;
        }
        public static T DeserializeXmlData<T>(string xmlData)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using StringReader reader = new StringReader(xmlData);

            return (T)serializer.Deserialize(reader)!;
        }
        public async Task<List<MailingList>> GetMailingList(CancellationToken cancellationToken)
        {
            // Implementation for GetMailingList method
            return await Task.FromResult(new List<MailingList>());
        }
    }
}
