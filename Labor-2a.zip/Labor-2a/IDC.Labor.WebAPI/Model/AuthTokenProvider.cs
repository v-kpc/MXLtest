﻿using Microsoft.Identity.Client.AppConfig;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;



namespace AutomationLaborEntry.Model
{
    
        public class AuthTokenProvider
        {

        public  async virtual Task<string> AuthFI(string appClientId, string resourceTenantId, string scope)

        {

            Uri authorityUri = new Uri($"https://login.microsoftonline.com/{resourceTenantId}");

            IConfidentialClientApplication app = ConfidentialClientApplicationBuilder.Create(appClientId)

                     .WithAuthority(authorityUri, false)

                     .WithClientAssertion(Assertion)

                     .Build();

            string[] scopes = new string[] { scope };

            var result = await app.AcquireTokenForClient(scopes)

                              .ExecuteAsync();

            return result.AccessToken;


            async Task<string> Assertion(AssertionRequestOptions assertionRequestOptions)

            {

                string audience = "api://AzureADTokenExchange";

                var miApplication = ManagedIdentityApplicationBuilder

                        .Create(ManagedIdentityId.SystemAssigned)

                        .Build();

                var miResult = await miApplication.AcquireTokenForManagedIdentity(audience)

                    .ExecuteAsync();

                return miResult.AccessToken;

            }

        }
        /// <summary>
        /// Method for generating the AAD token
        /// </summary>
        /// <param name="authInput">authentication input</param>
        /// <returns></returns>
        //public async virtual Task<String> GetAadAccessTokenAsync(AuthInput authInput)
        //    {
        //        Guard(authInput);
        //        return await GetAadAccessToken(authInput.Authority, authInput.Resource, authInput.ClientId, authInput.ClientSecret);
        //    }

            /// <summary>
            /// method for generating the aad token
            /// </summary>
            /// <param name="authority">the AD Authority used for login</param>
            /// <param name="resource">the Application ID of the app you are going to call.  This is a guid you can get from the Advanced Settings of your Auth setup for the targetapp in the portal</param>
            /// <param name="clientId">the Application ID of this app.  This is a guid you can get from the Advanced Settings of your Auth setup in the portal</param>
            /// <param name="clientSecret">the key you generate in Azure Active Directory for this application</param>
            /// <returns></returns>
            private async Task<String> GetAadAccessToken(string authority, string resource, string clientId, string clientSecret)
            {
                try
                {
                    var clientCredential = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(clientId, clientSecret);
                    AuthenticationContext context = new AuthenticationContext(authority, false);
                    Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationResult authenticationResult = await context.AcquireTokenAsync(resource, clientCredential);
                    return $"Bearer {authenticationResult.AccessToken}";
                }
                catch
                {
                    throw;
                }
            }



       private  async Task<string> Assertion(AssertionRequestOptions assertionRequestOptions)
        {
            string audience = "api://AzureADTokenExchange";

            var miApplication = ManagedIdentityApplicationBuilder
                    .Create(ManagedIdentityId.SystemAssigned)
                    .Build();

            var miResult = await miApplication.AcquireTokenForManagedIdentity(audience)
                .ExecuteAsync();

            return miResult.AccessToken;
        }
        /// <summary>
        /// This will check the mandatory items of the input 
        /// </summary>
        /// <param name="authInput">auth input</param>
        private void Guard(AuthInput authInput)
            {
                if (null == authInput)
                {
                    throw new ArgumentNullException(nameof(authInput));
                }

                if (string.IsNullOrEmpty(authInput.Authority))
                {
                    throw new ArgumentNullException(nameof(authInput.Authority));
                }

                if (string.IsNullOrEmpty(authInput.ClientId))
                {
                    throw new ArgumentNullException(nameof(authInput.ClientId));
                }

                //if (string.IsNullOrEmpty(authInput.ClientSecret))
                //{
                //    throw new ArgumentNullException(nameof(authInput.ClientSecret));
                //}

                if (string.IsNullOrEmpty(authInput.Resource))
                {
                    throw new ArgumentNullException(nameof(authInput.Resource));
                }
            }



        }

   

    }

