﻿namespace AutomationLaborEntry.Model
{
    public class BusinessError
    {
        public enum errorCategory
        {
            AuthenticationError,
            ModelValidationError,
            BusinessRuleError,
            TimeoutError,
            UnhandledError,
            NotFoundError,
            InvalidParametersError,
            NotApplicable
        }
    }
}
