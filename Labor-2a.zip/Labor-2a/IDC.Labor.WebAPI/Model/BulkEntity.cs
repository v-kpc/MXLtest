﻿
using Azure;
using Azure.Data.Tables;
using System;
namespace AutomationLaborEntry.Model
{
    public class BulkEntity : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        public string AgreementID { get; set; }
        public string Country { get; set; }
        public string PackageID { get; set; }
        public string ServiceID { get; set; }
        public string LaborCategory { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorType { get; set; }
        public string CorrelationID { get; set; }
        public string TransactionID { get; set; }
        public string LaborID { get; set; }
        public string BulkCorrelationID { get; set; }
        public string BulkSubCorrelationID { get; set; }
        public string OperationID { get; set; }

    }
}
