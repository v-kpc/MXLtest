﻿namespace AutomationLaborEntry.Model
{
    public class MXLDownloadfile
    {

        private string newsletter;
        private string mlxfile;
        public string Newsletter
        {
            get { return newsletter; }
            set { newsletter = value; }
        }

        public string MLXfile
        {
            get { return mlxfile; }
            set { mlxfile = value; }
        }


    }
}
