﻿using AutomatedLaborEntry.Model.BulkSubmitResponse;

namespace IDC.Labor.WebAPI.Model
{
    public class TopicSend
    {

        public Context context { get; set; }
        public string resourceUrl { get; set; }
    }
}
