﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace AutomatedLaborEntry.Model.BulkSubmitResponse
{

    public class Rootobject
{
    public Response response { get; set; }
    public object[] serviceMessages { get; set; }
}

public class Response
{
    public Context context { get; set; }
    public Datum[] data { get; set; }
}

public class Context
{
    public string correlationId { get; set; }

        [AllowNull]
        public string subCorrelationId { get; set; } 
        public string operationId { get; set; } 
    public string operationType { get; set; }
        
        [AllowNull]
    public string requestOriginator { get; set; } 

        [AllowNull]
  public string originatingSystem { get; set; }
    public string status { get; set; }
}

public class Datum
{
    public Context1 context { get; set; }
    public Data data { get; set; }
}

public class Context1
{
    public string correlationId { get; set; }
    public string transactionalId { get; set; }
}

public class Data
{
    public Response1 response { get; set; }
    public Servicemessage[] serviceMessages { get; set; }
}

public class Response1
{
    public Partnerspecificattribute partnerSpecificAttribute { get; set; }
    public string laborId { get; set; }
    public DateTime laborDate { get; set; }
    public string laborHours { get; set; }
    public int laborTimeZoneId { get; set; }
    public int laborCategoryId { get; set; }
    public string submittedFor { get; set; }
    public string submittedBy { get; set; }
    public DateTime submittedDateInUtc { get; set; }
    public string laborNotes { get; set; }
    public string laborStatus { get; set; }
    public string partner { get; set; }
    public Assignmentdetails assignmentDetails { get; set; }
    public string updatedBy { get; set; }
    public DateTime updatedDateTimeInUtc { get; set; }
    public string eTag { get; set; }
    public string id { get; set; }
    public string errorMessage { get; set; }
    public string exceptionIdentifier { get; set; }
    public string errorCategory { get; set; }
}

public class Partnerspecificattribute
{
    public string chargedLabor { get; set; }
}

public class Assignmentdetails
{
    public Int64 agreementId { get; set; }
    public Int64 packageId { get; set; }
    public Int64 serviceId { get; set; }
    public int regionId { get; set; }
}

public class Servicemessage
{
    public string type { get; set; }
    public string errorCategory { get; set; }
    public string message { get; set; }
    public string partnerId { get; set; }
}

}
