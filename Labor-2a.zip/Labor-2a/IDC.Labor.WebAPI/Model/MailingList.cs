﻿using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace AutomationLaborEntry.Model
{
    public class MailingList
    {
        public string Service { get; set; }

        [XmlAttribute("Name")]
        public string Name { get; set; }

        private string[] tags;
        [XmlElement("Tag")] // Even if same name, have to specify to force type conversion
        public string[] Tag
        {
            get { return tags; }
            set { tags = SplitIfSemicolon(value, false); }
        }

        private int laborCategoryId;
        [XmlElement("LaborCategoryId")] // Even if same name, have to specify to force type conversion
        public int LaborCategoryId
        {
            get { return laborCategoryId; }
            set { laborCategoryId = value; }
        }


        private string agreementId;
        [XmlElement("AgreementId")]
        public string AgreementId
        {
            get { return agreementId; }
            set { agreementId = value; }
        }

        private string packageId;
        [XmlElement("PackageId")]
        public string PackageId
        {
            get { return packageId; }
            set { packageId = value; }
        }

        private string serviceId;
        [XmlElement("ServiceId")]
        public string ServiceId
        {
            get { return serviceId; }
            set { serviceId = value; }
        }

        //private string lineItem;
        //[XmlElement("LineItem")]
        //public string LineItem
        //{
        //    get { return lineItem; }
        //    set { lineItem = value; }
        //}

        private int agreementRegionId;
        [XmlElement("AgreementRegionId")]
        public int AgreementRegionId
        {
            get { return agreementRegionId; }
            set { agreementRegionId = value; }
        }
        private int index;
        public int Index
        {
            get { return index; }
            set { index = value; }
        }
        private Guid _Guid;
        [XmlElement("GUID")]
        public Guid GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        private string agreementCountry;
        [XmlElement("AgreementCountry")]
        public string AgreementCountry
        {
            get { return agreementCountry; }
            set { agreementCountry = value; }
        }

        private string status;
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        private string laborId;
        public string LaborId
        {
            get { return laborId; }
            set { laborId = value; }
        }

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        private string transactionId;
        public string TransactionId
        {
            get { return transactionId; }
            set { transactionId = value; }
        }

        private string operationId;
        public string OperationId
        {
            get { return operationId; }
            set { operationId = value; }
        }

        private string bulkCorrelationId;
        public string BulkCorrelationId
        {
            get { return bulkCorrelationId; }
            set { bulkCorrelationId = value; }
        }

        private string bulkSubCorrelationId;
        public string BulkSubCorrelationId
        {
            get { return bulkSubCorrelationId; }
            set { bulkSubCorrelationId = value; }
        }

        // public object InvalidEmailAddresses { get; private set; }

        // Tally total messages to be sent for stats
        // TODO: Expose Delimiter as a setting
        /// <summary>
        /// Function which given a delimited list by semicolon returns an expanded array with one value per entry.
        /// 
        /// If the value is already an array, return the array.
        /// </summary>
        /// <param name="input">Is an Array due to desired object type vs. XmlSerialization, will be loaded as a 0 or 1 element array with the value passed in if it exists.</param>
        /// <returns></returns>
        private string[] SplitIfSemicolon(string[] input, bool email = true)
        {
            if (input == null)
                return null;

            // If we don't have a list separated by semi-colons, just keep value as is
            if (input.Length == 1)
            {
                if (string.IsNullOrWhiteSpace(input[0]))
                {
                    return null;
                }
                else if (input[0].Contains(';'))
                {
                    // Otherwise, we split into an array of addresses
                    string[] list = input[0].Trim().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    List<string> final = new List<string>(); // TODO: think about if we can re-use list like we did before more
                    for (int x = 0; x < list.Length; x++)
                    {
                        string na = email ? CleanEmailAddress(list[x]) : list[x].Trim(); // Want to ensure we don't have extra space at begining or end of values, otherwise would just return Split.
                        if (!string.IsNullOrWhiteSpace(na))
                        {
                            final.Add(na);
                        }
                    }
                    return final.ToArray();
                }
                else
                {
                    // Sanitize single value
                    input[0] = email ? CleanEmailAddress(input[0]) : input[0].Trim();
                }
            }
            // If we have no data, just return null
            else if (input.Length == 0)
            {
                return null;
            }

            return input;
        }
        /// <summary>
        /// Function to 'clean' E-mail addresses from Heading format 'Name (E-mail)' type format to just be an e-mail address.
        /// 
        /// Deals with 
        ///   &gt;Name&lt; (e-mail)
        ///   Name (e-mail)
        ///   Name &gt;e-mail&lt;
        /// 
        /// TODO: Work with addresses on left-side of name?
        /// </summary>
        /// <param name="address"></param>
        /// <returns>null if e-mail is invalid, otherwise cleaned e-mail address</returns>
        private string CleanEmailAddress(string address)
        {
            address = address.Trim();
            if (address.Length == 0)
            {
                // If blank address, then we had a space after the semi-colon probably, so just ignore this one, but don't log error.
                // Should be the case now as added a Trim above, but just in-case there's one inbetween.
                return null;
            }

            if (address.Contains(" ")) // Legal addresses can contain spaces in quotes, but should be uncommon, we'll assume that it means we've got a full header style name+address
            {
                address = address.Substring(address.LastIndexOf(" ")).Trim(); // Assume address is on the right side.
            }

            if (address.StartsWith("(") || address.StartsWith("<")) // GetBulkCompletion rid of start of bracket
            {
                address = address.Substring(1);
            }
            if (address.EndsWith(")") || address.EndsWith(">")) // End of Bracket
            {
                address = address.Substring(0, address.Length - 1);
            }

            if ((address.StartsWith("'") && address.EndsWith("'")) || // GetBulkCompletion rid of quotes surrounding address in bracket
                (address.StartsWith("\"") && address.EndsWith("\"")))
            {
                address = address.Substring(1, address.Length - 2);
            }

            // Check for valid mail address translation here and report error on fail
            //string regexPattern = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z_]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";
            string regexPattern = @"[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?";
            //string regexPattern = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z_~!#$&*+'?-]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";
            Match matches = Regex.Match(address, regexPattern, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            if (!matches.Success)
            {
                try
                {
                    MailAddress ma = new MailAddress(address);
                    //  InvalidEmailAddresses.Add(new Tuple<string, string>(address, "an invalid address"));
                    return null;
                }
                catch (Exception e)
                {
                    //  InvalidEmailAddresses.Add(new Tuple<string, string>(address, e.Message));
                    return null;
                }
            }

            return address.Trim();
        }

        public enum laborCategory
        {
            Proactive_Content_Billing = 847942,
            Reactive_Content_Billing = 847984,
            SAC_Bulk_Labor = 847909,
            Japan_Information_Curation = 847915
        }

    }

    [XmlRoot("Tag", Namespace = "")]
    public class MailingTagList
    {
        [XmlElement("MailingList")]
        public List<MailingList> MailingLists { get; set; }

        [XmlAttribute("Name")]
        public string Name { get; set; }

    }
}
