﻿namespace AutomationLaborEntry.Model
{
    public class data
    {
        private Guid _correlationId;

        public Guid correlationId { get { return _correlationId; } set { _correlationId = value; } }
    }

    public class ActionDetail
    {
        public string actionType { get; set; }
        public Int64 reasonId { get; set; }
        public string comments { get; set; }
    }
    public class LaborEntry
    {
        private DateTime _laborDate;
        private TimeSpan _laborHours;
        private int _timeZoneID;
        private int _laborCategoryID;
        private string _submittedFor;
        private string _submittedBy;
        private string _laborNotes;
        private string _partner;
        private AssignmentDetails _assignmentDetails;
        private DateTime _updatedDateInUtc;
        //private ActionDetail _actionDetail;
        private partnerSpecificAttributecs _partnerSpecificAttributes;

        // private string _regionName;
        //  private string _tagName;
        //  private Guid _correlationId;

        public DateTime laborDate { get { return _laborDate; } set { _laborDate = value; } }
        public TimeSpan laborHours { get { return _laborHours; } set { _laborHours = value; } }
        public int laborTimeZoneId { get { return _timeZoneID; } set { _timeZoneID = value; } }
        public int laborCategoryId { get { return _laborCategoryID; } set { _laborCategoryID = value; } }
        public string submittedFor { get { return _submittedFor; } set { _submittedFor = value; } }
        public string submittedBy { get { return _submittedBy; } set { _submittedBy = value; } }
        public string laborNotes { get { return _laborNotes; } set { _laborNotes = value; } }
        public string partner { get { return _partner; } set { _partner = value; } }
        public DateTime updatedDateInUtc { get { return _updatedDateInUtc; } set { _updatedDateInUtc = value; } }
        public ActionDetail[] actionDetails { get; set; }  // for late submission
        //public string TagName { get => _tagName; set => _tagName = value; }
        //  public string RegionName { get => _regionName; set => _regionName = value; }
        public AssignmentDetails assignmentDetails { get { return _assignmentDetails; } set { _assignmentDetails = value; } }
        public partnerSpecificAttributecs partnerSpecificAttribute { get { return _partnerSpecificAttributes; } set { _partnerSpecificAttributes = value; } }
        //public string etag { get => _etag; set => _etag = value; }

        //public Guid id { get => _id; set => _id = value; }

        // public Guid CorrelationId { get => _correlationId; set => _correlationId = value; }

        public LaborEntry()
        {
            // AssignmentDetails = new AssignmentDetails();
            // PartnerSpecificAttributes = new partnerSpecificAttributecs();
        }


    }
}
