﻿namespace AutomationLaborEntry.Model
{
    public class AuthInput
    {
        /// <summary>
        /// the AD Authority used for login.  For example: https://login.microsoftonline.com/myadnamehere.onmicrosoft.com 
        /// </summary>
        public string Authority { get; set; }
        /// <summary>
        /// the Application ID of this app.  This is a guid you can get from the Advanced Settings of your Auth setup in the portal
        /// </summary>
        public string ClientId { get; set; }

        public string TentantId { get; set; }
        /// <summary>
        /// the key you generate in Azure Active Directory for this application
        /// </summary>
        //public string ClientSecret { get; set; }
        /// <summary>
        /// the Application ID of the app you are going to call.  This is a guid you can get from the Advanced Settings of your Auth setup for the targetapp in the portal
        /// </summary>
        public string Resource { get; set; }

        public Task<string> GetAccess(string ClientId, string TentantId, string Resource)
        {
            Task<string> _accessToken = null;
            try
            {
              
                AuthTokenProvider authTokenProvider = new AuthTokenProvider();
                //_accessToken = authTokenProvider.GetAadAccessTokenAsync(auth);
                _accessToken = authTokenProvider.AuthFI(ClientId,TentantId,Resource);
            }
            catch (Exception exe)
            {
                //LaborLogging.telemetryClient.TrackException(exe);
                throw exe;
            }
            return _accessToken;
        }
    }
}
