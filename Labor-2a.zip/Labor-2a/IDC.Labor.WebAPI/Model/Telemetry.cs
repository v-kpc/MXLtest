﻿
using System.Collections.Generic;

namespace AutomationLaborEntry.Model
{
    public class Telemetry
    {
        public Telemetry()
        {
            // telemetryClient = new TelemetryClient();
            telemetryMlxProperties = new Dictionary<string, string>();
            telemetryLaborProperties = new Dictionary<string, string>();
            telemetryCountProperties = new Dictionary<string, string>();
            telemetryAppErrorProperties = new Dictionary<string, string>();
            telemetryOperationProperties = new Dictionary<string, string>();
            telemetryNullItemPropertiesProperties = new Dictionary<string, string>();
        }
        // public TelemetryClient telemetryClient;
        public Dictionary<string, string> telemetryMlxProperties { get; set; }
        public Dictionary<string, string> telemetryLaborProperties { get; set; }
        public Dictionary<string, string> telemetryCountProperties { get; set; }
        public Dictionary<string, string> telemetryAppErrorProperties { get; set; }
        public Dictionary<string, string> telemetryOperationProperties { get; set; }
        public Dictionary<string, string> telemetryHttpPostProperties { get; set; }
        public Dictionary<string, string> telemetryNullItemPropertiesProperties { get; set; }



        public TelemetrySettings SetTelemetrySettings()
        {
            TelemetrySettings set = new TelemetrySettings();
            set.EnvironmentInformation = new EnvironmentInformation();
            set.EnvironmentInformation.EnvironmentName = "Production";
            set.EnvironmentInformation.ComponentName = "Service Center";
            set.EnvironmentInformation.SubComponentName = "Automated Labor Entry";
            set.EnvironmentInformation.ServiceOffering = "Service Center";
            set.EnvironmentInformation.Service = "Service";
            return set;
        }


    }
}
