﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AutomationLaborEntry.Model
{
    public class Data
    {

        public Data()
        {
            context = new data();
        }
        public data context { get { return _context; } set { _context = value; } }
        private data _context;
        //public LaborEntry _data;
        public LaborEntry data { get; set; }
    }
}
