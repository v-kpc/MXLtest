﻿namespace AutomationLaborEntry.Model
{
    public class Context
    {
        public string correlationId
        {
            get; set;
        }
        public string subCorrelationId
        {
            get; set;
        }
        public string operationId
        {
            get; set;
        }
        public string operationType
        {
            get; set;
        }
        public string requestOriginator
        {
            get; set;
        }
        public string originatingSystem
        {
            get; set;
        }
        public string status { get; set; }
        //public string transactionId
        //{
        //    get; set;
        //}
    }

}
