﻿using System.Collections.ObjectModel;

namespace AutomationLaborEntry.Model
{
    public class BulkSubmit
    {
        private BulkSubmitHeader _context { get; set; }
        // private Data _data;

        public BulkSubmitHeader context { get { return _context; } set { _context = value; } }
        //internal Data Data { get ; set; }
        public ObservableCollection<Data> data { get; set; }
    }
}
