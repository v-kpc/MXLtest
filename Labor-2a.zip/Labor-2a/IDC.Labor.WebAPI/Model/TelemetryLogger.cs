﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Logging;
//using Msit.Telemetry.Extensions;
//using Msit.Telemetry.Extensions.AI;
using System;
using System.Collections.Generic;

namespace AutomationLaborEntry.Model
    {
        /// <summary>
        /// A logger that writes messages in the application insights only when telemetry is enabled.
        /// </summary>
        public class TelemetryLogger
        {
            /// <summary>
            /// The telemetry client
            /// </summary>
            private readonly TelemetryClient _telemetryClient;

            /// <summary>
            /// The telemetry setttings
            /// </summary>
            private readonly TelemetrySettings _telemetrySetttings;

            /// <summary>
            /// Initializes a new instance of the <see cref="TelemetryLogger"/> class.
            /// </summary>
            /// <param name="client">telemetry client</param>
            /// <param name="name">The name of the logger.</param>
            /// <param name="filter">The function used to filter events based on the log level.</param>
            public TelemetryLogger(TelemetryConfiguration telemetryConfiguration, TelemetrySettings telemetrySetttings)
            {
                Guard.ArgumentNotNull(telemetryConfiguration, nameof(telemetryConfiguration));
                Guard.ArgumentNotNull(telemetrySetttings, nameof(telemetrySetttings));

                telemetrySetttings.InstrumentationKey = telemetryConfiguration.InstrumentationKey;
               // AddTelemetryInitializers(telemetryConfiguration, telemetrySetttings);

                this._telemetryClient = new TelemetryClient(telemetryConfiguration);
                this._telemetrySetttings = telemetrySetttings;
            }

            /// <summary>
            /// Adds the telemetry initializers.
            /// </summary>
            /// <param name="telemetryConfiguration">The telemetry configuration.</param>
            /// <param name="telemetrySetttings">The telemetry setttings.</param>
           

            /// <inheritdoc />
            public IDisposable BeginScope<TState>(TState state)
            {
                return null;
            }

            /// <summary>
            /// Checks if the given <paramref name="logLevel" /> is enabled.
            /// </summary>
            /// <param name="logLevel">level to be checked.</param>
            /// <returns>
            ///   <c>true</c> if enabled.
            /// </returns>
            public bool IsEnabled(LogLevel logLevel)
            {
                return this._telemetryClient != null && this.IsEnabledFilter(logLevel) && this._telemetryClient.IsEnabled();
            }


            /// <summary>
            /// Converts to severity level.
            /// </summary>
            /// <param name="logLevel">The log level.</param>
            /// <returns></returns>
            private static SeverityLevel ConvertToSeverityLevel(LogLevel logLevel)
            {
                switch (logLevel)
                {
                    case LogLevel.Information:
                        return SeverityLevel.Information;
                    case LogLevel.Warning:
                        return SeverityLevel.Warning;
                    case LogLevel.Error:
                        return SeverityLevel.Error;
                    case LogLevel.Critical:
                        return SeverityLevel.Critical;
                    case LogLevel.Trace:
                    case LogLevel.Debug:
                    default:
                        return SeverityLevel.Verbose;
                }
            }

            /// <summary>
            /// Determines whether [is enabled filter] [the specified log level].
            /// </summary>
            /// <param name="logLevel">The log level.</param>
            /// <returns>
            ///   <c>true</c> if [is enabled filter] [the specified log level]; otherwise, <c>false</c>.
            /// </returns>
            private bool IsEnabledFilter(LogLevel logLevel)
            {
                switch (logLevel)
                {
                    case LogLevel.Trace:
                    case LogLevel.Debug:
                    case LogLevel.Information:
                        return _telemetrySetttings.IsInfoEnabled;
                    case LogLevel.Warning:
                        return _telemetrySetttings.IsWarnEnabled;
                    case LogLevel.Error:
                        return _telemetrySetttings.IsErrorEnabled;
                    case LogLevel.Critical:
                        return _telemetrySetttings.IsFatalEnabled;
                    case LogLevel.None:
                    default:
                        return true;
                }

            }

            ///// <summary>
            ///// Messages the formatter.
            ///// </summary>
            ///// <param name="state">The state.</param>
            ///// <param name="error">The error.</param>
            ///// <returns></returns>
            //private static string MessageFormatter(object state, Exception error)
            //{
            //    var message = new StringBuilder();

            //    if (error != null)
            //    {
            //        var trace = state as Trace;

            //        message.AppendLine($"Error Message: {trace?.Message ?? error.Message} {Environment.NewLine} Inner message: {error.InnerException?.Message}");
            //    }

            //    message.Append($"{state?.ToString()}");

            //    return message.ToString();
            //}

            /// <summary>
            /// MSIT Business process event logging. This should be used to log an event that operates on a business object.
            /// </summary>
            /// <param name="businessProcessEvent">The business process event.</param>
            /// <param name="properties">[Optional] A collection of properties that should be associated to the telemetry entry</param>
            /// <param name="metrics">[Optional] A collection of metrics that should be associated to the telemetry</param>
            //public void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent)
            //{
            //    this._telemetryClient.TrackBusinessProcessEvent(businessProcessEvent);
            //}

            /// <summary>
            /// MSIT Business process event logging. This should be used to log an event that operates on a business object.
            /// </summary>
            /// <param name="businessProcessEvent">The business process event.</param>
            /// <param name="properties">[Optional] A collection of properties that should be associated to the telemetry entry</param>
            //public void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent, Dictionary<string, string> properties)
            //{
            //    this._telemetryClient.TrackBusinessProcessEvent(businessProcessEvent, properties);
            //}

            ///// <summary>
            /// Tracks the business event.
            /// </summary>
            /// <param name="businessProcessEvent">The business process event.</param>
            /// <param name="properties">The properties.</param>
            /// <param name="metrics">The metrics.</param>
            //public void TrackBusinessEvent(BusinessProcessEvent businessProcessEvent, Dictionary<string, string> properties, Dictionary<string, double> metrics)
            //{
            //    this._telemetryClient.TrackBusinessProcessEvent(businessProcessEvent, properties, metrics);
            //}

            ///// <summary>
            ///// MSIT Feature usage logging. This should be used to log usage of any user facing feature.
            ///// </summary>
            ///// <param name="eventName">The name of the event that is happening</param>
            ///// <param name="componentType">What type of component are you</param>
            ///// <param name="componentUri">What is the path to your feature i.e. Api url or app page path</param>
            ///// <param name="userRole">[Optional] What is the role name of the user using this feature</param>
            ///// <param name="durationInMS">[Optional] How long was the feature used in milliseconds </param>
            ///// <param name="properties">[Optional] A collection of properties that should be associated to the telemetry entry</param>
            ///// <param name="metrics">[Optional] A collection of metrics that should be associated to the telemetry</param>
            //public void TrackFeatureEvent(string eventName, ComponentType componentType, string componentUri, string userRole, double durationInMS, Dictionary<string, string> properties, Dictionary<string, double> metrics)
            //{
            //    var eventData = new FeatureUsageEvent(eventName, componentType);
            //    eventData.ComponentUri = componentUri;
            //    eventData.Duration = durationInMS;
            //    eventData.UserRoleName = userRole;
            //    this._telemetryClient.TrackFeatureUsageEvent(eventData, properties, metrics);
            //}

            /// <summary>
            /// Send a Microsoft.ApplicationInsights.DataContracts.MetricTelemetry for aggregation in Metric Explorer.
            /// </summary>
            /// <param name="name">Metric name.</param>
            /// <param name="value">Metric value.</param>
            /// <param name="properties">Named string values you can use to classify and filter metrics.</param>
            public void TrackMetricEvent(string name, double value, Dictionary<string, string> properties)
            {
                this._telemetryClient.TrackMetric(name, value, properties);
            }

            /// <summary>
            /// Send a Microsoft.ApplicationInsights.DataContracts.RequestTelemetry for aggregation in Request Explorer.
            /// </summary>
            /// <param name="telemetry">request telemetry</param>
            public void TrackRequest(RequestTelemetry telemetry)
            {
                this._telemetryClient.TrackRequest(telemetry);
            }


            public void TrackDependency(string dependencyTypeName, string target, string dependencyName, string data, DateTimeOffset startTime, TimeSpan duration, string resultCode, bool success)
            {
                this._telemetryClient.TrackDependency(dependencyTypeName, target, dependencyName, data, DateTime.Now, duration, resultCode, success);
            }

            public void TrackDependency(string dependencyType, string dependencyName, string target, string resultCode, string command, TimeSpan duration, bool success, Dictionary<string, string> customProperties)
            {
                DependencyTelemetry dependencyTelemetry = new DependencyTelemetry()
                {
                    Type = dependencyType,
                    Name = dependencyName,
                    Data = command,
                    Duration = duration,
                    Success = success,
                    Target = target,
                    ResultCode = resultCode
                };

                if (customProperties != null)
                {
                    foreach (var item in customProperties)
                    {
                        dependencyTelemetry.Properties.Add(item.Key, item.Value);
                    }
                }

                this._telemetryClient.TrackDependency(dependencyTelemetry);
            }

            /// <summary>
            /// Flushes the in-memory buffer and any metrics being pre-aggregated.
            /// </summary>
            public void Flush()
            {
                _telemetryClient.Flush();
            }
        }
    }


