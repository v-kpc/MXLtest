﻿using AutomatedLaborEntry.Model.BulkSubmitResponse;

namespace AutomatedLaborEntry.Model
{
    public class TopicMessage
    {
        public Context context { get; set; }
        public string resourceUrl { get; set; }
        //public Response response { get; set; }
        //  [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        //   public List<ServiceMessages> ServiceMessages { get; set; }
    }
}
