﻿namespace AutomationLaborEntry.Model
{
    public sealed class TelemetrySettings
    {
        /// <summary>
        /// Gets the instrumentation key.
        /// </summary>
        /// <value>
        /// The instrumentation key.
        /// </value>

        public string InstrumentationKey { get; set; }

        /// <summary>
        /// Gets the correlation header key.
        /// </summary>
        /// <value>
        /// The correlation header key.
        /// </value>

        public string CorrelationHeaderKey { get; private set; }

        /// <summary>
        /// Gets the sub correlation header key.
        /// </summary>
        /// <value>
        /// The sub correlation header key.
        /// </value>

        public string SubCorrelationHeaderKey { get; private set; }

        /// <summary>
        /// Gets a value indicating whether this instance is sampling enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is sampling enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsSamplingEnabled { get; private set; } = false;

        /// <summary>
        /// Gets the personally identifiable information fields to exclude.
        /// </summary>
        /// <value>
        /// The personally identifiable information fields to exclude.
        /// </value>
        public string[] PiiFieldsToExclude { get; private set; }

        /// <summary>
        /// Gets the pii reg ex to exlude.
        /// </summary>
        /// <value>
        /// The pii reg ex to exlude.
        /// </value>
        public string[] PiiRegExToExlude { get; private set; }

        /// <summary>
        /// Gets the environment information.
        /// </summary>
        /// <value>
        /// The environment information.
        /// </value>

        public EnvironmentInformation EnvironmentInformation { get; set; }

        /// <summary>
        /// Gets a value indicating whether this instance is information Enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is information Enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsInfoEnabled { get; private set; } = true;

        /// <summary>
        /// Gets a value indicating whether this instance is warn Enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is warn Enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsWarnEnabled { get; private set; } = true;

        /// <summary>
        /// Gets a value indicating whether this instance is error Enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is error Enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsErrorEnabled { get; private set; } = true;

        /// <summary>
        /// Gets a value indicating whether this instance is fatal Enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is fatal Enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsFatalEnabled { get; private set; } = true;


    }

    public class EnvironmentInformation
    {
        /// <summary>
        /// Gets the name of the environment.
        /// </summary>
        /// <value>
        /// The name of the environment.
        /// </value>

        public string EnvironmentName { get; set; }

        /// <summary>
        /// Gets the service offering(L1).
        /// </summary>
        /// <value>
        /// The service offering.
        /// </value>

        public string ServiceOffering { get; set; }

        /// <summary>
        /// Gets the service line(L2).
        /// </summary>
        /// <value>
        /// The service line.
        /// </value>

        public string ServiceLine { get; set; }

        /// <summary>
        /// Gets the service(L3).
        /// </summary>
        /// <value>
        /// The service.
        /// </value>

        public string Service { get; set; }

        /// <summary>
        /// Gets the component identifier.
        /// </summary>
        /// <value>
        /// The component identifier.
        /// </value>

        public string ComponentId { get; set; }

        /// <summary>
        /// Gets the name of the component.
        /// </summary>
        /// <value>
        /// The name of the component.
        /// </value>

        public string ComponentName { get; set; }

        /// <summary>
        /// Gets the name of the SubComponentName.
        /// </summary>
        /// <value>
        /// The name of the SubComponentName.
        /// </value>

        public string SubComponentName { get; set; }

    }
}
