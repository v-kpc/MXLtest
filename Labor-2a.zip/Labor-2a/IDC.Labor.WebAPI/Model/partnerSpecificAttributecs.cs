﻿namespace AutomationLaborEntry.Model
{
    public class partnerSpecificAttributecs
    {
        private TimeSpan _chargedLabor;

        public TimeSpan chargedLabor { get { return _chargedLabor; } set { _chargedLabor = value; } }
    }
}
