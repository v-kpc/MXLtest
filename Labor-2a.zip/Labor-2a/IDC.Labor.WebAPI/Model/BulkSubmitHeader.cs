﻿namespace AutomationLaborEntry.Model
{
    public class BulkSubmitHeader
    {
        public Guid operationID { get; set; }
        public string type { get; set; }
        public DateTime originatingDateTimeInUtc { get; set; }
    }
}
