using AutomationLaborEntry.Interface;
using AutomationLaborEntry;
using System.Fabric.Query;
using Autofac.Core;
using System.Configuration;
using IDC.Labor.Infrastructure;
using IDC.Labor.Infrastructure.Database;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using IDC.Common.Authentication;
using IDC.Common.Tools.Authentication;
using BulkCompletionEvent;
using IDC.Labor.WebAPI.Interface;
using IDC.Labor.ApiClient.Models;
using IDC.Common.Tools.Validation;
using IDC.Labor.WebAPI.Validation;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//builder.Services.AddScoped<ITokenProvider, TokenProvider>();
builder.Services.AddScoped<ILaborLogging, LaborLogging>();
builder.Services.AddScoped<IProcessTransaction, ProcessTransaction>();
builder.Services.AddScoped<IValidator<PatchLaborBulkCompletionRequestDto>, PatchLaborBulkCompletionRequestDtoValidator>();

builder.Services.AddTokenProvider();
//builder.Services.AddScoped<ITokenProvider, TokenProvider>();
builder.Services.AddInfrastructureModule(builder.Configuration, false);

builder.Configuration
    .SetBasePath(Directory.GetCurrentDirectory())
   // .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
    .AddEnvironmentVariables()
    .AddCommandLine(args);

var app = builder.Build();
var mySetting = builder.Configuration["MySettingKey"];

// Apply migrations
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<LaborDbContext>();
    dbContext.Database.Migrate();
}

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();



app.Run();
