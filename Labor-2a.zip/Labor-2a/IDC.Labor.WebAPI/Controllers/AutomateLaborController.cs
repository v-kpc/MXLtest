﻿using AutomationLaborEntry.Model;
using Microsoft.AspNetCore.Mvc;
using AutomationLaborEntry.Interface;
using IDC.Common.Model;
using IDC.Labor.ApiClient.Models;
using IDC.Labor.Infrastructure.Repositories;
using FluentResults.Extensions;
using IDC.Labor.WebAPI.Mapping;
using IDC.Common.Tools.Extensions.FluentResultExtensions;
using IDC.Common.Tools.Contract;
using IDC.Labor.WebAPI.Interface;
using AutomatedLaborEntry.Model;
using IDC.Labor.Infrastructure.Database.Model;
using FluentResults;
using IDC.Common.Tools.Validation;
namespace AutomationLaborEntry.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AutomateLaborController : ControllerBase
    {
        private readonly ILogger<AutomateLaborController> _logger;
        private readonly ILaborLogging _laborlogging;
        private readonly ILaborRepository _laborRepository;
        private readonly IProcessTransaction _processTransaction;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="laborlogging"></param>
        public AutomateLaborController(ILogger<AutomateLaborController> logger, ILaborLogging laborlogging, ILaborRepository laborRepository, IProcessTransaction processTransaction)
        {
            _logger = logger;
            _laborlogging = laborlogging;
            _laborRepository = laborRepository;
            _processTransaction = processTransaction;
        }
  
      [HttpPost("GetAutomationLaborEntry")]
        public List<string> GetAutomationLaborEntry([FromBody] List<MXLDownloadfile> mXLDownloadfiles)
        {
            _laborlogging.GetMXLfiles(mXLDownloadfiles, CancellationToken.None);
            return new List<string>();
        }


        [HttpPost("ProcessBulkcompletion")]
        public async Task <List<string>> BulkCompletion([FromBody] TopicMessage message)
        {

         //   message.context.
           await _processTransaction.GetTransaction(message);
            return new List<string>();
        }
        [HttpPost("insert-bulk-completion")]
        public Task<Result> Insertbulk([FromBody] LaborBulkCompletion request)
        {
            var test = _laborRepository.InsertBulkCompletion(request,CancellationToken.None);
            return test;
        }

        [HttpPost("find-bulk-completion")]
        public async Task<IActionResult> FindBulkCompletion([FromBody] FindLaborBulkCompletionRequestDto request)
        {
            return await _laborRepository.FindLaborBulkCompletionByCriteria(request.LaborCategory, request.ErrorType, request.StartDate, request.EndDate, request.PageIndex, request.PageSize, CancellationToken.None)
                .Bind(result => new PaginatedList<LaborBulkCompletionDto>(result.Items.Select(LaborBulkCompletionMapper.MapToDto).ToList(), result.PageIndex, result.PageSize, result.TotalCount, result.TotalPages).AsResult())
                .MapAsync<PaginatedList<LaborBulkCompletionDto>, IActionResult>(success => ApiResultFactory.Success(success, System.Net.HttpStatusCode.OK),
                 errors => errors.First() switch
                 {
                     _ => ApiResultFactory.Error<PaginatedList<LaborBulkCompletionDto>>(System.Net.HttpStatusCode.InternalServerError, string.Join(", ", errors.First().Reasons))
                 });
        }

        [HttpPatch("patch-bulk-completion/{id}")]
        public async Task<IActionResult> PatchBulkCompletion(Guid id, [FromBody] PatchLaborBulkCompletionRequestDto request, [FromServices] IValidator<PatchLaborBulkCompletionRequestDto> validator)
        {

            return await validator.ValidateAsync(request, default)
                 .Bind(() => _laborRepository.GetBulkCompletion(id, default))
                 .Bind(bulkCompletion => _laborRepository.Update(bulkCompletion.SetStatus(request.ErrorType, request.Comment, request.userName), default)
                 .Bind(bulkCompletion => _laborRepository.Commit(default)
                 .Bind(() => Task.FromResult(LaborBulkCompletionMapper.MapToDto(bulkCompletion).AsResult()))))
                 .MapAsync<LaborBulkCompletionDto, IActionResult>(success => ApiResultFactory.Success(success, System.Net.HttpStatusCode.OK),
            errors => errors.First() switch
            {
                _ => ApiResultFactory.Error<LaborBulkCompletionDto>(System.Net.HttpStatusCode.InternalServerError, string.Join(", ", errors.First().Reasons))
            });
        }

        [HttpPost("bulk-completion")]
        public List<string> Get([FromBody] List<MailingList> mailingList)
        {
            _laborlogging.GetMailingList(CancellationToken.None);
            return new List<string>();
        }
    }
}
