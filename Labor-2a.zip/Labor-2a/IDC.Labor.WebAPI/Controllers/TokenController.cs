﻿using IDC.Common.Authentication;
using Microsoft.AspNetCore.Mvc;

namespace IDC.Labor.WebAPI.Controllers
{
    [Route("api/token")]
    [ApiController]
    public class TokenController : ControllerBase
    {

        private readonly ILogger<TokenController> _logger;
       
        private readonly IConfiguration _configuration;
       
        private readonly ITokenProvider _tokenProvider;

        public TokenController(IConfiguration configuration,ITokenProvider tokenProvider, ILogger<TokenController> logger)
        {
            _logger=logger;
            _configuration=configuration;

            _tokenProvider=tokenProvider;


        }
        [HttpPost("token-with-parameters")]
        public async Task<IActionResult> GetTokenFromEntra([FromQuery] string appClientId, [FromQuery] string tenantId, [FromQuery] string scope, [FromQuery] string audience)
        {
            _logger.LogInformation("Try get token");

            try
            {
                var token = await _tokenProvider.GetToken(appClientId, tenantId, scope, audience);
                return Ok(token.AccessToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting token");
                _logger.LogError(ex.Message);
                return StatusCode(500, $"Error getting token {ex.Message}");
            }
        }

    }
}
