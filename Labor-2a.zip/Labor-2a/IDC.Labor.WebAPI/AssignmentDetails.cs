﻿namespace AutomationLaborEntry
{
    public class AssignmentDetails
    {
        public Int64 agreementId;
        public Int64 packageId;
        public Int64 serviceId;
        // public string isPublicSector;
        public int regionId;
    }
}
