﻿using AutomatedLaborEntry.Model;
using AutomationLaborEntry.Model;
using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Azure.Storage.Files.DataLake;
using BulkCompletionEvent;
using IDC.Labor.Infrastructure.Database;
using IDC.Labor.Infrastructure.Repositories;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.ServiceBus;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using System.Xml.Serialization;
using ConfigurationManager = System.Configuration.ConfigurationManager;
using ITokenProvider = IDC.Common.Authentication.ITokenProvider;

namespace IDC.Labor.WebAPI
{
    public class BulkCompletion
    {
        //static ISubscriptionClient subscriptionClient;
        public static System.IO.StreamWriter bulkSubmitAppFile;
        public static Telemetry telemetry;
        public static TelemetryClient telemetryClient;
        public static TelemetryLogger logger;
        public TopicMessage topicMessage;
        // private const string ServiceBusNamespace = "sclaborentry-uat";
        private const string TopicName = "msgtopic";
        private const string SubscriptionName = "idssub";
        static ServiceBusProcessor processor;
        static ServiceBusClient client;
        static IConfiguration configuration;
        static ITokenProvider tokenProvider;
        static ILaborRepository _laborRepository;
        //static  _laborRepository { get; } = new 
        public static async Task Main(string[] args)
        {
            try
            {
                //var host = CreateHostBuilder(args).Build();

                //using (var scope = host.Services.CreateScope())
                //{
                //    _laborRepository = scope.ServiceProvider.GetRequiredService<ILaborRepository>();
                //}

                    // _dbContext = new LaborDbContext();
                    telemetry = new Telemetry();
                telemetryClient = new TelemetryClient();
                logger = new TelemetryLogger(TelemetryConfiguration.Active, telemetry.SetTelemetrySettings());
                bulkSubmitAppFile = File.AppendText(ConfigurationManager.AppSettings["BulkSubmitApplog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd"));

                string connectionString = "https://sclaborentry-uat.servicebus.windows.net/";

                //string connectionString = "https://sc-laborentry-prod.servicebus.windows.net/";
                var options = new ServiceBusClientOptions
                {
                    TransportType = ServiceBusTransportType.AmqpWebSockets
                };
                client = new ServiceBusClient(connectionString, new DefaultAzureCredential(), options);
                processor = client.CreateProcessor(TopicName, SubscriptionName, new ServiceBusProcessorOptions
                { AutoCompleteMessages = false, MaxConcurrentCalls = 1, MaxAutoLockRenewalDuration = TimeSpan.FromMinutes(60) });

                // Define the message handler
                processor.ProcessMessageAsync += MessageHandler;
                processor.ProcessErrorAsync += ErrorHandler;

                // Start processing
                await processor.StartProcessingAsync();
                Console.WriteLine("Waiting for messages...");
            }
            catch (Exception ex)
            {
                if (telemetryClient != null)
                {
                    telemetryClient.TrackException(ex);
                }
                else
                {
                    Console.WriteLine("Telemetry client is not initialized.");
                }
            }
            finally
            {
                Console.ReadKey();
                // Wait for a key press to exit
                // Console.ReadKey();

                // Stop processing
                await processor.StopProcessingAsync();
                //subscriptionClient.CloseAsync();
            }
        }


        public static async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();
            Console.WriteLine($"Received: {body}");

            if (!File.Exists(ConfigurationManager.AppSettings["BulkSubmitApplog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd")))
            {
                bulkSubmitAppFile.Close();
                bulkSubmitAppFile = File.AppendText(ConfigurationManager.AppSettings["BulkSubmitApplog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd"));
            }
            GetLoadedListAsync();

            ServiceBusReceiver receiver = client.CreateReceiver(TopicName);

            await args.CompleteMessageAsync(args.Message);

            // await client.CompleteAsync(args.Message.LockToken);
            ProcessMessage(Parse(args.Message.Body.ToString()));
            //ProcessMessage(Parse(Encoding.UTF8.GetString(args.Message.Body)));
        }

        public static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine($"Message handler encountered an exception {args.Exception}.");
            var context = args.ErrorSource;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {args.FullyQualifiedNamespace}");
            Console.WriteLine($"- Entity Path: {args.EntityPath}");
            Console.WriteLine($"- Executing Action: {args.Identifier}");
            telemetryClient.TrackException(args.Exception);
            bulkSubmitAppFile.WriteLine(args.Exception);
            return Task.CompletedTask;
        }
       // public static ILaborRepository laborRepository;

        public static async Task<List<MailingList>> GetLoadedListAsync()
        {
            try
            {
                // Connect to a fabric
                string accountName = "msit-onelake";
                string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
                string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Tables";

                // Initialize the DataLakeServiceClient
                var serviceClient = new DataLakeServiceClient(
                    new Uri($"https://{accountName}.dfs.fabric.microsoft.com"),
                    new DefaultAzureCredential());

                // GetBulkCompletion the file system client
                DataLakeFileSystemClient fileSystemClient = serviceClient.GetFileSystemClient(fileSystemName);

                // GetBulkCompletion the directory client
                var directoryClient = fileSystemClient.GetDirectoryClient(directoryName);

                // GetBulkCompletion the file client for "LoadList.xml"
                var fileClient = directoryClient.GetFileClient("LoadList.xml");

                // Read the file content
                var downloadResponse = await fileClient.ReadAsync();
                var fileStream = new MemoryStream();
                await downloadResponse.Value.Content.CopyToAsync(fileStream);
                fileStream.Position = 0; // Reset the stream position to the beginning if needed

                // Process the file content as needed
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    string fileContent = await reader.ReadToEndAsync();
                    Console.WriteLine(fileContent);

                    var rootAttribute = new XmlRootAttribute
                    {
                        ElementName = "Tag",
                        IsNullable = true
                    };
                    var serializer = new XmlSerializer(typeof(List<MailingList>), rootAttribute);
                    using (var stringReader = new StringReader(fileContent))
                    {
                        ProcessTransaction.loadedList = (List<MailingList>)serializer.Deserialize(stringReader);
                    }
                }

                return ProcessTransaction.loadedList;
            }
            catch (Exception exe)
            {
                bulkSubmitAppFile.WriteLine("get Loaded List" + exe.Message);
                telemetryClient.TrackException(exe);
                return new List<MailingList>(); // Return an empty list in case of an error
            }
        }

        public static void RegisterOnMessageHandlerAndReceiveMessages()
        {
            var messageHandlerOptions = new ServiceBusProcessorOptions()
            {
                MaxConcurrentCalls = 1,
                AutoCompleteMessages = false,
                MaxAutoLockRenewalDuration = TimeSpan.FromMinutes(60)
            };

            // Register the function that processes messages.
            ServiceBusProcessor processor = client.CreateProcessor(TopicName, SubscriptionName, messageHandlerOptions);
            // Define the message handler
            processor.ProcessMessageAsync += MessageHandler;
            processor.ProcessErrorAsync += ErrorHandler;
            processor.StartProcessingAsync();
        }

        static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            var context = exceptionReceivedEventArgs.ExceptionReceivedContext;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {context.Endpoint}");
            Console.WriteLine($"- Entity Path: {context.EntityPath}");
            Console.WriteLine($"- Executing Action: {context.Action}");
            telemetryClient.TrackException(exceptionReceivedEventArgs.Exception);
            bulkSubmitAppFile.WriteLine(exceptionReceivedEventArgs.Exception);
            return Task.CompletedTask;
        }

        public static TopicMessage Parse(string json)
        {
            try
            {
                var json1 = json;
                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore
                };

                TopicMessage result = JsonConvert.DeserializeObject<TopicMessage>(json1, settings);
                //logger.TrackBusinessEvent(new Msit.Telemetry.Extensions.AI.BusinessProcessEvent("Received Message Successfully from ServiceBus", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess));
                bulkSubmitAppFile.WriteLine("Parsed Successfully");
                bulkSubmitAppFile.AutoFlush = true;
                return result;
            }
            catch (Exception exe)
            {
                bulkSubmitAppFile.WriteLine("Error in Parsing" + exe.Message);
            }
            return null;
        }

        public static async void ProcessMessage(TopicMessage topic)
        {
            try
            {

                bulkSubmitAppFile.WriteLine("Inside Process Method");
                ProcessTransaction transaction = new ProcessTransaction(configuration,tokenProvider,_laborRepository);
                if (transaction.GetTransaction(topic).Result)
                {
                    transaction.ProcessApplicatonError();
                }

            }
            catch (Exception exe)
            {
                bulkSubmitAppFile.WriteLine("Exception Inside Process" + exe.Message);
                telemetryClient.TrackException(exe);
            }
        }
    }
}