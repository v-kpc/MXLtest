﻿using AutomatedLaborEntry.Model;
using Newtonsoft.Json;
using System.Net;
using Microsoft.ApplicationInsights.DataContracts;
using AutomationLaborEntry.Model;
using System.Net.Http.Headers;
using AutomationLaborEntry;
using IDC.Labor.WebAPI;
using ConfigurationManager = System.Configuration.ConfigurationManager;
using AutomatedLaborEntry.Model.BulkSubmitResponse;
using Microsoft.Extensions.Configuration;
using IDC.Common.Authentication;
using System.Configuration;
using IDC.Labor.WebAPI.Interface;
using Azure.Identity;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using Azure;
using IDC.Labor.Infrastructure.Database;
using Azure.Data.Tables;
using IDC.Labor.Infrastructure.Database.Model;
using Microsoft.EntityFrameworkCore;
using IDC.Labor.Infrastructure.Repositories;
using Microsoft.Data.SqlClient;
using Azure.Core;
using FluentResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Amqp.Framing;
using System.Text;

namespace BulkCompletionEvent
{
    public class ProcessTransaction : IProcessTransaction
    {

        public List<MailingList> applicationErrorList;
        public List<MailingList> applicationRetryList;
        public List<MailingList> businessErrorList;
        public static List<MailingList> loadedList;
        public List<MailingList> batchloadedList;
        public IConfiguration Configuration;
        public ITokenProvider TokenProvider;
        private readonly ILaborRepository _laborRepository;

        public int successCount = 0;
        public static int batchNumber = 0;
        private static ReaderWriterLockSlim _readWriteLock = new ReaderWriterLockSlim();

        public ProcessTransaction(IConfiguration configuration,ITokenProvider tokenProvider, ILaborRepository laborRepository)
        {

            applicationErrorList = new List<MailingList>();
            applicationRetryList = new List<MailingList>();
            businessErrorList = new List<MailingList>();
            batchloadedList = new List<MailingList>();
            Configuration = configuration;
            TokenProvider = tokenProvider;
            _laborRepository = laborRepository;
            
            // _laborRepository = laborDbContext;

        }



        public async Task<bool> GetTransaction(TopicMessage listMessage)
        {
            try
            {
                if (listMessage != null)
                {
                    //string ClientID = "d3ea2afc-cc39-4636-aaaa-7e39bcace289";
                    //string TentantID = "72f988bf-86f1-41af-91ab-2d7cd011db47";
                    //string Resource = "5eb170f9-f828-4121-936c-288eb43b050e";
                    string ClientID = Configuration.GetValue<string>("FICProd:ClientID");
                    //string ClientID = "1330818f-cef4-4702-b776-d4d414b21d8e";
                    //string TentantID = "72f988bf-86f1-41af-91ab-2d7cd011db47";
                    string TentantID = Configuration.GetValue<string>("FICProd:TentantID");
                    //string Resource = "22c68362-0f39-4ef6-a5a6-2eb389b8592f/.default";
                    string Resource = Configuration.GetValue<string>("FICProd:Resource");


                    // string audience = "api://AzureADTokenExchange";
                    string audience = Configuration.GetValue<string>("FICProd:audience");

                    // var baseUrl = "https://idcxlaborentry-dev.azurewebsites.net/api/token/token-with-parameters";
                    var baseUrl = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:baseUrl");
                    var queryString = $"?appClientId={ClientID}&tenantId={TentantID}&scope={Resource}&audience={audience}";
                    var fullUrl = baseUrl + queryString;
                    string token = string.Empty;
                    bool bPost = false;
                    using (var httpclient = new HttpClient())
                    {
                        try
                        {
                            var response = await httpclient.GetAsync(fullUrl);
                            if (response.IsSuccessStatusCode)
                            {
                                var content = await response.Content.ReadAsStringAsync();
                                token = content;
                                byte[] newData46 = Encoding.UTF8.GetBytes("Error in Post method token : " + "token:" + token + response.ReasonPhrase + response.StatusCode);
                                LaborLogging.stream.Write(newData46, 0, newData46.Length);
                            }
                            else
                            {
                                byte[] newData46 = Encoding.UTF8.GetBytes("Error in Post method token : " + response.ReasonPhrase + response.StatusCode);
                                LaborLogging.stream.Write(newData46, 0, newData46.Length);
                                // LaborLogging.stream.Flush();
                                throw new HttpRequestException(response.ReasonPhrase + response.StatusCode);
                                // return StatusCode((int)response.StatusCode, response.ReasonPhrase);
                            }
                        }
                        catch(Exception  ex)
                        {

                        }

                        }

                            using (var client = new HttpClient())

                    {
                        try
                        {

                            if (listMessage != null)
                            {
                                if (!string.IsNullOrEmpty(listMessage.resourceUrl))
                                {


                                    //  client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjNQYUs0RWZ5Qk5RdTNDdGpZc2EzWW1oUTVFMCIsImtpZCI6IjNQYUs0RWZ5Qk5RdTNDdGpZc2EzWW1oUTVFMCJ9.eyJhdWQiOiI1ZWIxNzBmOS1mODI4LTQxMjEtOTM2Yy0yODhlYjQzYjA1MGUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83MmY5ODhiZi04NmYxLTQxYWYtOTFhYi0yZDdjZDAxMWRiNDcvIiwiaWF0IjoxNzMxMDYzNTY3LCJuYmYiOjE3MzEwNjM1NjcsImV4cCI6MTczMTE1MDI2NywiYWlvIjoiazJCZ1lOQ2Q4dCsyU0czamxweW1oVXlTeHJVeEFBPT0iLCJhcHBpZCI6ImQzZWEyYWZjLWNjMzktNDYzNi1hYWFhLTdlMzliY2FjZTI4OSIsImFwcGlkYWNyIjoiMiIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0Ny8iLCJvaWQiOiIwMTM5Zjk2ZC1iM2E2LTRlZWEtOTc4MC0yM2ExZmFjZmMxN2IiLCJyaCI6IjEuQVFFQXY0ajVjdkdHcjBHUnF5MTgwQkhiUl9sd3NWNG8tQ0ZCazJ3b2pyUTdCUTRhQUFBYUFBLiIsInN1YiI6IjAxMzlmOTZkLWIzYTYtNGVlYS05NzgwLTIzYTFmYWNmYzE3YiIsInRpZCI6IjcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0NyIsInV0aSI6IjdlaWR5YTc3OTBHNWJ0a0JrMGpLQUEiLCJ2ZXIiOiIxLjAifQ.UoJxKg5vAUegBWCm5wn2YGMqcmnW5WjfwK1-9LsIwrHW6clF_9XdpY_CvbhpopF5QTMroExD7moTPOo39r1yk7rN6gDg0OKssqg8BTndJi5wGDQZW7XKPOeFdCnxawAg8JvT2LzYKDRK5GVTvvXEP8DT83xcPNnThEQkX8FlqV4s3EKTTnMUJGKrcc0QzHZI8y3NgTMKLl8W4B32kGnms17PDNb9qj3aLmMYIcij7ac0LSgT2iK1dNKKnJM-ielZ70kpIEV3ogzZJcDR56h1hd_p-7YGOWv5g2PJNSEuG3b8PAXcQy2Be0FpPgIoizEUJzpiWmuZfhKSuogRicM0Jg");
                                    string subkey = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:Ocp-Apim-Subscription-Key");
                                    var url = listMessage.resourceUrl;
                                    //  BulkCompletion.bulkSubmitAppFile.WriteLine("request Url" + url);
                                    //var token = await TokenProvider.GetToken(ClientID, TentantID, Resource, audience);
                                  //  client.DefaultRequestHeaders.Add("Authorization", token);
                                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Inp4ZWcyV09OcFRrd041R21lWWN1VGR0QzZKMCIsImtpZCI6Inp4ZWcyV09OcFRrd041R21lWWN1VGR0QzZKMCJ9.eyJhdWQiOiIyMmM2ODM2Mi0wZjM5LTRlZjYtYTVhNi0yZWIzODliODU5MmYiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83MmY5ODhiZi04NmYxLTQxYWYtOTFhYi0yZDdjZDAxMWRiNDcvIiwiaWF0IjoxNzMzMjQyMjU5LCJuYmYiOjE3MzMyNDIyNTksImV4cCI6MTczMzMyODk1OSwiYWlvIjoiazJCZ1lEaTRiNStYZFcva29aKzFsMVp2TkQxMENRQT0iLCJhcHBpZCI6IjEzMzA4MThmLWNlZjQtNDcwMi1iNzc2LWQ0ZDQxNGIyMWQ4ZSIsImFwcGlkYWNyIjoiMiIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0Ny8iLCJvaWQiOiIwYzgzNTQ0MS1mMGU2LTRlNjMtYmVhNS01YjI4MmFkYjc3M2EiLCJyaCI6IjEuQVFFQXY0ajVjdkdHcjBHUnF5MTgwQkhiUjJLRHhpSTVEX1pPcGFZdXM0bTRXUzhhQUFBYUFBLiIsInN1YiI6IjBjODM1NDQxLWYwZTYtNGU2My1iZWE1LTViMjgyYWRiNzczYSIsInRpZCI6IjcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0NyIsInV0aSI6IklrXzBuc0Z2aTBXSlROdlcxZmdFQVEiLCJ2ZXIiOiIxLjAifQ.b8L-ZVO_LhP54CGS1jEOdMHdxF0QQOXJBvJ9K6cbAqEbuJpHM9y0c1_LxJSqyCHwRuZhY9Q_KZCEsLTnhq7Aqy-YDSvhUpLDD67NUEX3HecYUuKIuVHnAKCW3WRNU_5FTgij78WcfTMSq91o6YZIRXfFO2GzmSTAgiIDeNgGfvpeJ2a0Y8Pcu2q2AusYq3hmw4bb3EmnZTOiJspyXMj2BINeIjrzQyTbQpg6JffeqN1BZwWmQFkM8coCRc4c1fLoWwTQj4Ny4MYgAxyvNuSjfkzsyC-wHTD1Zx8MP5x47cK_a5kL8rzLsZ7EksK4-JD0UmRFd33154RYuBBqCW7-sg");
                                    //client.DefaultRequestHeaders.Add("Authorization", new AuthInput().GetAccess(ClientID, TentantID, Resource).Result);
                                    //client.DefaultRequestHeaders.Add("Authorization", new AuthInput().GetAccess(GetAuth()).Result);
                                    client.DefaultRequestHeaders.Add("x-originating-system-name", "ServiceCenter-LaborEntryAutomation");
                                    client.DefaultRequestHeaders.Add("x-core-correlation-request-id", Guid.NewGuid().ToString());
                                    client.DefaultRequestHeaders.Add("X-CorrelationId", Guid.NewGuid().ToString());
                                   // client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "fd723c776fbd432fb12471dcf25d5c10");
                                    client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subkey);

                                    var response = await client.GetAsync(url).ConfigureAwait(true);
                                    string result = response.Content.ReadAsStringAsync().Result;

                                    if (response.IsSuccessStatusCode)
                                    {
                                        var loadlist = await GetLoadlist();
                           //             BulkCompletion.logger.TrackRequest(new RequestTelemetry()
                           //             {
                           //                 Success = true,
                           //                 Url = new Uri(url),
                           //                 ResponseCode = response.StatusCode.ToString()
                           //             }

                           //);
                                        //BulkCompletion.bulkSubmitAppFile.WriteLine("GetBulkCompletion Successfully" + DateTime.Now.ToString());
                                        //BulkCompletion.bulkSubmitAppFile.AutoFlush = true;

                                        await Parse(result, listMessage.context.operationId);

                                    }
                                    else
                                    {
                                        throw new HttpRequestException(result);
                                    }
                                    return true;
                                }
                            }


                        }
                        catch (HttpRequestException e)
                        {
                            //BulkCompletion.telemetryClient.TrackException(e);
                            Console.WriteLine("\nException Caught!");
                            Console.WriteLine("Message :{0} ", e.Message);
                            //BulkCompletion.bulkSubmitAppFile.WriteLine(e.Message + " " + DateTime.Now.ToString());
                            return false;
                        }
                        catch (WebException wex)
                        {
                            if (wex.Response != null)
                            {
                                using (var errorResponse = (HttpWebResponse)wex.Response)
                                {
                                    using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                                    {
                                        string error = reader.ReadToEnd();
                                        //BulkCompletion.telemetryClient.TrackException(wex);
                                        //BulkCompletion.bulkSubmitAppFile.WriteLine(wex.Message + " " + DateTime.Now.ToString());
                                    }
                                }

                            }
                            return false;
                        }
                        catch (Exception ex)
                        {
                            //BulkCompletion.telemetryClient.TrackException(ex);
                           // BulkCompletion.bulkSubmitAppFile.WriteLine(ex.Message + " " + DateTime.Now.ToString());
                            return false;
                        }

                    }
                }
            }
            catch (Exception exe)
            {
                //BulkCompletion.telemetryClient.TrackException(exe);
               // BulkCompletion.bulkSubmitAppFile.WriteLine("Inside get Transation detail  :  " + exe.Message);
            }
            return true;
        }


        public async Task<bool> GetLoadlist()
        {
            //string accountName = "msit-onelake";
            //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
            //string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";
            ////string fileName = "Applog-2024-09-10.txt";
            //List<MailingList> loadedList= new List<MailingList>();
            //string newFileName = "LoadList.xml";
            string accountName = Configuration.GetValue<string>("CDEFabricsDataLake:accountName");
            //string accountName = "msit-onelake";
            //string fileSystemName = "fcc9c59a-0f2a-4b67-9225-af4b908c7592";
            string fileSystemName = Configuration.GetValue<string>("CDEFabricsDataLake:fileSystemName");
            // string directoryName = "1361e728-920b-4576-b17e-3623ba69e554/Files";

            string directoryName = Configuration.GetValue<string>("CDEFabricsDataLake:directoryName");
            // string fileName = $"{Configuration.GetValue<string>("CDEFabricsDataLake:fileName")}-{DateTime.Now.ToString("yyyy-MM-dd")}.txt";
            //  string fileName = "Applog-" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            string fileName = Configuration.GetValue<string>("CDEFabricsDataLake:fileName") + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            //string newFileName = "LoadList.xml";
            string newFileName = Configuration.GetValue<string>("CDEFabricsDataLake:newFileName");

            var serviceClient = new DataLakeServiceClient(
                new Uri($"https://{accountName}.dfs.fabric.microsoft.com"),
                new DefaultAzureCredential());

            DataLakeFileSystemClient fileSystemClient = serviceClient.GetFileSystemClient(fileSystemName);

            var directoryClient = fileSystemClient.GetDirectoryClient(directoryName);
            var fileClient2 = directoryClient.GetFileClient(newFileName);

            Response<FileDownloadInfo> downloadResponse = await fileClient2.ReadAsync();
            using (StreamReader reader = new StreamReader(downloadResponse.Value.Content))
            {
               
                var rootAttribute = new System.Xml.Serialization.XmlRootAttribute();
                rootAttribute.ElementName = "Tag";
                rootAttribute.IsNullable = true;
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(List<MailingList>), rootAttribute);
                ProcessTransaction.loadedList = (List<MailingList>)serializer.Deserialize(reader);
                string content = await reader.ReadToEndAsync();
               // reader.Close();
                // loadedList = System.Text.Json.JsonSerializer.Serialize(content);
                //Console.WriteLine(content);
                return true;
            }

           // return true;

        }
        /// <summary>
        /// for testing
        /// </summary>
        /// <returns></returns>
        public static string GetJson()
        {


            string json = "{ \"response\":  {" +
         "  \"context\": {" +
                  "  \"correlationId\": " + "\"" + "2f52cd8c-134e-4019-97a9-4b982195e1b2" + "\", " +
                  "  \"subCorrelationId\": " + "\"89a61fcf-d374-65c6-2bc8-f95e350b4871\", " +
                  "  \"operationId\": " + "\"2f52cd8c-134e-4019-97a9-4b982195e1b2\", " +
                  "  \"operationType\": " + "\"Submit\", " +
                  "  \"requestOriginator\": " + "\"b3f2c3b5-d67d-4d32-ab43-aca9db1b6384\", " +
                  "  \"originatingSystem\": " + "\"Swagger\" " +
                         "  }, " +
                        " \"data\":[{" +
                      "   \"context\": {" +
                  "  \"correlationId\": " + "\"" + "edb281ba-20b6-4726-870e-994e7ffac56c" + "\", " +
                  "  \"transactionalId\": " + "\"" + "43359c30-4949-4df0-a2ba-2979c0e64ea8" + "\" " +
                  "}," +
                       "   \"data\": {" +
                         "   \"response\": {" +
                          "  \"errorMessage\": " + "\"" + "Business rules validation failed" + "\", " +
                  "  \"exceptionIdentifier\": " + "\"edb281ba-20b6-4726-870e-994e7ffac56c\", " +
                   "  \"errorCategory\": " + "\"ApplicationError\" " +
                         "}," +
          "\"serviceMessages\":[{" +
          "\"type\":" + "\"" + "Error" + "\"," +
            "\"errorCategory\":" + "\"" + "BusinessRuleError" + "\"," +
              "\"message\":" + "\"" + "Please provide a valid labor category." + "\"," +
                "\"partnerId\":" + "\"bravos-idc-newsletters\"" +

          "}]}}," +
          "{" +
          "   \"context\": {" +
                  "  \"correlationId\": " + "\"" + "0ecc6e97-4ba4-4d4b-834d-42bd298ed583" + "\", " +
                  "  \"transactionalId\": " + "\"" + "50a61fcf-d374-65c6-2bc8-f95e350b4871" + "\" " +
                  "}," +
                       "   \"data\": {" +
                         "   \"response\": {" +
                          "  \"errorMessage\": " + "\"" + "Business rules validation failed" + "\", " +
                  "  \"exceptionIdentifier\": " + "\"19a61fcf-d374-65c6-2bc8-f95e350b4871\", " +
                   "  \"errorCategory\": " + "\"ApplicationError\" " +
                         "}," +
          "\"serviceMessages\":[{" +
          "\"type\":" + "\"" + "Error" + "\"," +
            "\"errorCategory\":" + "\"" + "ApplicationError" + "\"," +
              "\"message\":" + "\"" + "Please provide a valid labor category." + "\"," +
                "\"partnerId\":" + "\"bravos-idc-newsletters\"" +

          "}]" +
                   "}" +

                      " }" +
        "]" +
    "}}";

            return json;
        }



        /// <summary>
        /// Processing Error 
        /// </summary>
        /// <param name="result"> cantains the data from topic message</param>
        public async Task ProcessError(Rootobject result, string operationId)
        {
            string status = string.Empty;
            string ErrorMessage = string.Empty;
            //dynamic data = GetJson(); //for testing
            //result = JsonConvert.DeserializeObject<List<AutomatedLaborEntry.Model.BulkSubmitResponse.Response>>(data);//, settings); //for testing
          //  dynamic data = GetJson(); // for testing
            //result = JsonConvert.DeserializeObject<AutomatedLaborEntry.Model.BulkSubmitResponse.Rootobject>(data);
            // result =JsonConvert.DeserializeObject<AutomatedLaborEntry.Model.BulkSubmitResponse.Response>(data);

            try
            {
                if (result.response.data != null)
                {
                    for (int dataIncrement = 0; dataIncrement < result.response.data.Length; dataIncrement++)
                    {
                        if (result.response.data[dataIncrement].data.serviceMessages != null && result.response.data[dataIncrement].data.serviceMessages.Length != 0)
                        {
                            for (int serviceMsgIncrement = 0; serviceMsgIncrement < result.response.data[dataIncrement].data.serviceMessages.Length; serviceMsgIncrement++)
                            {
                                if (result.response.data[dataIncrement].data.serviceMessages == null)
                                {
                                    successCount++;
                                    MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                    if (list != null)
                                    {
                                        list.Status = "Success";
                                        list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                        list.LaborId = result.response.data[dataIncrement].data.response.laborId;
                                        list.OperationId = operationId;
                                        list.BulkCorrelationId = result.response.context.correlationId;
                                        list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                        batchloadedList.Add(list);
                                       // BulkCompletion.bulkSubmitAppFile.WriteLine("Success : agreementId" + result.response.data[dataIncrement].data.response.assignmentDetails.agreementId);
                                    }
                                }
                                else if (result.response.data[dataIncrement].data.serviceMessages[serviceMsgIncrement].@type == "Error")
                                {
                                    if (Enum.IsDefined(typeof(BusinessError.errorCategory), (result.response.data[dataIncrement].data.response.errorCategory)))
                                    {
                                        MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                        if (list != null)
                                        {
                                            list.Status = "Business";
                                            list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                            list.ErrorMessage = result.response.data[dataIncrement].data.serviceMessages[serviceMsgIncrement].@message;
                                            list.OperationId = operationId;
                                            list.BulkCorrelationId = result.response.context.correlationId;
                                            list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                            batchloadedList.Add(list);
                                            businessErrorList.Add(list);
                                            //AppendToFileLog("Mailing List - AgreementId: " + list.AgreementId + " " + "ScheduleID : " + list.PackageId + ", LineItem: " + list.ServiceId + ", LaborCategory: " + Enum.GetName(typeof(MailingList.laborCategory), list.LaborCategoryId) + ", Error Message:" + result.response.data[dataIncrement].data.serviceMessages[serviceMsgIncrement].@message + "  " + DateTime.Now.ToString());
                                        }

                                    }
                                    else if (result.response.data[dataIncrement].data.response.errorCategory == "ApplicationError" ||
                                       result.response.data[dataIncrement].data.response.errorCategory == "ExternalError")
                                    {
                                        MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                        if (list != null)
                                        {
                                            if (list.Index < 2)
                                            {
                                                bool alreadyExist = applicationErrorList.Contains(list);
                                                if (!alreadyExist)
                                                {
                                                    list.Status = "Application";
                                                    list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                                    list.ErrorMessage = result.response.data[dataIncrement].data.response.errorMessage;
                                                    list.OperationId = operationId;
                                                    list.BulkCorrelationId = result.response.context.correlationId;
                                                    list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                                    if (list.Index == 0)
                                                        list.Index = 1;
                                                    else if (list.Index == 1)
                                                        list.Index = 2;

                                                    batchloadedList.Add(list);
                                                    applicationErrorList.Add(list);
                                                }
                                            }
                                            else
                                            {
                                                bool alreadyExist = applicationRetryList.Contains(list);
                                                if (!alreadyExist)
                                                {
                                                    list.Status = "ApplicationRetry";
                                                    list.ErrorMessage = result.response.data[dataIncrement].data.response.errorMessage;
                                                    list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                                    list.OperationId = operationId;
                                                    list.BulkCorrelationId = result.response.context.correlationId;
                                                    list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                                    batchloadedList.Add(list);
                                                    applicationRetryList.Add(list);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (result.response.data[dataIncrement].data.response != null && ((result.response.data[dataIncrement].data.serviceMessages == null) || (result.response.data[dataIncrement].data.serviceMessages.Length == 0)))
                        {
                            if (result.response.data[dataIncrement].data.response.errorCategory == "ApplicationError")
                            {
                                MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                if (list != null)
                                {
                                    if (list.Index < 2)
                                    {
                                        list.Status = "Application";
                                        list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                        list.ErrorMessage = result.response.data[dataIncrement].data.response.errorMessage;
                                        list.OperationId = operationId;
                                        list.BulkCorrelationId = result.response.context.correlationId;
                                        list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                        if (list.Index == 0)
                                            list.Index = 1;
                                        else if (list.Index == 1)
                                            list.Index = 2;
                                        batchloadedList.Add(list);
                                        applicationErrorList.Add(list);


                                    }
                                    else
                                    {
                                        list.Status = "ApplicationRetry";
                                        list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                        list.ErrorMessage = result.response.data[dataIncrement].data.response.errorMessage;
                                        list.OperationId = operationId;
                                        list.BulkCorrelationId = result.response.context.correlationId;
                                        list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                        batchloadedList.Add(list);
                                        applicationRetryList.Add(list);


                                    }
                                }
                            }
                            else if (result.response.data[dataIncrement].data.response.errorCategory == null)
                            {
                                successCount++;
                                MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                if (list != null)
                                {
                                    list.Status = "Success";
                                    list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                    list.LaborId = result.response.data[dataIncrement].data.response.laborId;
                                    list.OperationId = operationId;
                                    list.BulkCorrelationId = result.response.context.correlationId;
                                    list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                    batchloadedList.Add(list);

                                }
                                //BulkCompletion.bulkSubmitAppFile.WriteLine("Success : agreementId" + result.response.data[dataIncrement].data.response.assignmentDetails.agreementId);
                            }
                            else if (Enum.IsDefined(typeof(BusinessError.errorCategory), (result.response.data[dataIncrement].data.response.errorCategory)))
                            {
                                MailingList list = loadedList.Where(X => X.GUID.ToString() == result.response.data[dataIncrement].context.correlationId).SingleOrDefault();
                                if (list != null)
                                {
                                    list.Status = "Business";
                                    list.TransactionId = result.response.data[dataIncrement].context.transactionalId;
                                    list.ErrorMessage = result.response.data[dataIncrement].data.response.errorMessage;
                                    list.OperationId = operationId;
                                    list.BulkCorrelationId = result.response.context.correlationId;
                                    list.BulkSubCorrelationId = result.response.context.subCorrelationId;
                                    batchloadedList.Add(list);
                                    businessErrorList.Add(list);
                                    //AppendToFileLog("Mailing List - AgreementId: " + list.AgreementId + " " + "ScheduleID : " + list.PackageId + ", LineItem: " + list.ServiceId + ", LaborCategory: " + Enum.GetName(typeof(MailingList.laborCategory), list.LaborCategoryId) + ", Error Message:" + result.response.data[dataIncrement].data.response.errorMessage + "  " + DateTime.Now.ToString());
                                }
                            }
                        }
                    }
                    //BulkCompletion.bulkSubmitAppFile.AutoFlush = true;

                }
                var batchResult = await BatchOperation(batchloadedList, "Batch-" + batchNumber.ToString());
                //_dbContext.LaborBulkCompletion.Add()
               //string batchResult = new WriteToAzureStorage().BatchOperation(batchloadedList, "Batch-" + batchNumber.ToString());
                //BulkCompletion.bulkSubmitAppFile.WriteLine("BatchOperationResult : " + batchResult);
                batchloadedList.Clear();
               // BulkCompletion.bulkSubmitAppFile.WriteLine("BatchNumber : " + batchNumber);
                batchNumber++;
                //SetTelemetryCount();

            }
            catch (Exception exe)
            {
                //BulkCompletion.telemetryClient.TrackException(exe);
                //BulkCompletion.bulkSubmitAppFile.WriteLine("ProcessError" + exe.StackTrace);

            }
        }


        /// <summary>
        /// Process application errors
        /// </summary>
        public void ProcessApplicatonError()
        {
            try
            {
                if (applicationErrorList != null)
                {
                    int errCount = applicationErrorList.Distinct().ToList<MailingList>().Count;
                    //BulkCompletion.bulkSubmitAppFile.WriteLine("ApplicatonErrorCount - " + errCount);
                    if (applicationErrorList.Count > 0 && applicationRetryList.Count == 0)
                    {
                        // Build the configuration
                        var configuration = new ConfigurationBuilder()
                            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                            .Build();

                        // Create an instance of LaborLogging
                        var laborLogging = new LaborLogging(Configuration,TokenProvider);

                        LaborLogging laborlog = new LaborLogging(Configuration, TokenProvider);
                        List<MailingList> applicationlist = applicationErrorList.Distinct().ToList<MailingList>();
                        //BulkCompletion.bulkSubmitAppFile.WriteLine("Retrying  Application Error");
                        laborlog.BatchProcessList(applicationlist, 1).GetAwaiter().GetResult();
                       // BulkCompletion.bulkSubmitAppFile.WriteLine(" Completed Retrying  Application Error");
                    }
                }
                //BulkCompletion.bulkSubmitAppFile.AutoFlush = true;
            }
            catch (Exception ex)
            {
               // BulkCompletion.bulkSubmitAppFile.WriteLine("Error in Application Retry", ex.Message);
                //BulkCompletion.telemetryClient.TrackException(ex);
            }

        }

        public async Task<string> BatchOperation(List<MailingList> mls, string partition)
        {
           // CloudTable table = null;
            int i = 0;
            List<MailingList> batchlist;
            //TableBatchOperation batch;
          //  TableClient tableClient = null;
            var batchop = new List<TableTransactionAction>();
            //List<MailingList> mylist = new List<MailingList>();
            //mylist.Add("Item 1");
            //mylist.Add("Item 2");

            //mls.Add(new MailingList
            //{
            //    Service = "181763857",
            //    AgreementId = "181763846",
            //    PackageId = "181763847",
            //    AgreementCountry = "Croatia",
            //    LaborCategoryId = 847942,
            //    ErrorMessage = "Test",
            //    Status = "Green",
            //    GUID = Guid.NewGuid(),
            //    TransactionId="12345",
            //    LaborId="67890",
            //    BulkCorrelationId= "678909",
            //    BulkSubCorrelationId= "123457",
            //    OperationId="455678"

            //});


            if (mls.Count > 0)
            {
                try
                {

                    for (int j = 0; j < mls.Count; j = j + 100)
                    {
                        string partitionKey = Guid.NewGuid().ToString();
                       // batch = new TableBatchOperation();
                        batchlist = mls.Skip(j).Take(100).ToList<MailingList>();
                        foreach (MailingList ml in batchlist)
                        {
                            

                            var tablebulkentity = new LaborBulkCompletion()
                            {
                                ExternalId = Guid.NewGuid(),
                                PartitionKey = partitionKey,
                                RowKey = i,
                                AgreementID = ml.AgreementId,
                                Country = ml.AgreementCountry,
                                PackageID = ml.PackageId,
                                ServiceID = ml.ServiceId,
                                LaborCategory = Enum.GetName(typeof(MailingList.laborCategory), ml.LaborCategoryId),
                                ErrorMessage = ml.Status,// ml.ErrorMessage,
                                ErrorType = ml.Status,
                                CorrelationID = ml.GUID.ToString(),
                                TransactionID = ml.TransactionId,
                                LaborID = ml.LaborId,
                                BulkCorrelationID = ml.BulkCorrelationId,
                                BulkSubCorrelationID = ml.BulkSubCorrelationId,
                                OperationID = ml.OperationId,
                                Timestamp=System.DateTime.Now,
                            };
                            var test2 = await Insertbulk(tablebulkentity);
                               
                                i++;
                        }

                        //  var result = table.ExecuteBatch(batch);
                        //var result = tableClient.SubmitTransaction(table);
                       // var result = tableClient.SubmitTransactionAsync(batchop);
                    }
                    return "Success";

                }
                catch (HttpRequestException ex)
                {
                    return ex.Message;

                }
                catch (Exception exe)
                {
                    return exe.Message;
                }

            }
            return "Empty List";
        }


        public async Task<Result> Insertbulk(LaborBulkCompletion request)
        {
            var test =  await _laborRepository.InsertBulkCompletion(request, CancellationToken.None);
            return test;
        }
        /// <summary>
        /// write all business rules to file
        /// </summary>
        /// <param name="file"></param>
        private static void AppendToFileLog(string file)
        {
            try
            {
                _readWriteLock.EnterWriteLock();
                if (!Directory.Exists(ConfigurationManager.AppSettings["BusinessErrorLog"].ToString()))
                {
                    Directory.CreateDirectory(ConfigurationManager.AppSettings["BusinessErrorLog"].ToString());
                }
                using (StreamWriter wr = System.IO.File.AppendText(ConfigurationManager.AppSettings["LstLog"].ToString() + ".lst"))
                {
                    wr.WriteLine(file);
                    wr.Close();
                }
            }
            catch (Exception exe)
            {
                //BulkCompletion.bulkSubmitAppFile.WriteLine(exe.Message);
            }
            finally
            {
                _readWriteLock.ExitWriteLock();
            }

        }

        public static AuthInput GetAuth()
        {
            AuthInput auth = new AuthInput();
            auth.Authority = ConfigurationManager.AppSettings["Authority"].ToString();
            auth.ClientId = ConfigurationManager.AppSettings["ClientId"].ToString();
            auth.Resource = ConfigurationManager.AppSettings["Resource"].ToString();
            return auth;
        }

        public async Task Parse(string json, string operationId)
        {

            try
            {
                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore
                };

                Rootobject result = JsonConvert.DeserializeObject<Rootobject>(json, settings);
                await ProcessError(result, operationId);
            }
            catch (Exception ex)
            {
                //BulkCompletion.bulkSubmitAppFile.WriteLine("Error in parsing Topic Message to Class object   :" + ex.Message);
            }
        }

        public void SetTelemetryCount()
        {
            Telemetry telemetry = new Telemetry();

            try
            {
                telemetry.telemetryCountProperties.Add("SuccessCount", (successCount == 0) ? "0" : successCount.ToString());
                telemetry.telemetryCountProperties.Add("ApplicationErrorCount", (applicationErrorList.Count > 0) ? applicationErrorList.Count.ToString() : "0");
                telemetry.telemetryCountProperties.Add("ApplicationRetryFailedCount", (applicationRetryList.Count > 0) ? applicationRetryList.Count.ToString() : "0");
                telemetry.telemetryCountProperties.Add("BusinessErrorCount", (businessErrorList.Count > 0) ? businessErrorList.Count.ToString() : "0");
                //BulkCompletion.logger.TrackBusinessEvent(new Msit.Telemetry.Extensions.AI.BusinessProcessEvent("Count", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryCountProperties);
                //BulkCompletion.bulkSubmitAppFile.WriteLine(string.Format("SuccessCount " + successCount + " " + "ApplicationErrorCount " + applicationErrorList.Count
                // + " " + "ApplicationRetryCount " + applicationRetryList.Count + " " + "BusinessErrorList " + businessErrorList.Count));
                //foreach (MailingList list in applicationRetryList)
                //{
                //    //BulkCompletion.bulkSubmitAppFile.WriteLine("After 2 Retry transaction failed: ContractID " + list.AgreementId +
                //                                 "  ScheduleID  " + list.PackageId + " " + "lineItemID  :" + list.ServiceId);
                //    telemetry.telemetryAppErrorProperties.Add("AgreementId", list.AgreementId);
                //    telemetry.telemetryAppErrorProperties.Add("PackageId", list.PackageId);
                //    telemetry.telemetryAppErrorProperties.Add("ServiceId", list.ServiceId);
                //    //BulkCompletion.logger.TrackBusinessEvent(new Msit.Telemetry.Extensions.AI.BusinessProcessEvent("Application Error after 2 repeative retry", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryAppErrorProperties);
                //    telemetry = new Telemetry();
                //}
                businessErrorList.Clear();
                //BulkCompletion.logger.Flush();
            }
            catch (Exception exe)
            {
               // BulkCompletion.bulkSubmitAppFile.WriteLine("SetTelemetryCount" + exe.StackTrace);

            }
            finally
            {

            }

        }


    }
}
