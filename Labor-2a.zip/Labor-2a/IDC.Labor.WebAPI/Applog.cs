﻿namespace IDC.Labor.WebAPI
{
    public class Applog
    {
    }
}
