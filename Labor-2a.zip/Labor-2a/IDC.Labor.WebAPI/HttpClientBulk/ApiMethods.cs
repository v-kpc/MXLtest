﻿using System.Text;
using System.Net;
using Azure.Storage.Files.DataLake;
using Azure.Identity;
using AutomationLaborEntry.Model;
using IDC.Common.Authentication;
using Azure.Messaging.ServiceBus;
using IDC.Labor.WebAPI.Model;
using AutomatedLaborEntry.Model.BulkSubmitResponse;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace AutomationLaborEntry.HttpClientBulk
{

    public class ApiMethods
    {
        public IConfiguration Configuration { get; }

        public ITokenProvider TokenProvider;
        public static ServiceBusClient client;
        public static ServiceBusProcessor processor;
        private const string TopicName = "msgtopic";
        private const string SubscriptionName = "idssub";
        public ApiMethods(IConfiguration configuration, ITokenProvider tokenProvider)
        {
            Configuration = configuration;
            TokenProvider = tokenProvider;
        }

        /// <summary>
        /// Post Method for Bulk Submit
        /// </summary>
        /// <param name="output">Json Payload with all labor data</param>
        /// <returns></returns>
        public async Task<bool> PostMethod(string output)
        {
            byte[] newData5 = Encoding.UTF8.GetBytes("PostMethod: ");
            LaborLogging.stream.Write(newData5, 0, newData5.Length);
            //LaborLogging.stream.Flush();
            //LaborLogging.stream.Write(newData4, 0, newData4.Length);
            // BulkSubmit bulkSubmit = new BulkSubmit();
            BulkSubmit? bulkSubmit = System.Text.Json.JsonSerializer.Deserialize<BulkSubmit>(output);
            //  TopicSend? topicSend= System.Text.Json.JsonSerializer.Deserialize<TopicSend>(output);
            Guid OpertionID = bulkSubmit.context.operationID;
            //Dev
            //string ClientID = "d3ea2afc-cc39-4636-aaaa-7e39bcace289";
            //string TentantID = "72f988bf-86f1-41af-91ab-2d7cd011db47";
            //string Resource = "5eb170f9-f828-4121-936c-288eb43b050e/.default";
            //Prod
            string ClientID = Configuration.GetValue<string>("FICProd:ClientID");
            //string ClientID = "1330818f-cef4-4702-b776-d4d414b21d8e";
            //string TentantID = "72f988bf-86f1-41af-91ab-2d7cd011db47";
            string TentantID = Configuration.GetValue<string>("FICProd:TentantID");
            //string Resource = "22c68362-0f39-4ef6-a5a6-2eb389b8592f/.default";
            string Resource = Configuration.GetValue<string>("FICProd:Resource");


           // string audience = "api://AzureADTokenExchange";
            string audience = Configuration.GetValue<string>("FICProd:audience");

            // var baseUrl = "https://idcxlaborentry-dev.azurewebsites.net/api/token/token-with-parameters";
            var baseUrl = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:baseUrl");
            var queryString = $"?appClientId={ClientID}&tenantId={TentantID}&scope={Resource}&audience={audience}";
            var fullUrl = baseUrl + queryString;
            string token=string.Empty;
            bool bPost = false;
            using (var httpclient= new HttpClient())
            {
                try
                {
                    var response = await httpclient.GetAsync(fullUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        token = content;
                        byte[] newData46 = Encoding.UTF8.GetBytes("Error in Post method token : " +"token:"+ token+ response.ReasonPhrase + response.StatusCode);
                        LaborLogging.stream.Write(newData46, 0, newData46.Length);
                    }
                    else
                    {
                        byte[] newData46 = Encoding.UTF8.GetBytes("Error in Post method token : " + response.ReasonPhrase + response.StatusCode);
                        LaborLogging.stream.Write(newData46, 0, newData46.Length);
                        // LaborLogging.stream.Flush();
                        throw new HttpRequestException(response.ReasonPhrase + response.StatusCode);
                        // return StatusCode((int)response.StatusCode, response.ReasonPhrase);
                    }

                    bPost= await TimetwopointO(token, output, OpertionID.ToString(), ClientID);
                }
                catch(Exception ex)
                { Console.WriteLine(ex.Message); }
            }

            return bPost;


          
        }




        public  async Task<bool> TimetwopointO(string token, string output,string OpertionID, string ClientID)
        {
            bool apiconnect = false;
            try {
                
                using (var client = new HttpClient())
                {
                    try
                    {

                      string url= Configuration.GetValue<string>("Time2.0APIUrldetailsProd:BulkSendUrl");
                        string subkey = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:Ocp-Apim-Subscription-Key");
                       // var url = "https://professionalservices.microsoft.com/lmt-coreapi-dev/api/v1/labor/operation";

                        //  var token = await TokenProvider.GetToken(ClientID, TentantID, Resource, audience);

                        // client.DefaultRequestHeaders.Add("Authorization", token.AccessToken);
                        string applogtoken = "token.AccessToken" + DateTime.Now.ToString() + Environment.NewLine;
                        //string applog = "Exit due to error in StoredList";
                        byte[] newDatatoken = Encoding.UTF8.GetBytes(applogtoken);
                        LaborLogging.stream.Write(newDatatoken, 0, newDatatoken.Length);
                        //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                        //client.DefaultRequestHeaders.Add("Authorization", token);
                       client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Inp4ZWcyV09OcFRrd041R21lWWN1VGR0QzZKMCIsImtpZCI6Inp4ZWcyV09OcFRrd041R21lWWN1VGR0QzZKMCJ9.eyJhdWQiOiIyMmM2ODM2Mi0wZjM5LTRlZjYtYTVhNi0yZWIzODliODU5MmYiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83MmY5ODhiZi04NmYxLTQxYWYtOTFhYi0yZDdjZDAxMWRiNDcvIiwiaWF0IjoxNzMzMjQyMjU5LCJuYmYiOjE3MzMyNDIyNTksImV4cCI6MTczMzMyODk1OSwiYWlvIjoiazJCZ1lEaTRiNStYZFcva29aKzFsMVp2TkQxMENRQT0iLCJhcHBpZCI6IjEzMzA4MThmLWNlZjQtNDcwMi1iNzc2LWQ0ZDQxNGIyMWQ4ZSIsImFwcGlkYWNyIjoiMiIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0Ny8iLCJvaWQiOiIwYzgzNTQ0MS1mMGU2LTRlNjMtYmVhNS01YjI4MmFkYjc3M2EiLCJyaCI6IjEuQVFFQXY0ajVjdkdHcjBHUnF5MTgwQkhiUjJLRHhpSTVEX1pPcGFZdXM0bTRXUzhhQUFBYUFBLiIsInN1YiI6IjBjODM1NDQxLWYwZTYtNGU2My1iZWE1LTViMjgyYWRiNzczYSIsInRpZCI6IjcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0NyIsInV0aSI6IklrXzBuc0Z2aTBXSlROdlcxZmdFQVEiLCJ2ZXIiOiIxLjAifQ.b8L-ZVO_LhP54CGS1jEOdMHdxF0QQOXJBvJ9K6cbAqEbuJpHM9y0c1_LxJSqyCHwRuZhY9Q_KZCEsLTnhq7Aqy-YDSvhUpLDD67NUEX3HecYUuKIuVHnAKCW3WRNU_5FTgij78WcfTMSq91o6YZIRXfFO2GzmSTAgiIDeNgGfvpeJ2a0Y8Pcu2q2AusYq3hmw4bb3EmnZTOiJspyXMj2BINeIjrzQyTbQpg6JffeqN1BZwWmQFkM8coCRc4c1fLoWwTQj4Ny4MYgAxyvNuSjfkzsyC-wHTD1Zx8MP5x47cK_a5kL8rzLsZ7EksK4-JD0UmRFd33154RYuBBqCW7-sg");
                        client.DefaultRequestHeaders.Add("x-originating-system-name", "ServiceCenter-LaborEntryAutomation");
                        string subcorrelation = Guid.NewGuid().ToString();
                        client.DefaultRequestHeaders.Add("x-core-correlation-request-id", subcorrelation);
                        string Correlation = Guid.NewGuid().ToString();
                        client.DefaultRequestHeaders.Add("X-CorrelationId", Correlation);
                        // client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "fd723c776fbd432fb12471dcf25d5c10");
                        client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subkey);
                         var data = new StringContent(output, Encoding.UTF8, "application/json");
                        try
                        {
                            //  HttpResponseMessage response1 = await client.PostAsync("https://professionalservicesint.microsoft.com/lmt-coreapi-dev/api/v1/labor/operation", data);
                            var response1 = await client.PostAsync(url, data).ConfigureAwait(true); 

                            string result = response1.Content.ReadAsStringAsync().Result;
                            if (response1.IsSuccessStatusCode)
                            {

                                string applogt = "Post Successfully: " + DateTime.Now.ToString() + Environment.NewLine;
                                //string applog = "Exit due to error in StoredList";
                                byte[] newData43 = Encoding.UTF8.GetBytes(applogt);
                                LaborLogging.stream.Write(newData43, 0, newData43.Length);
                                LaborLogging.stream.Flush();

                                TopicSend message = new TopicSend();
                                string resourceUrl = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:resourceurl");
                                // message.resourceUrl = "https://professionalservicesint.microsoft.com/lmt-coreapi-dev/api/v1/labor/operation/" + OpertionID.ToString() + "/Submit";
                                message.resourceUrl = resourceUrl + OpertionID.ToString() + "/Submit";
                                if (message.context == null)
                                {
                                    message.context = new AutomatedLaborEntry.Model.BulkSubmitResponse.Context(); // Assuming Context is the correct type
                                }

                                // Ensure OpertionID is not null
                                if (OpertionID != null)
                                {
                                    message.context.operationId = OpertionID.ToString();
                                    message.context.correlationId = Correlation;
                                    message.context.operationType = "Submit";
                                    message.context.status = response1.StatusCode.ToString();
                                    message.context.subCorrelationId = subcorrelation;
                                    message.context.originatingSystem = "ServiceCenter-LaborEntryAutomation";
                                    message.context.requestOriginator = ClientID;


                                }
                                else
                                {
                                    throw new ArgumentNullException(nameof(OpertionID), "OpertionID cannot be null");
                                }


                                string data1 = System.Text.Json.JsonSerializer.Serialize(message);


                                var text = await Createservicebus(data1);
                                if (text != null)
                                {
                                    apiconnect = true;
                                   // return true;
                                }
                                //return false;
                            }
                            else
                            {
                                byte[] newData46 = Encoding.UTF8.GetBytes("Error in Post : " + "token" + result + response1.ReasonPhrase + response1.StatusCode);
                                LaborLogging.stream.Write(newData46, 0, newData46.Length);
                                LaborLogging.stream.Flush();
                                throw new HttpRequestException(result + response1.ReasonPhrase + response1.StatusCode);
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Exception: " + ex.Message);
                            // return false;
                            apiconnect=false;
                        }


                    }
                    catch (HttpRequestException e)
                    {
                        // LaborLogging.telemetryClient.TrackException(e);
                        Console.WriteLine("\nException Caught!");
                        Console.WriteLine("Message :{0} ", e.Message);
                        byte[] newData47 = Encoding.UTF8.GetBytes("Error in Post :" + DateTime.Now + "\n" + e.Message);
                        LaborLogging.stream.Write(newData47, 0, newData47.Length);
                        LaborLogging.stream.Flush();
                        //LaborLogging.appFile.WriteLine("Error in Post :" + DateTime.Now + "\n" + e.Message);
                        //LaborLogging.appFile.Flush();
                        // return false;
                        apiconnect = false;
                    }
                    catch (WebException wex)
                    {
                        if (wex.Response != null)
                        {
                            using (var errorResponse = (HttpWebResponse)wex.Response)
                            {
                                using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                                {
                                    string error = reader.ReadToEnd();
                                    LaborLogging.appFile.WriteLine("WebRequestError :" + DateTime.Now + "\n" + error);
                                    //LaborLogging.telemetryClient.TrackException(wex);
                                    //TODO: use JSON.net to parse this string and look at the error message
                                    apiconnect = false;
                                }
                            }

                        }
                       // return false;
                    }
                    catch (Exception ex)
                    {
                        //LaborLogging.telemetryClient.TrackException(ex);
                        // throw;
                        LaborLogging.appFile.WriteLine("Inside Post Method: " + ex.Message);
                        //return false;
                        apiconnect = false;
                    }

                }

            }
            catch (Exception ex)
            {
                LaborLogging.appFile.WriteLine("Inside Post Method: " + ex.Message);
                //return false;
                apiconnect = false;
            }
            return apiconnect;


            }

        public  async Task <string>Createservicebus(string output)
        {
            // string connectionString = "https://SCLaborEntry-UAT.servicebus.windows.net/";
            string connectionString = Configuration.GetValue<string>("Time2.0APIUrldetailsProd:Servicebusurl"); ;
            
            string strmessage = string.Empty;
            var options = new ServiceBusClientOptions
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };
            client = new ServiceBusClient(connectionString, new DefaultAzureCredential(), options);
            ServiceBusSender sender = client.CreateSender(TopicName);

            try
            {
                // Create a new message to send to the topic
                ServiceBusMessage message = new ServiceBusMessage(output);

                // Send the message
               await sender.SendMessageAsync(message);
                strmessage="Message sent successfully.";
            }
            finally
            {
                // Dispose of the client when done
                await sender.DisposeAsync();
                await client.DisposeAsync();
            }
            return strmessage;

        }







    }
}
