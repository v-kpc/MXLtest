﻿using FluentValidation;
using IDC.Common.Tools.Validation;
using IDC.Labor.ApiClient.Models;

namespace IDC.Labor.WebAPI.Validation
{
    internal class PatchLaborBulkCompletionRequestDtoValidator : FluentValidator<PatchLaborBulkCompletionRequestDto>
    {
        public PatchLaborBulkCompletionRequestDtoValidator()
        {
            RuleFor(x => x.ErrorType).NotEmpty().MaximumLength(500);
            RuleFor(x => x.Comment).MaximumLength(5000);
            RuleFor(x => x.userName).NotEmpty().MaximumLength(500);
        }
    }
}
