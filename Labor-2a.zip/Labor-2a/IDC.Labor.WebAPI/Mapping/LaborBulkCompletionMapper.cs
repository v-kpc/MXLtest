﻿using IDC.Labor.ApiClient.Models;
using IDC.Labor.Infrastructure.Database.Model;

namespace IDC.Labor.WebAPI.Mapping
{
    public static class LaborBulkCompletionMapper
    {
        public static LaborBulkCompletionDto MapToDto(LaborBulkCompletion src)
            => new LaborBulkCompletionDto(src.ExternalId, src.PackageID, src.AgreementID, src.ErrorType, src.LaborCategory, src.Timestamp, src.ServiceID, src.Country, src.Comment);
    }
}
