using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure;
using System.Xml.Serialization;
using System.Text;
using System.Xml.Linq;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Google.Protobuf.Reflection;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Azure.Identity;
using System.Diagnostics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using AutomatedLaborEntry.Model.BulkSubmitResponse;



namespace AutomatedLaborfuncapp
{
    public class Automatelaborfunc
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        static ServiceBusProcessor processor;
        static ServiceBusClient client;
        private readonly IHttpClientFactory _httpClientFactory;

        public Automatelaborfunc(ILoggerFactory loggerFactory, IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            _logger = loggerFactory.CreateLogger<Automatelaborfunc>();
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
        }

        [Function("Automatelaborfunc")]
        public  async Task Run([TimerTrigger("* */5 * * * *")] TimerInfo myTimer, ILogger log)
        {
            //_logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            BlobContainerClient blobContainerClient = new BlobContainerClient(storageConnectionString, "mlxfiles");

            //  var test=  blobContainerClient.GetBlobs(prefix: "_SC-PROACTIVEBILLINGONLY");


            //foreach (BlobItem blobItem in blobContainerClient.GetBlobs(prefix: "_SC-PROACTIVEBILLINGONLY"))
            //{
            //    Console.WriteLine(blobItem.Name);
            //}
            var blobs = blobContainerClient.GetBlobs();
            var resultSegment = blobContainerClient.GetBlobsByHierarchyAsync(prefix: "LATEST", delimiter: "/")
            .AsPages(default, 2);
            List<MXLDownloadfile> res = new List<MXLDownloadfile>();
            var bulk = new List<(string newsletter, string MLXfile)>();
            var list = new List<BlobItem>();
            var listfilter = new List<BlobItem>();
            var multilistfilter = new List<BlobItem>();
            await foreach (Page<BlobHierarchyItem> blobPage in resultSegment)
            {
                // A hierarchical listing may return both virtual directories and blobs.
                foreach (BlobHierarchyItem blobhierarchyItem in blobPage.Values)
                {
                    if (blobhierarchyItem.IsPrefix)
                    {
                        // Write out the prefix of the virtual directory.
                        Console.WriteLine("Virtual directory prefix: {0}", blobhierarchyItem.Prefix);

                        // Call recursively with the prefix to traverse the virtual directory.
                        list = await ListBlobsHierarchicalListing(blobContainerClient, blobhierarchyItem.Prefix);
                        string strProactive = "_SC-PROACTIVEBILLINGONLY";
                        string strReactive = "_SC-REACTIVEBILLINGONLY";
                        if (strProactive != string.Empty)
                        {

                            //listfilter = list.FindAll(s => s.Name.IndexOf("SECURITYCALL-CN", StringComparison.OrdinalIgnoreCase) >= 0);
                            multilistfilter = list.FindAll(s => s.Name.IndexOf(strProactive, StringComparison.OrdinalIgnoreCase) >= 0);
                            listfilter.AddRange(multilistfilter);
                        }
                        if (strReactive != string.Empty)
                        {
                            listfilter = list.FindAll(s => s.Name.IndexOf(strReactive, StringComparison.OrdinalIgnoreCase) >= 0);
                            listfilter.AddRange(multilistfilter);
                        }
                    }
                    else
                    {
                        // Write out the name of the blob.
                        Console.WriteLine("Blob name: {0}", blobhierarchyItem.Blob.Name);
                    }
                }

            }
            // XmlDocument xmlDocument = new XmlDocument();

            foreach (var blob in listfilter)
            {
                var blobClient = blobContainerClient.GetBlobClient(blob.Name);

                string strnewletter = blobClient.Name;
                using var stream = new MemoryStream();
                await blobClient.DownloadToAsync(stream);
                stream.Position = 0;
                using var streamReader = new StreamReader(stream);
                var result = await streamReader.ReadToEndAsync();

                MailingTagList mls = DeserializeXmlData<MailingTagList>(result);



                List<MXLDownloadfile> finallist = new List<MXLDownloadfile>();
                finallist.Add(new MXLDownloadfile { MLXfile = result, Newsletter = strnewletter });

                res.AddRange(finallist);



            }

            var json = System.Text.Json.JsonSerializer.Serialize(res);

           
            try
            {
                var response = await ExecuteAsync(json, log);
                //var client = _httpClientFactory.CreateClient();
                //var response = await client.GetStringAsync("https://api.example.com/data");
                //return response;

                //using (var client = new HttpClient())
                //{
                //    var request = new HttpRequestMessage(HttpMethod.Post, $"https://idcxlaborentry-dev.azurewebsites.net/AutomateLabor/GetAutomationLaborEntry");
                //    request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                //    // using var client = new HttpClient();
                //    var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    log.LogInformation(response.ReasonPhrase, response.Content);

                    
                }
                else
                {
                    log.LogInformation(response.ReasonPhrase, response.Content);
                    throw new HttpRequestException(response.ReasonPhrase + response.StatusCode);
                }
                //    //response.EnsureSuccessStatusCode();

                //}
            }
            catch (Exception ex)
            {
                log.LogInformation("Automatedlaborerror ", ex.Message);
            }

        }

        private static T DeserializeXmlData<T>(string xmlstring)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using StringReader reader = new StringReader(xmlstring);

            return (T)serializer.Deserialize(reader)!;
        }

        private static async Task<List<BlobItem>> ListBlobsHierarchicalListing(BlobContainerClient container, string prefix)
        {
            var list = new List<BlobItem>();

            var resultSegment =
                container.GetBlobsByHierarchyAsync(prefix: prefix, delimiter: "/");

            // A hierarchical listing may return both virtual directories and blobs.
            await foreach (BlobHierarchyItem blobhierarchyItem in resultSegment)
            {
                if (blobhierarchyItem.IsPrefix)
                {
                    // Write out the prefix of the virtual directory.

                    // Call recursively with the prefix to traverse the virtual directory.
                    list.AddRange(await ListBlobsHierarchicalListing(container, blobhierarchyItem.Prefix));
                }
                else
                {
                    // Write out the name of the blob.
                    list.Add(blobhierarchyItem.Blob);
                    // list.Add(blobhierarchyItem.Blob.Name)
                }
            }


            return list;
        }

        // Timer trigger to fetch mlx files from storage account  every month second tuesday 

        //[Function("TimerTriggerAutomtedLabor")]
        //public static void Run([TimerTrigger("0 0 0 * * 2")] TimerInfo myTimer, ILogger log)
        //{
        //    // Additional logic to check if it's the second Tuesday
        //    var today = DateTime.UtcNow;
        //    if (today.Day >= 8 && today.Day <= 14)
        //    {
        //        log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
        //        // Your function logic here
        //    }
        //}

        public async Task<HttpResponseMessage> ExecuteAsync(string json, ILogger log)
        {
            var client = _httpClientFactory.CreateClient();
            // string strcontent=string.Empty;
            string url = Environment.GetEnvironmentVariable("Automatedlaborendpoint");
           // var request= new HttpRequestMessage(HttpMethod.Post,url )
             var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:7139/AutomateLabor/GetAutomationLaborEntry")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
                
            };

            var response = await client.SendAsync(request);
           // strcontent=response.Content.ToString();
            if (response.IsSuccessStatusCode)
            {
                log.LogInformation(response.ReasonPhrase, response.Content);
            }
            response.EnsureSuccessStatusCode();
            return response;
        }


        [Function("BulkCompletion")]
        public static async Task Run1(
           [TimerTrigger("* */10 * * * *")] TimerInfo myTimer, ILogger log, IConfiguration configuration)
        {




            try
            {
                string connectionString = Environment.GetEnvironmentVariable("ServicebusConnection");
                string strservicebusname = Environment.GetEnvironmentVariable("idssubname");

                string TopicName = Environment.GetEnvironmentVariable("msgtopicname");
                var options = new ServiceBusClientOptions
                {
                    TransportType = ServiceBusTransportType.AmqpWebSockets
                };
                client = new ServiceBusClient(connectionString, new DefaultAzureCredential(
                     ), options);
                processor = client.CreateProcessor(TopicName, strservicebusname, new ServiceBusProcessorOptions
                { AutoCompleteMessages = false, MaxConcurrentCalls = 1, MaxAutoLockRenewalDuration = TimeSpan.FromMinutes(60)});

                // Add handler to process messages
                processor.ProcessMessageAsync += MessageHandler;

                // Add handler to process any errors
                processor.ProcessErrorAsync += ErrorHandler;

                // Start processing
                await processor.StartProcessingAsync();

                Console.WriteLine("Press any key to end the processing");
                Console.ReadKey();

                // Stop processing
                await processor.StopProcessingAsync();






            }

            catch (Exception ex)
            {
                log.LogError(ex, ex.Message);
                // await messageActions.AbandonMessageAsync(message);
            }
        }



        // Handle received messages
        static async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();
            Console.WriteLine($"Received: {body}");
            var json = System.Text.Json.JsonSerializer.Serialize(body);
            //  string jsonString = JsonConvert.SerializeObject(json, Formatting.Indented);

            // Unescape the JSON string
            string unescapedJson = System.Text.RegularExpressions.Regex.Unescape(json.Trim('"'));

            // Parse and format the JSON
            var parsedJson = JToken.Parse(unescapedJson);
            string formattedJson = parsedJson.ToString(Formatting.Indented);

            using (var client = new HttpClient())
            {
                string url = Environment.GetEnvironmentVariable("BulkCompletionenpoint");
                var request = new HttpRequestMessage(HttpMethod.Post, $"https://localhost:7139/AutomateLabor/ProcessBulkcompletion");
               // var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(formattedJson, Encoding.UTF8, "application/json");

                // using var client = new HttpClient();
                var response = await client.SendAsync(request);
                response.EnsureSuccessStatusCode();

            }
            // Complete the message. Messages are deleted from the queue.
            await args.CompleteMessageAsync(args.Message);
        }

        // Handle any errors when receiving messages
        static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }


    }



}
