﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomatedLaborfuncapp
{
    public class MXLDownloadfile
    {
        private string newsletter;
        private string mlxfile;
        public string Newsletter
        {
            get { return newsletter; }
            set { newsletter = value; }
        }
        
        public string MLXfile
        {
            get { return mlxfile; }
            set { mlxfile = value; }
        }




    }
}
