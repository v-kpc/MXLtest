﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;

namespace AutomatedLaborfuncapp
{
    public static class ListExtensions
    {
        public static string SerializeToXml<T>(this List<T> list)
        {
            var serializer = new XmlSerializer(typeof(List<T>));
            using (var writer = new StringWriter())
            using (var xmlWriter = XmlWriter.Create(writer))
            {
                serializer.Serialize(xmlWriter, list);
                return writer.ToString();
            }
        }

    }
}
