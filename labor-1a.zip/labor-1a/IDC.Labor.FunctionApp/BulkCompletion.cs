using System;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using IDC.Labor.WebAPI;
using System.Text.Json;
using AutomationLaborEntry.Model;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace IDC.Labor.FunctionApp
{
    public class BulkCompletion
    {
        private readonly ILogger<BulkCompletion> _logger;
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public BulkCompletion(ILogger<BulkCompletion> logger, HttpClient httpClient, IConfiguration configuration)
        {
            _logger = logger;
            _httpClient = httpClient;
            _configuration=configuration;
        }

        [Function("BulkCompletion")]
        public async Task Run(
            [ServiceBusTrigger("msgtopic", "idssub", Connection = "https://SCLaborEntry-UAT.servicebus.windows.net/")] ServiceBusReceivedMessage message,
            ServiceBusMessageActions messageActions)
        {
            _logger.LogInformation("Message ID: {id}", message.MessageId);
            _logger.LogInformation("Message Body: {body}", message.Body);
            _logger.LogInformation("Message Content-Type: {contentType}", message.ContentType);

            try
            {
                // Deserialize the message body to a MailingList object
                //var mailingList = JsonSerializer.Deserialize<MailingList>(message.Body.ToString());

                //if (mailingList != null)
                //{
                //    // Log the mailing list details
                //    _logger.LogInformation("Mailing List Name: {name}", mailingList.Name);
                //    _logger.LogInformation("Mailing List Agreement ID: {agreementId}", mailingList.AgreementId);

                //    // Call the Web API controller to check if the load list is created in the lakehouse
                //    var response = await _httpClient.GetAsync($"https://your-api-endpoint/api/checkloadlist/{mailingList.AgreementId}");
                //    if (response.IsSuccessStatusCode)
                //    {
                //        _logger.LogInformation("Load list is created in the lakehouse.");
                //    }
                //    else
                //    {
                //        _logger.LogError("Failed to verify load list creation in the lakehouse.");
                //    }

                //    // Call the method in IDC.Labor.WebAPI.BulkCompletion.Main with the mailing list
                //    await IDC.Labor.WebAPI.BulkCompletion.Main(new string[] { mailingList.AgreementId });
                //}
                //else
                //{
                //    _logger.LogError("Failed to deserialize the message body to a MailingList object.");
                //}

                // Complete the message
                var json = JsonSerializer.Serialize(message);
                using (var client = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, $"https://localhost:7139/ProcessBulkcompletion");
                    request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                    // using var client = new HttpClient();
                    var response = await client.SendAsync(request);
                    response.EnsureSuccessStatusCode();

                }
                await messageActions.CompleteMessageAsync(message);
                
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "JSON deserialization error.");
                await messageActions.AbandonMessageAsync(message);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "HTTP request error.");
                await messageActions.AbandonMessageAsync(message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred.");
                await messageActions.AbandonMessageAsync(message);
            }
        }
    }
}
