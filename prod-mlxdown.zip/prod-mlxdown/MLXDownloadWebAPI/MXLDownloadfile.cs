﻿using Newtonsoft.Json;

namespace MLXDownloadWebAPI
{

    public class MXLDownloadfile
    {      
        private string newsletter;
        private string mlxfile;
        private int beforeCSAMremovecount;
        private int afterCSAMremovecount;
        public string Newsletter {
            get { return newsletter; }
            set { newsletter = value; }
        }
        public int BeforeCSAMSremoveMlxcount
        {
            get { return beforeCSAMremovecount; }
            set { beforeCSAMremovecount = value; }
        }

        public int AfterCSAMSremoveMLXcount
        {
            get { return afterCSAMremovecount; }
            set { afterCSAMremovecount = value; }
        }
        public string MLXfile
        {
            get { return mlxfile; }
            set { mlxfile = value; }
        }


        

    }
}
