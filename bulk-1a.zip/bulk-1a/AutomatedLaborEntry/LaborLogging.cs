﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Configuration;
using AutomatedLaborEntry.Model;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using Newtonsoft.Json;
using Microsoft.ApplicationInsights;
using System.Diagnostics;
using msit= Msit.Telemetry.Extensions.AI;
using Microsoft.ApplicationInsights.Extensibility;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;
using System.Xml;


namespace AutomatedLaborEntry
{
    public class LaborLogging
    {
        #region public variable
        public static System.IO.StreamWriter appFile;
        public static List<MailingList> loadedLists;
        public IEnumerable<MailingList> batchLists;
        public ObservableCollection<Data> data;
        ApiMethods callApi;
        public static Telemetry telemetry;
        public static TelemetryClient telemetryClient;
        public static TelemetryLogger logger;
        private ReaderWriterLockSlim _readWriteLock;
        public List<string> failedPayload;
        #endregion

        public LaborLogging()
        {

            try
            {
                telemetry = new Telemetry();
                loadedLists = new List<MailingList>();
                _readWriteLock = new ReaderWriterLockSlim();
                _readWriteLock.EnterWriteLock();
                telemetryClient = new TelemetryClient();
                failedPayload = new List<string>();

                logger = new TelemetryLogger(TelemetryConfiguration.Active, telemetry.SetTelemetrySettings());
                logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Application Started", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);

                var mth = new StackTrace().GetFrame(1).GetMethod();
                string cls = mth.ReflectedType.FullName;


                appFile = File.AppendText(ConfigurationManager.AppSettings["ApplicationLog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd"));
                callApi = new ApiMethods();

                if (cls.Equals("AutomatedLaborEntry.Program"))
                {
                    
                    // to get files from local drive for testing purpose
                      GetMlxFiles();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Labor logging " + ex.StackTrace);
                appFile.WriteLine("Inside Labor logging" + ex.Message + " " + DateTime.Now.ToString());
                telemetryClient.TrackException(ex);
            }
            finally
            {
                if (_readWriteLock.IsWriteLockHeld)
                {
                    _readWriteLock.ExitWriteLock();
                }
                appFile.Close();
            }

        }

        /// <summary>
        /// getting Mlx Files from folder and processing
        /// </summary>

        public void GetMlxFiles()
        {
            telemetry = new Telemetry();
            try
            {
                string mlxFilePath = ConfigurationManager.AppSettings["MlxFilePath"].ToString();
                XmlSerializer xml = new XmlSerializer(typeof(MailingTagList));
                string[] files = Directory.GetFiles(mlxFilePath);
                logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Reading Mlx Files", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);
                appFile.WriteLine("Reading Mlx Files" + DateTime.Now.ToString());
                if (files.Count() > 0)
                {
                    foreach (var path in files)
                    {

                        MailingTagList mls = (MailingTagList)xml.Deserialize(System.IO.File.OpenRead(path));

                        // Parse all tags and add to our global list if they weren't there already
                        foreach (MailingList ml in mls.MailingLists)
                        {
                            ml.Index = 0;// mls.MailingLists.IndexOf(ml);
                            ml.Tag = new string[] { mls.Name.Trim() };
                            ml.GUID = Guid.NewGuid();

                            // Add this list to our tally of all lists
                            if (ml.Tag[0].ToUpper().Contains("_SC-REACTIVEBILLINGONLY"))//_SC-SECURITY-
                            {
                                if (loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-REACTIVEBILLINGONLY")).Count() == 0)
                                {
                                    ml.LaborCategoryId = (int)MailingList.laborCategory.Reactive_Content_Billing;
                                    loadedLists.Add(ml);
                                }
                            }
                            else if (ml.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY"))
                            {
                                if (loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY")).Count() == 0)
                                {
                                    ml.LaborCategoryId = (int)MailingList.laborCategory.Proactive_Content_Billing;
                                    loadedLists.Add(ml);
                                }
                            }
                        }
                        // read Xml file
                    }

                    telemetry.telemetryMlxProperties.Add("TotalloadedMlxCount", loadedLists.Count().ToString());


                    logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Successfully Read MLX files", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryMlxProperties);
                    // store the mailing list
                    List<MailingList> lineItemNullList = loadedLists.Where(x => x.ServiceId == null || x.ServiceId == "").ToList<MailingList>();
                    if (lineItemNullList.Count() > 0)
                    {
                        foreach (MailingList ml in lineItemNullList)
                        {
                            AppendToFileLog("Mailing List Null LineItemID - AgreementId: " + ml.AgreementId + " " + "PackageId : " + ml.PackageId + ", LaborCategory: " + Enum.GetName(typeof(MailingList.laborCategory), ml.LaborCategoryId));
                            telemetry = new Telemetry();
                            telemetry.telemetryNullItemPropertiesProperties.Add("AgreementId", ml.AgreementId);
                            telemetry.telemetryNullItemPropertiesProperties.Add("PackageId", ml.PackageId);
                            telemetry.telemetryNullItemPropertiesProperties.Add("LaborCategory", Enum.GetName(typeof(MailingList.laborCategory), ml.LaborCategoryId));
                            logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Agreement with Null ItemID", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryNullItemPropertiesProperties);
                            string status = new WriteToAzureStorage().CreateAzureTableEntity(ml, "Mailing List null ServiceId", "Business", null);
                            appFile.WriteLine("ServiceId Null Post to Azure Storage" + status);
                        }
                    }

                    //  checking for null LineItemID, contractID , ScheduleID and Region, if present excluding from billing list
                    loadedLists.RemoveAll(x => (x.ServiceId == null) || (x.AgreementRegionId == 0) || (x.PackageId == null) || (x.AgreementId == null) || (x.ServiceId == "") ||
                    (x.PackageId == "") || (x.AgreementId == ""));
                    telemetry.telemetryMlxProperties.Add("TotalloadedMlxCountAfterNullCheck", loadedLists.Count().ToString());
                    appFile.WriteLine("Total loaded MLX Count after NUll check" + loadedLists.Count().ToString());
                    appFile.Flush();
                    logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Successfully Read MLX files", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryMlxProperties);
                    //  loadedLists = loadedLists.Take(10).ToList<MailingList>();

                    // store the mailing list
                   string storingstatus = storeLoadedList(0, null);
                    if (storingstatus.Equals("Success"))
                    {
                        var result = BatchProcessList(loadedLists, 0).GetAwaiter().GetResult();
                    }
                    else
                    {
                        appFile.WriteLine("Exit due to error in StoredList");
                        logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Exit due to error in StoredList", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);

                    }

                }
                else
                {
                    appFile.WriteLine("No Mlx File found");
                    logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Mlx Files not found", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), null);

                }
            }
            catch (Exception exe)
            {
                appFile.WriteLine("Reading Mlx File: " + exe.Message);
                telemetryClient.TrackException(exe);
            }
        }


        /// <summary>
        /// Generating Payload for Post request
        /// Parameter: flag - false for fresh entry and true for Application retry entry
        /// </summary>
        /// <param name="flag"></param>
        public string GeneratePayload(int index)
        {
            try
            {
                data = new ObservableCollection<Data>();
                foreach (MailingList ml in batchLists)
                {
                    data.Add(LaborEntry(ml, index));
                }
                return GetHeader();
            }
            catch (Exception exe)
            {
                appFile.WriteLine("Generating Pay Load:  " + exe.StackTrace + "\n" + exe.Message + " " + DateTime.Now.ToString());
                Console.WriteLine(exe.StackTrace);
                telemetryClient.TrackException(exe);
            }
            return string.Empty;
        }


        /// <summary>
        /// generating header for the payload
        /// </summary>
        public string GetHeader()
        {
            string output = string.Empty;
            try
            {
                telemetry = new Telemetry();
                BulkSubmitHeader _submitHeader = new BulkSubmitHeader();
                _submitHeader.operationID = Guid.NewGuid();
                appFile.WriteLine("Creating operationId  :" + _submitHeader.operationID);
                _submitHeader.originatingDateTimeInUtc = DateTime.UtcNow;
                _submitHeader.type = "Submit";
                BulkSubmit bulkSubmit = new BulkSubmit();
                bulkSubmit.context = _submitHeader;
                bulkSubmit.data = data;
                output = JsonConvert.SerializeObject(bulkSubmit);
                appFile.WriteLine("Bulk Submit Payload " + output);
                telemetry.telemetryOperationProperties.Add("OperationId", _submitHeader.operationID.ToString());
                logger.TrackBusinessEvent(new msit.BusinessProcessEvent("OperationID generated", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryOperationProperties);
                return output;

            }
            catch (Exception ex)
            {
                appFile.WriteLine("Binding Header: " + ex.Message + " " + DateTime.Now.ToString());
                telemetryClient.TrackException(ex);
            }
            return output;
        }

        /// <summary>
        /// spliting mailing list into parts for processing
        /// </summary>
        /// <param name="lists"></param>
        /// <param name="flag"></param>
        public async Task<bool> BatchProcessList(List<MailingList> lists, int index)
        {
            try
            {
                bool isValidPayLoad;
                Task<bool> getPostResult;
                if (index > 0)
                {
                    appFile = File.AppendText(ConfigurationManager.AppSettings["ApplicationLog"].ToString() + "-" + DateTime.Now.ToString("yyyy-MM-dd"));
                }

                appFile.WriteLine("Inside Batch Processing");
                int BatchSize = int.Parse(ConfigurationManager.AppSettings["BatchSize"].ToString());
                /* just checking*/
                List<Task> tasklist = new List<Task>();
                if (callApi == null)
                {
                    callApi = new ApiMethods();
                }

                for (int i = 0; i < lists.Count; i = i + BatchSize)
                {
                    try
                    {
                        batchLists = new ObservableCollection<MailingList>();
                        batchLists = lists.Skip(i).Take(BatchSize);
                        string output = GeneratePayload(index);
                        if (!string.IsNullOrEmpty(output))
                        {

                            getPostResult = callApi.PostMethod(output);
                            tasklist.Add(getPostResult);
                            isValidPayLoad = await getPostResult;
                            if (!isValidPayLoad)
                            {
                                failedPayload.Add(output);
                            }
                        }
                        else
                        {
                            appFile.WriteLine("Payload is Empty");
                        }
                    }
                    catch (Exception exe)
                    {
                        appFile.WriteLine("Error in bulk submit trigger  " + exe.StackTrace + " " + exe.Message + DateTime.Now.ToString());
                    }

                }
                await Task.WhenAll(tasklist);

                if (failedPayload.Count != 0)
                {
                    foreach (string pay in failedPayload)
                    {
                        try
                        {
                            getPostResult = callApi.PostMethod(pay);
                            tasklist.Add(getPostResult);
                            isValidPayLoad = await getPostResult;
                            if (!isValidPayLoad)
                            {
                                string isdone = new WriteToAzureStorage().UpdateFailedPayLoadAzureTableEntity(pay, "Failed");
                                appFile.WriteLine("Retry Failed for Payload   " + pay + "Status " + isdone);
                            }
                            else
                            {
                                string isdone = new WriteToAzureStorage().UpdateFailedPayLoadAzureTableEntity(pay, "Success");
                                appFile.WriteLine("Retry Passed for Payload   " + pay + "Status " + isdone);
                            }
                        }
                        catch (Exception exe)
                        {
                            appFile.WriteLine("Error in  retry bulk submit trigger  " + exe.StackTrace + " " + exe.Message + DateTime.Now.ToString());
                        }
                    }
                }
                else
                {
                    appFile.WriteLine("All task completed");
                    appFile.AutoFlush = true;
                    appFile.Close();
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in batchprocessing" + ex.StackTrace + ex.Message);
                appFile.WriteLine("Batch Processing " + ex.Message + " " + DateTime.Now.ToString());
                telemetryClient.TrackException(ex);
                return false;

            }
            finally
            {
                if (_readWriteLock.IsWriteLockHeld)
                    _readWriteLock.ExitWriteLock();
            }
            return true;
        }



        /// <summary>
        /// setting values to Labor Data
        /// </summary>
        /// <param name="ml"></param>
        /// <param name="flag"></param>
        /// <returns></returns>
        public Data LaborEntry(MailingList ml, int index)
        {
            Data laborDataEntry = new Data();
            LaborEntry labor = new LaborEntry();
            telemetry = new Telemetry();
            try
            {
                labor.laborCategoryId = ml.LaborCategoryId;
                if (ml.Index > 0)
                {
                    laborDataEntry.context.correlationId = Guid.NewGuid();
                    ml.GUID = laborDataEntry.context.correlationId;
                }
                else
                {
                    laborDataEntry.context.correlationId = ml.GUID;// Guid.NewGuid();
                }

                labor.assignmentDetails = new AssignmentDetails();

             //for Labor late submission
                //labor.laborDate = DateTimeOffset.Parse("2020-04-15T00:00:00Z").UtcDateTime.Date;//for late submission
                //labor.submittedBy = "bravos-idc-newsletters-submitter-" + "04" + "/" + DateTime.Now.Year;
                //labor.submittedFor = "bravos-idc-newsletters-submitter-" + "04" + "/" + DateTime.Now.Year;

                
                labor.laborHours = new TimeSpan(00, 00, 00);
                labor.laborTimeZoneId = 35;

                // for normal submission
                labor.submittedBy = "bravos-idc-newsletters-submitter-" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year;
                labor.submittedFor = "bravos-idc-newsletters-submitter-" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year;
                labor.laborDate = DateTime.UtcNow.Date;


                if (labor.laborCategoryId == (int)MailingList.laborCategory.Proactive_Content_Billing)
                {
                    labor.laborNotes = string.Format("Proactive Alert " + " " + String.Format("{0:MMM}", DateTime.Now) + " " + DateTime.Now.Year);
                    if (string.Equals(ml.AgreementCountry, "China") || string.Equals(ml.AgreementCountry, "Taiwan"))
                    {
                        labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                        {
                            chargedLabor = new TimeSpan(00, 30, 00)
                        };
                    }
                    else
                    {
                        labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                        {
                            chargedLabor = new TimeSpan(00, 45, 00)
                        };
                    }
                }
                else if (labor.laborCategoryId == (int)MailingList.laborCategory.Reactive_Content_Billing)
                {
                    labor.laborNotes = string.Format("Security Alert" + " " + String.Format("{0:MMM}", DateTime.Now) + " " + DateTime.Now.Year);
                    labor.partnerSpecificAttribute = new partnerSpecificAttributecs()
                    {
                        chargedLabor = new TimeSpan(00, 15, 00)
                    };
                }
                labor.partner = "bravos-idc-newsletters";
                labor.assignmentDetails = new AssignmentDetails()
                {

                    agreementId = Int64.Parse(ml.AgreementId),
                    packageId = Int64.Parse(ml.PackageId),
                    serviceId = Int64.Parse(ml.ServiceId),
                    regionId = ml.AgreementRegionId,
                    //  isPublicSector = null

                };

              
                labor.updatedDateInUtc = DateTime.UtcNow;

                /// for late submission scenario
                //  labor.actionDetails = new ActionDetail[1];
                //  labor.actionDetails[0] = new ActionDetail();
                //  labor.actionDetails[0].reasonId = 333177;
                ////  labor.actionDetails[0].comments = "Delayed Billing";
                // labor.actionDetails[0].comments = "https://nam06.safelinks.protection.outlook.com/?url=https%3A%2F%2Fipgengagements.visualstudio.com%2Ff9cffc0e-8cf9-4ef4-8634-4413399709c7%2F_workitems%2Fedit%2F36203&data=02%7C01%7Cv-ranjpa%40microsoft.com%7Cead15e2a0e684a6411e508d7eff596aa%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C637241710586101292&sdata=LB3ypKgdknZD%2FvYC3jXp2GNYj9AL3u9VzQN2vfU1NpY%3D&reserved=0" +"   delayed submission due to pubsec charges";
                //  labor.actionDetails[0].actionType = "LateSubmission";



                laborDataEntry.data = labor;
                telemetry.telemetryLaborProperties.Add("ContractId", ml.AgreementId);
                telemetry.telemetryLaborProperties.Add("ScheduleId", ml.PackageId);
                telemetry.telemetryLaborProperties.Add("LineItemId", ml.ServiceId);
                telemetry.telemetryLaborProperties.Add("CorrelationID", ml.GUID.ToString());
                telemetry.telemetryLaborProperties.Add("LaborCategoryID", (ml.LaborCategoryId != 0) ? ml.LaborCategoryId.ToString() : "0");
                telemetry.telemetryLaborProperties.Add("Modified Guid", (ml.GUID == laborDataEntry.context.correlationId) ? "0" : laborDataEntry.context.correlationId.ToString());
                logger.TrackBusinessEvent(new msit.BusinessProcessEvent("Labor Data : ", Msit.Telemetry.Extensions.ComponentType.BackgroundProcess), telemetry.telemetryLaborProperties);

                if (ml.Index > 0)
                {
                  string status= storeLoadedList(index, ml);
                }

            }

            catch (Exception exe)
            {
                appFile.WriteLine("Inside Labor Entry" + exe.StackTrace);
                telemetryClient.TrackException(exe);
            }
            return laborDataEntry;
        }
        /// <summary>
        /// to get access with appid,clientid and secretid
        /// </summary>
        /// <returns></returns>
        public AuthInput GetAuth()
        {
            AuthInput auth = new AuthInput();
            auth.Authority = ConfigurationManager.AppSettings["Authority"].ToString();
            auth.ClientId = ConfigurationManager.AppSettings["ClientId"].ToString();
            auth.ClientSecret = ConfigurationManager.AppSettings["ClientSecret"].ToString();
            auth.Resource = ConfigurationManager.AppSettings["Resource"].ToString();
            return auth;
        }

        /// <summary>
        /// store the existing Mlx file to storedlist
        /// </summary>
        public string storeLoadedList(int index, MailingList ml)
        {
            XmlDocument doc;
            try
            {
                if (ml != null)
                {
                    if (ml.Index > 0)
                    {

                        doc = new XmlDocument();
                        doc.Load(ConfigurationManager.AppSettings["LoadedList"].ToString());
                        // create node and add value
                        XmlNode node = doc.CreateNode(XmlNodeType.Element, "MailingList", null);
                        //node.InnerText = "this is new node";

                        //create title node
                        XmlNode nodeContractNumber = doc.CreateElement("AgreementId");
                        //add value for it
                        nodeContractNumber.InnerText = ml.AgreementId;

                        XmlNode nodeScheduleId = doc.CreateElement("PackageId");
                        //add value for it
                        nodeScheduleId.InnerText = ml.PackageId;

                        XmlNode nodeLineItemID = doc.CreateElement("ServiceId");
                        //add value for it
                        nodeLineItemID.InnerText = ml.ServiceId;

                        XmlNode nodeRegionID = doc.CreateElement("AgreementRegionId");
                        //add value for it
                        nodeRegionID.InnerText = ml.AgreementRegionId.ToString();

                        XmlNode nodeIndex = doc.CreateElement("Index");
                        //add value for it
                        // nodeIndex.InnerText = "1";//.ContractNo;
                        nodeIndex.InnerText = ml.Index.ToString();

                        XmlNode nodeGUID = doc.CreateElement("GUID");
                        //add value for it
                        nodeGUID.InnerText = ml.GUID.ToString();

                        XmlNode nodeCountry = doc.CreateElement("AgreementCountry");
                        //add value for it
                        nodeCountry.InnerText = ml.AgreementCountry;


                        XmlNode nodeTag = doc.CreateElement("Tag");
                        //add value for it
                        nodeTag.InnerText = ml.Tag[0];


                        XmlNode nodeLaboCategoryIdr = doc.CreateElement("LaborCategoryId");
                        //add value for it
                        nodeLaboCategoryIdr.InnerText = ml.LaborCategoryId.ToString();

                        node.AppendChild(nodeContractNumber);
                        node.AppendChild(nodeLineItemID);
                        node.AppendChild(nodeRegionID);
                        node.AppendChild(nodeScheduleId);
                        node.AppendChild(nodeIndex);
                        node.AppendChild(nodeGUID);

                        node.AppendChild(nodeLaboCategoryIdr);
                        node.AppendChild(nodeTag);

                        //add to elements collection
                        doc.DocumentElement.AppendChild(node);


                        doc.Save(ConfigurationManager.AppSettings["LoadedList"].ToString());


                        appFile.WriteLine("LoadedList added with Mailing List" + ml.GUID.ToString());
                    }

                    else
                    {
                        XmlRootAttribute xRoot = new XmlRootAttribute();
                        xRoot.ElementName = "Tag";
                        XmlSerializer serializer = new XmlSerializer(typeof(List<MailingList>), xRoot);
                        using (TextWriter writer = new StreamWriter(ConfigurationManager.AppSettings["LoadedList"].ToString()))
                        {
                            serializer.Serialize(writer, loadedLists);
                        }
                    }
                }

                else
                {
                    if (!File.Exists(ConfigurationManager.AppSettings["LoadedList"].ToString()))
                    {
                        XmlRootAttribute xRoot = new XmlRootAttribute();
                        xRoot.ElementName = "Tag";
                        XmlSerializer serializer = new XmlSerializer(typeof(List<MailingList>), xRoot);
                        using (TextWriter writer = new StreamWriter(ConfigurationManager.AppSettings["LoadedList"].ToString()))
                        {
                            serializer.Serialize(writer, loadedLists);
                            writer.Close();
                        }
                    }
                    else
                    {
                        doc = new XmlDocument();
                        doc.Load(ConfigurationManager.AppSettings["LoadedList"].ToString());
                        var rootNode = doc.GetElementsByTagName("Tag")[0];
                        var nav = rootNode.CreateNavigator();
                        var emptyNamepsaces = new XmlSerializerNamespaces(new[] {
                           XmlQualifiedName.Empty });
                        foreach (MailingList list in loadedLists)
                        {
                            using (var writer = nav.AppendChild())
                            {
                                var serializer = new XmlSerializer(typeof(MailingList));
                                writer.WriteWhitespace("");
                                serializer.Serialize(writer, list, emptyNamepsaces);
                                writer.Close();
                            }
                        }
                        doc.Save(ConfigurationManager.AppSettings["LoadedList"].ToString());

                    }
                }
                return "Success";
            }


            catch (Exception exe)
            {
                appFile.WriteLine("Error Store Loaded list" + exe.StackTrace + " " + exe.InnerException);
                telemetryClient.TrackException(exe);
                return "Failed";
            }
            finally
            {
                doc = null;

            }
        }




        private void AppendToFileLog(string file)
        {
            try
            {
                if (!Directory.Exists(ConfigurationManager.AppSettings["BusinessErrorLog"].ToString()))
                {
                    Directory.CreateDirectory(ConfigurationManager.AppSettings["BusinessErrorLog"].ToString());
                }
                using (StreamWriter wr = System.IO.File.AppendText(ConfigurationManager.AppSettings["LstLog"].ToString() + ".lst"))
                {
                    wr.WriteLine(file);
                    wr.Close();
                }
            }
            catch (Exception exe)
            {
                appFile.WriteLine(exe.Message);
            }
            finally
            {
            }


        }

    }


}

    

