﻿namespace AutomatedLaborEntry
{
    class Program
    {
        static void Main(string[] args)
        {

            new LaborLogging();
        }
    }
}
