﻿using AutomatedLaborEntry.Model;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Configuration;

namespace AutomatedLaborEntry
{
    public class FetchFromSharePoint
    {
        private static ClientContext clientContext = null;
        private string userName="";
            private string passWord ="";


        public void getFileStream()
        {
            userName = ConfigurationManager.AppSettings["Username"].ToString();
            passWord = ConfigurationManager.AppSettings["Password"].ToString();

            XmlSerializer xml = new XmlSerializer(typeof(MailingTagList));

            try
            {
                clientContext = GetSiteContext(ConfigurationManager.AppSettings["SharepointUrl"].ToString(), userName, passWord);
                clientContext.RequestTimeout = 10800000;
                Web web = clientContext.Web;
                clientContext.Load(web, a => a.ServerRelativeUrl);
                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);

                List list = clientContext.Web.Lists.GetByTitle("Delivery Documents");
                clientContext.Load(list);
                clientContext.Load(list.RootFolder);
                clientContext.Load(list.RootFolder.Folders);
                clientContext.Load(list.RootFolder.Files);
                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);

                FolderCollection fcol = list.RootFolder.Folders;

                List<string> lstFile = new List<string>();

                foreach (Folder f in fcol)
                {
                    if (f.Name == "Backup Data")
                    {
                        FolderCollection fcollection = f.Folders;
                        clientContext.Load(fcollection);
                        ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);
                        foreach (Folder fo in fcollection)
                        {
                            if (fo.Name == ConfigurationManager.AppSettings["SharepointFolder"].ToString())
                            {
                                FileCollection fileCol = fo.Files;
                                clientContext.Load(fileCol);
                                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);
                                foreach (Microsoft.SharePoint.Client.File file in fileCol)
                                {


                                    if (file.Name.ToUpper().Contains("_SC-SECURITY-") || file.Name.ToUpper().Contains("_SC-PROACTIVEBILLINGONLY"))
                                    {
                                        if (!file.Name.Contains("NB"))
                                        {
                                            lstFile.Add(file.Name);
                                            FileInformation fileInformation = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, (string)file.ServerRelativeUrl);
                                            MailingTagList mls = (MailingTagList)xml.Deserialize(fileInformation.Stream);


                                            // Parse all tags and add to our global list if they weren't there already
                                            foreach (MailingList ml in mls.MailingLists)
                                            {
                                                ml.Index = 0;// mls.MailingLists.IndexOf(ml);
                                                ml.Tag = new string[] { mls.Name.Trim() };
                                                ml.GUID = Guid.NewGuid();

                                                // Add this list to our tally of all lists
                                                if (ml.Tag[0].ToUpper().Contains("_SC-SECURITY-"))
                                                {
                                                    if (LaborLogging.loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-SECURITY-")).Count() == 0)
                                                    {
                                                        ml.LaborCategoryId = (int)MailingList.laborCategory.Reactive_Content_Billing;
                                                        LaborLogging.loadedLists.Add(ml);
                                                    }
                                                }
                                                else if (ml.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY"))
                                                {
                                                    if (LaborLogging.loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY")).Count() == 0)
                                                    {
                                                        ml.LaborCategoryId = (int)MailingList.laborCategory.Proactive_Content_Billing;
                                                        LaborLogging.loadedLists.Add(ml);
                                                    }
                                                }

                                            }
                                        }
                                    }


                                }
                            }

                        }
                    }
                }

            }

            catch (MaximumRetryAttemptedException mex)
            {
                // Exception handling for the Maximum Retry Attempted
                LaborLogging.appFile.WriteLine("Exception in getFileStream:" + mex.Message);
                Console.WriteLine("Exception in getFileStream: " + mex.Message);
            }
            catch (Exception ex)
            {
                LaborLogging.appFile.WriteLine("Exception in getFileStream:" + ex.Message + ex.StackTrace);
                Console.WriteLine("Exception in getFileStream: " + ex.Message + ex.StackTrace);
            }
        }
        public void getFileStreamPROD()
        {
            userName = ConfigurationManager.AppSettings["Username"].ToString();
            passWord = ConfigurationManager.AppSettings["Password"].ToString();

            XmlSerializer xml = new XmlSerializer(typeof(MailingTagList));

            try
            {
                clientContext = GetSiteContext(ConfigurationManager.AppSettings["SharepointUrl"].ToString(), userName, passWord);
                clientContext.RequestTimeout = 10800000;
                Web web = clientContext.Web;
                clientContext.Load(web, a => a.ServerRelativeUrl);
                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);

                List list = clientContext.Web.Lists.GetByTitle("Delivery Documents");
                clientContext.Load(list);
                clientContext.Load(list.RootFolder);
                clientContext.Load(list.RootFolder.Folders);
                clientContext.Load(list.RootFolder.Files);
                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);

                FolderCollection fcol = list.RootFolder.Folders;

                List<string> lstFile = new List<string>();

                foreach (Folder f in fcol)
                {
                    if (f.Name == "Backup Data")
                    {
                        FolderCollection fcollection = f.Folders;
                        clientContext.Load(fcollection);
                        ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);
                        foreach (Folder fo in fcollection)
                        {
                            if (fo.Name == ConfigurationManager.AppSettings["SharepointFolder"].ToString())
                            {
                                FolderCollection fpcollection = fo.Folders;
                                clientContext.Load(fpcollection);
                                ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);
                                foreach (Folder folder in fpcollection)
                                {
                                    if (folder.Name == "MLX Files")
                                    {
                                        FileCollection fileCol = folder.Files;
                                        clientContext.Load(fileCol);
                                        ExecuteQueryWithIncrementalRetry(clientContext, 3, 30000);
                                        foreach (Microsoft.SharePoint.Client.File file in fileCol)
                                        {


                                            if (file.Name.ToUpper().Contains("_SC-SECURITY-") || file.Name.Contains("_SC-PROACTIVEBILLINGONLY"))
                                            {
                                                if (!file.Name.Contains("NB"))
                                                {
                                                    lstFile.Add(file.Name);
                                                    FileInformation fileInformation = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, (string)file.ServerRelativeUrl);
                                                    MailingTagList mls = (MailingTagList)xml.Deserialize(fileInformation.Stream);


                                                    // Parse all tags and add to our global list if they weren't there already
                                                    foreach (MailingList ml in mls.MailingLists)
                                                    {
                                                        ml.Index = 0;// mls.MailingLists.IndexOf(ml);
                                                        ml.Tag = new string[] { mls.Name.Trim() };
                                                        ml.GUID = Guid.NewGuid();

                                                        // Add this list to our tally of all lists
                                                        if (ml.Tag[0].ToUpper().Contains("_SC-SECURITY-"))
                                                        {
                                                            if (LaborLogging.loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-SECURITY-")).Count() == 0)
                                                            {
                                                                ml.LaborCategoryId = (int)MailingList.laborCategory.Reactive_Content_Billing;
                                                                LaborLogging.loadedLists.Add(ml);
                                                            }
                                                        }
                                                        else if (ml.Tag[0].Contains("_SC-PROACTIVEBILLINGONLY"))
                                                        {
                                                            if (LaborLogging.loadedLists.Where(x => x.PackageId == ml.PackageId && x.AgreementId == ml.AgreementId && x.Tag[0].ToUpper().Contains("_SC-PROACTIVEBILLINGONLY")).Count() == 0)

                                                            {
                                                                ml.LaborCategoryId = (int)MailingList.laborCategory.Proactive_Content_Billing;
                                                                LaborLogging.loadedLists.Add(ml);
                                                            }
                                                        }

                                                    }
                                                }
                                            }


                                        }
                                    }
                                }
                            }

                        }
                    }
                }

            }

            catch (MaximumRetryAttemptedException mex)
            {
                // Exception handling for the Maximum Retry Attempted
                LaborLogging.appFile.WriteLine("Exception in getFileStream:" + mex.Message);
                Console.WriteLine("Exception in getFileStream: " + mex.Message);
            }
            catch (Exception ex)
            {
                LaborLogging.appFile.WriteLine("Exception in getFileStream:" + ex.Message + ex.StackTrace);
                Console.WriteLine("Exception in getFileStream: " + ex.Message + ex.StackTrace);
            }
        }

        public static ClientContext GetSiteContext(string _SharePointSite, string _UserID, string _Password)
        {
            try
            {
                var authenticationManager = new OfficeDevPnP.Core.AuthenticationManager();

                ClientContext _siteContext = authenticationManager.GetWebLoginClientContext(_SharePointSite, null, false);
                _siteContext.AuthenticationMode = ClientAuthenticationMode.Default;

                ExecuteQueryWithIncrementalRetry(_siteContext, 3, 30000);

                return _siteContext;
            }
            catch (MaximumRetryAttemptedException mex)
            {
                // Exception handling for the Maximum Retry Attempted
                LaborLogging.appFile.WriteLine("Error occured during GetSiteContext method: " + mex.Message + mex.StackTrace);
                Console.WriteLine("Error occured during GetSiteContext method: " + mex.Message);
                return null;
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter("C:\\LaborEntry\\Error", true))
                {
                    writer.WriteLine("Method : Error occured during GetSiteContext method. LookUPList :  <br/> Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                LaborLogging.appFile.WriteLine("Error occured during GetSiteContext method: " + ex.Message + ex.StackTrace);
                Console.WriteLine("Error occured during GetSiteContext method" + ex.Message + ex.StackTrace);
                return null;
            }
        }


        public static void ExecuteQueryWithIncrementalRetry(ClientContext context, int retryCount, int delay)
        {
            int retryAttempts = 0;
            int backoffInterval = delay;
            if (retryCount <= 0)
                throw new ArgumentException("Provide a retry count greater than zero.");

            if (delay <= 0)
                throw new ArgumentException("Provide a delay greater than zero.");

            // Do while retry attempt is less than retry count
            while (retryAttempts < retryCount)
            {
                try
                {
                    context.ExecuteQuery();
                    return;

                }
                catch (WebException wex)
                {
                    var response = wex.Response as HttpWebResponse;
                    // Check if request was throttled - http status code 429
                    // Check is request failed due to server unavailable - http status code 503
                    if (response != null && (response.StatusCode == (HttpStatusCode)429 || response.StatusCode == (HttpStatusCode)503))
                    {
                        // Output status to console. Should be changed as Debug.WriteLine for production usage.
                        LaborLogging.appFile.WriteLine(string.Format("CSOM request frequency exceeded usage limits. Sleeping for {0} seconds before retrying.",
                                        backoffInterval));
                        Console.WriteLine(string.Format("CSOM request frequency exceeded usage limits. Sleeping for {0} seconds before retrying.",
                                        backoffInterval));

                        //Add delay for retry
                        System.Threading.Thread.Sleep(backoffInterval);

                        //Add to retry count and increase delay.
                        retryAttempts++;
                        backoffInterval = backoffInterval * 2;
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            throw new MaximumRetryAttemptedException(string.Format("Maximum retry attempts {0}, has be attempted.", retryCount));
        }
    }

    public class MaximumRetryAttemptedException : Exception
    {
        public MaximumRetryAttemptedException()
        {

        }
        public MaximumRetryAttemptedException(string msg)
            : base(msg)
        {
        }
    }
}
