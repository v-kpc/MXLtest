﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
//using Microsoft.ApplicationInsights;
//using Microsoft.ApplicationInsights.DataContracts;
using System.IO;
using AutomatedLaborEntry.Model;
using System.Configuration;
using Microsoft.ApplicationInsights.DataContracts;
using System.Net.Http.Headers;

namespace AutomatedLaborEntry
{
    public class ApiMethods
    {
        /// <summary>
        /// Post Method for Bulk Submit
        /// </summary>
        /// <param name="output">Json Payload with all labor data</param>
        /// <returns></returns>
        public async Task<bool> PostMethod(string output)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    var url = ConfigurationManager.AppSettings["BulkSendUrl"].ToString();
                    client.DefaultRequestHeaders.Add("Authorization", new AuthInput().GetAccess(GetAuth()).Result);
                    //  client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhsQzBSMTJza3hOWjFXUXdtak9GXzZ0X3RERSIsImtpZCI6IkhsQzBSMTJza3hOWjFXUXdtak9GXzZ0X3RERSJ9.eyJhdWQiOiI1ZWIxNzBmOS1mODI4LTQxMjEtOTM2Yy0yODhlYjQzYjA1MGUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83MmY5ODhiZi04NmYxLTQxYWYtOTFhYi0yZDdjZDAxMWRiNDcvIiwiaWF0IjoxNTgzNDg0Mjc1LCJuYmYiOjE1ODM0ODQyNzUsImV4cCI6MTU4MzQ4ODE3NSwiYWlvIjoiNDJOZ1lQQ2UyZjAvclRKdHphSTlVOWZObkxDVEJRQT0iLCJhcHBpZCI6ImZhNzBjMjE4LWNlYTAtNDA1Yi1hMjMwLTcwMzM5ZDQwN2E4YiIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0Ny8iLCJvaWQiOiI0NzVkZGM1My0zYWEzLTRiNTItOGJmYy0yMWY1YWUzNWM4MmMiLCJzdWIiOiI0NzVkZGM1My0zYWEzLTRiNTItOGJmYy0yMWY1YWUzNWM4MmMiLCJ0aWQiOiI3MmY5ODhiZi04NmYxLTQxYWYtOTFhYi0yZDdjZDAxMWRiNDciLCJ1dGkiOiIzWTFHNHRzSmhFZXBLUHZ5QUtZdEFBIiwidmVyIjoiMS4wIn0.drxzDVURjv_KKavJCz-4e2NCZmFl15O0fvvekV8PfuJ6bN-lpNOA6kKOQQJgoeTwsmOGSzSYuZpakR1kRCN4glCizTHEg8UgC4a7pqO0sjeJbbeemGbUYGblWBEAe0Ge78Dp3ZmXcxGralb4-8Lbnaw0aXLvnXgoVMM34qLDit6v-lBFowe0WyA86Jimd6E5pUugExiDfqHm55e2Mz0FeU-Sy9vx7XcGUysAs-aRsQd7BfPpY1j5q5YZLecnhWvo7H1iRtJqRoRZoQzkrkLB66i157nBHXhX_2FfUrxwzD0a43vJDTNdov8fgSO5o-5GsD4yThYkHTdJl8F_QP-B9A");
                    client.DefaultRequestHeaders.Add("x-originating-system-name", "ServiceCenter-LaborEntryAutomation");
                    client.DefaultRequestHeaders.Add("x-core-correlation-request-id", Guid.NewGuid().ToString());
                    client.DefaultRequestHeaders.Add("X-CorrelationId", Guid.NewGuid().ToString());
                    client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", ConfigurationManager.AppSettings["Ocp-Apim-Subscription-Key"].ToString());
                    var data = new StringContent(output, Encoding.UTF8, "application/json");
                    //  var response = await client.PostAsync("https://professionalservices.microsoft.com/lmt-coreapi/api/v1/labor/operation", data);
                    var response = await client.PostAsync(url, data).ConfigureAwait(true);
                    // var response = client.PostAsync(url, data).GetAwaiter().GetResult();
                    string result = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        LaborLogging.logger.TrackRequest(new RequestTelemetry()
                        {
                            Success = true,
                            HttpMethod = "Post",
                            Url = new Uri(url),
                            ResponseCode = response.StatusCode.ToString()
                        }
                        );
                        LaborLogging.appFile.WriteLine("Post Successfully: " + DateTime.Now.ToString());
                        LaborLogging.appFile.Flush();
                        return true;
                    }
                    else
                    {
                        LaborLogging.appFile.WriteLine("Error in Post : " + result + response.ReasonPhrase + response.StatusCode);
                        LaborLogging.appFile.Flush();
                        throw new HttpRequestException(result + response.ReasonPhrase + response.StatusCode);
                    }
                    // Console.WriteLine(result);

                }
                catch (HttpRequestException e)
                {
                    LaborLogging.telemetryClient.TrackException(e);
                    Console.WriteLine("\nException Caught!");
                    Console.WriteLine("Message :{0} ", e.Message);
                    LaborLogging.appFile.WriteLine("Error in Post :" + DateTime.Now + "\n" + e.Message);
                    LaborLogging.appFile.Flush();
                    return false;
                }
                catch (WebException wex)
                {
                    if (wex.Response != null)
                    {
                        using (var errorResponse = (HttpWebResponse)wex.Response)
                        {
                            using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                            {
                                string error = reader.ReadToEnd();
                                LaborLogging.appFile.WriteLine("WebRequestError :" + DateTime.Now + "\n" + error);
                                LaborLogging.telemetryClient.TrackException(wex);
                                //TODO: use JSON.net to parse this string and look at the error message
                            }
                        }

                    }
                    return false;
                }
                catch (Exception ex)
                {
                    LaborLogging.telemetryClient.TrackException(ex);
                    // throw;
                    LaborLogging.appFile.WriteLine("Inside Post Method: " + ex.Message);
                    return false;
                }

            }
        }

        public AuthInput GetAuth()
        {
            AuthInput auth = new AuthInput();
            auth.Authority = ConfigurationManager.AppSettings["Authority"].ToString();
            auth.ClientId = ConfigurationManager.AppSettings["ClientId"].ToString();
            auth.ClientSecret = ConfigurationManager.AppSettings["ClientSecret"].ToString();
            auth.Resource = ConfigurationManager.AppSettings["Resource"].ToString();
            return auth;
        }

    }

}

