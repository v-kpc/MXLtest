﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDC.Labor.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddBulkCompletion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LaborBulkCompletion",
                schema: "LaborLoad",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PartitionKey = table.Column<long>(type: "bigint", nullable: false),
                    RowKey = table.Column<int>(type: "int", nullable: false),
                    Timestamp = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    AgreementID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    AgreementIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Countrytype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    PackageID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    PackageIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ServiceID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ServiceIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    LaborCategory = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    LaborCategorytype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ErrorType = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ErrorTypetype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CorrelationID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CorrelationIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    TransactionID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    TransactionIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    LaborID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    LaborIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    BulkCorrelationID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    BulkCorrelationIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    BulkSubCorrelationID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    BulkSubCorrelationIDtype = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OperationID = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    OperationIDtype = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ErrorMessagetype = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LaborBulkCompletion", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LaborBulkCompletion_ErrorType",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                column: "ErrorType");

            migrationBuilder.CreateIndex(
                name: "IX_LaborBulkCompletion_LaborCategory",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                column: "LaborCategory");

            migrationBuilder.CreateIndex(
                name: "IX_LaborBulkCompletion_Timestamp",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                column: "Timestamp");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LaborBulkCompletion",
                schema: "LaborLoad");
        }
    }
}
