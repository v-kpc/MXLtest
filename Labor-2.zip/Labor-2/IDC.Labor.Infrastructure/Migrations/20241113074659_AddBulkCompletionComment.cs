﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDC.Labor.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddBulkCompletionComment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "PartitionKey",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<string>(
                name: "Comment",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ExternalId",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "ModifiedTime",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "datetimeoffset",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_LaborBulkCompletion_ExternalId",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                column: "ExternalId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_LaborBulkCompletion_ExternalId",
                schema: "LaborLoad",
                table: "LaborBulkCompletion");

            migrationBuilder.DropColumn(
                name: "Comment",
                schema: "LaborLoad",
                table: "LaborBulkCompletion");

            migrationBuilder.DropColumn(
                name: "ExternalId",
                schema: "LaborLoad",
                table: "LaborBulkCompletion");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                schema: "LaborLoad",
                table: "LaborBulkCompletion");

            migrationBuilder.DropColumn(
                name: "ModifiedTime",
                schema: "LaborLoad",
                table: "LaborBulkCompletion");

            migrationBuilder.AlterColumn<long>(
                name: "PartitionKey",
                schema: "LaborLoad",
                table: "LaborBulkCompletion",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500);
        }
    }
}
