﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDC.Labor.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class LaborInit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "LaborLoad");

            migrationBuilder.CreateTable(
                name: "MailingList",
                schema: "LaborLoad",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AgreementId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PackageId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ServiceId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AgreementRegionId = table.Column<int>(type: "int", nullable: false),
                    Index = table.Column<int>(type: "int", nullable: false),
                    GUID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AgreementCountry = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LaborCategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MailingList", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MailingList",
                schema: "LaborLoad");
        }
    }
}
