﻿using FluentResults;
using Microsoft.EntityFrameworkCore;
using IDC.Common.Tools.Extensions.FluentResultExtensions;
using IDC.Labor.Infrastructure.Database;
using IDC.Labor.Infrastructure.Database.Model;
using IDC.Common.Tools.Errors;
using IDC.Common.Model;

namespace IDC.Labor.Infrastructure.Repositories
{
    internal  class LaborRepository : ILaborRepository
    {
        private readonly LaborDbContext _dbContext;

        public LaborRepository(LaborDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Result<LaborLoadItemEntity>> Get(long id, CancellationToken token)
        {
            var result = await _dbContext.LaborLoad.FirstOrDefaultAsync(x => x.Id == id, token);
            return result is null
                ? Result.Fail<LaborLoadItemEntity>(new NotFoundInRepositoryError(id.ToString()))
                : Result.Ok(result);
        }
        public Result<LaborLoadItemEntity> Add(LaborLoadItemEntity entity, CancellationToken token)
        {
            _dbContext.LaborLoad.Add(entity);
            return Result.Ok(entity);
        }
        public async Task<Result> InsertBulkCompletion(LaborBulkCompletion entity,CancellationToken token)
        {
            _dbContext.LaborBulkCompletion.Add(entity);
            await _dbContext.SaveChangesAsync(token);
            return Result.Ok();
        }
        public async Task<Result> Commit(CancellationToken token)
        {
            await _dbContext.SaveChangesAsync(token);
            return Result.Ok();
        }

        public async Task<Result<LaborBulkCompletion>> GetBulkCompletion(Guid id, CancellationToken token)
        {
            var result = await _dbContext.LaborBulkCompletion.FirstOrDefaultAsync(x => x.ExternalId == id, token);
            return result is null
                ? Result.Fail<LaborBulkCompletion>(new NotFoundInRepositoryError(id.ToString()))
                : Result.Ok(result);
        }

        public Result<LaborBulkCompletion> Update(LaborBulkCompletion entity, CancellationToken token)
        {
            _dbContext.LaborBulkCompletion.Update(entity);
            return Result.Ok(entity);
        }
        public async Task<Result<PaginatedList<LaborBulkCompletion>>> FindLaborBulkCompletionByCriteria(string? laborCategory, string? errorType, DateTimeOffset? startDate, DateTimeOffset? endDate, int pageIndex, int pageSize, CancellationToken cancellationToken)
        {

            var query = _dbContext.LaborBulkCompletion
                .AsNoTracking()
                .AsQueryable();
            if (!string.IsNullOrWhiteSpace(laborCategory)) query = query.Where(query => query.LaborCategory == laborCategory);
            if (!string.IsNullOrWhiteSpace(errorType)) query = query.Where(query => query.ErrorType == errorType);
            if (startDate is not null) query = query.Where(query => query.Timestamp >= startDate);
            if (endDate is not null) query = query.Where(query => query.Timestamp <= endDate);

           
            var resultsCount = await query.CountAsync(cancellationToken);
            var results = await query.OrderBy(x => x.Timestamp).ThenBy(x => x.Id).Skip(pageIndex * pageSize).Take(pageSize).ToListAsync(cancellationToken);
            return new PaginatedList<LaborBulkCompletion>(results, pageIndex, pageSize, resultsCount, (int)Math.Ceiling(resultsCount / (double)pageSize));
        }

    }
}
