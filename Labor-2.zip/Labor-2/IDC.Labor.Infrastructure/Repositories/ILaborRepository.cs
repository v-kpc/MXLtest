﻿using FluentResults;
using IDC.Common.Model;
using IDC.Labor.Infrastructure.Database.Model;

namespace IDC.Labor.Infrastructure.Repositories
{
    public interface ILaborRepository
    {

        Task<Result<LaborLoadItemEntity>> Get(long id, CancellationToken token);
        Result<LaborLoadItemEntity> Add(LaborLoadItemEntity entity, CancellationToken token);
        Task<Result<LaborBulkCompletion>> GetBulkCompletion(Guid id, CancellationToken token);
        Result<LaborBulkCompletion> Update(LaborBulkCompletion entity, CancellationToken token);
        Task<Result> Commit(CancellationToken token);
        Task<Result<PaginatedList<LaborBulkCompletion>>> FindLaborBulkCompletionByCriteria(string? laborCategory, string? errorType, DateTimeOffset? startDate, DateTimeOffset? endDate, int pageIndex, int pageSize, CancellationToken cancellationToken);
        Task<Result> InsertBulkCompletion(LaborBulkCompletion entity,CancellationToken token);
    }
}
