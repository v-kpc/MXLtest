﻿using IDC.Labor.Infrastructure.Database;
using IDC.Labor.Infrastructure.Repositories;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace IDC.Labor.Infrastructure
{
    public static class InfrastructureModuleExtensions
    {
        public static IServiceCollection AddInfrastructureModule(this IServiceCollection services,
            IConfiguration configuration, bool isIntegrationTests)
        {
            services.AddScoped<ILaborRepository, LaborRepository>();

            if (!isIntegrationTests)
            {
                var connectionString = configuration["LaborDbConnectionString"];

                services.AddDbContextPool<LaborDbContext>(o => o.UseSqlServer(connectionString, c => c.EnableRetryOnFailure()).EnableSensitiveDataLogging());
            }
            else
            {
                var inMemoryRoot = new InMemoryDatabaseRoot();
                services.AddDbContextPool<LaborDbContext>(o => o.UseInMemoryDatabase("Labor", inMemoryRoot).EnableServiceProviderCaching(false));
            }

            return services;
        }
    }
}
