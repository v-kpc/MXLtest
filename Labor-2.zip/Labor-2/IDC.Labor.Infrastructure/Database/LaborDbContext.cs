﻿using IDC.Labor.Infrastructure.Database.Model;
using Microsoft.EntityFrameworkCore;

namespace IDC.Labor.Infrastructure.Database
{
    public class LaborDbContext : DbContext
    {


        public LaborDbContext(DbContextOptions<LaborDbContext> options)
            : base(options)
        {
        }

        public DbSet<LaborLoadItemEntity> LaborLoad { get; set; } = default!;
        public DbSet<LaborBulkCompletion> LaborBulkCompletion { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.HasDefaultSchema("LaborLoad");
            builder.Entity<LaborLoadItemEntity>(e =>
            {
                e.ToTable("MailingList");
                e.HasKey(p => p.Id);
            });
            builder.Entity<LaborBulkCompletion>(e =>
            {
                e.ToTable("LaborBulkCompletion");
                e.HasKey(p => p.Id);
                e.Property(p=> p.ExternalId).IsRequired();
                e.HasIndex(e => e.ExternalId).IsUnique();

                e.HasIndex(p => p.ErrorType);
                e.HasIndex(p => p.LaborCategory);
                e.HasIndex(p => p.Timestamp);

                e.Property(p => p.PartitionKey).HasMaxLength(500);
                e.Property(p => p.AgreementID).HasMaxLength(500);
                e.Property(p => p.AgreementIDtype).HasMaxLength(500);
                e.Property(p => p.Country).HasMaxLength(500);
                e.Property(p => p.Countrytype).HasMaxLength(500);
                e.Property(p => p.PackageID).HasMaxLength(500);
                e.Property(p => p.PackageIDtype).HasMaxLength(500);
                e.Property(p => p.ServiceID).HasMaxLength(500);
                e.Property(p => p.ServiceIDtype).HasMaxLength(500);
                e.Property(p => p.LaborCategory).HasMaxLength(500);
                e.Property(p => p.LaborCategorytype).HasMaxLength(500);
                e.Property(p => p.ErrorType).HasMaxLength(500);
                e.Property(p => p.ErrorTypetype).HasMaxLength(500);
                e.Property(p => p.CorrelationID).HasMaxLength(500);
                e.Property(p => p.CorrelationIDtype).HasMaxLength(500);
                e.Property(p => p.TransactionID).HasMaxLength(500);
                e.Property(p => p.TransactionIDtype).HasMaxLength(500);
                e.Property(p => p.LaborID).HasMaxLength(500);
                e.Property(p => p.LaborIDtype).HasMaxLength(500);
                e.Property(p => p.BulkCorrelationID).HasMaxLength(500);
                e.Property(p => p.BulkCorrelationIDtype).HasMaxLength(500);
                e.Property(p => p.BulkSubCorrelationID).HasMaxLength(500);
                e.Property(p => p.OperationID).HasMaxLength(500);
                e.Property(p => p.OperationIDtype).HasMaxLength(500);
                e.Property(p => p.ModifiedBy).HasMaxLength(500);
                e.Property(p => p.Comment);
            });
        }

    }

}
