﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDC.Labor.Infrastructure.Database.Model
{
    public class LaborLoadItemEntity
    {
        public long Id { get; set; }
        public string AgreementId { get; set; }
        public string PackageId { get; set; }
        public string ServiceId { get; set; }
        public int AgreementRegionId { get; set; }
        public int Index { get; set; }
        public Guid GUID { get; set; }
        public string AgreementCountry { get; set; }
        private string[] Tags { get; set; }
        public int LaborCategoryId { get; set; }

    }
}


