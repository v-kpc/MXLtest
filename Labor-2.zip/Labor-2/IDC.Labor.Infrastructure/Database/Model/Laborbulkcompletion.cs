﻿using System;
using System.Collections.Generic;
namespace IDC.Labor.Infrastructure.Database.Model
{
    public class LaborBulkCompletion
    {
        public long Id { get; set; }
        public Guid ExternalId { get; set; }

        public string PartitionKey { get; set; }
        public int RowKey { get; set; }

        public DateTimeOffset Timestamp { get; set; }
        public string AgreementID { get; set; }
        public string? AgreementIDtype { get; set; }
        public string Country  { get; set; }
        public string? Countrytype { get; set; }
        public string PackageID { get; set; }
        public string? PackageIDtype { get; set; }
        public string ServiceID { get; set; }
        public string? ServiceIDtype { get; set; }
        public string  LaborCategory { get; set; }
        public string? LaborCategorytype { get; set; }
        public string ErrorType { get; set; }
        public string? ErrorTypetype { get; set; }
        public string  CorrelationID { get; set; }
        public string? CorrelationIDtype { get; set; }
    public string  TransactionID { get; set; }
    public string?  TransactionIDtype { get; set; }
        public string LaborID { get; set; }
        public string? LaborIDtype { get; set; }
        public string BulkCorrelationID { get; set; }
        public string? BulkCorrelationIDtype { get; set; }
        public string BulkSubCorrelationID { get; set; }
        public string? BulkSubCorrelationIDtype { get; set; }
        public string OperationID { get; set; }
        public string? OperationIDtype { get; set; }
        public string ErrorMessage { get; set; }
        public string? ErrorMessagetype { get; set; }
        public string? Comment { get; set; }

        public string? ModifiedBy { get; set; }
        public DateTimeOffset? ModifiedTime { get; set; }


        public LaborBulkCompletion SetStatus(string errorType, string comment, string userName)
        {

            ErrorType = errorType;
            Comment = comment;
            ModifiedBy = userName;
            ModifiedTime = DateTimeOffset.UtcNow;
            return this;
        }
    }
}
