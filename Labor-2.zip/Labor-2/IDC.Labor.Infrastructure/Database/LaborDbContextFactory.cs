﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore;

namespace IDC.Labor.Infrastructure.Database
{
    internal class LaborDbContextFactory : IDesignTimeDbContextFactory<LaborDbContext>
    {
        public LaborDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<LaborDbContext>();
            builder.UseSqlServer(".");
            return new LaborDbContext(builder.Options);
        }
    }
}